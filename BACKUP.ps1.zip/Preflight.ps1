﻿# =============================================================================
#  Audio-Video Preflight  .  Kingdom Hall AV App -- WTLC Edition
#  Version 5.5 - EMEET Integration Edition
# =============================================================================

$Script:ScriptRoot = if ($PSScriptRoot) {
    $PSScriptRoot
} else {
    Split-Path $MyInvocation.MyCommand.Path -ErrorAction SilentlyContinue
}

$Script:MediaFolder = Join-Path $Script:ScriptRoot "media"

# =============================================================================
#  CONFIGURATION
# =============================================================================
$Script:Config = @{
    CongregationName    = "West Tagalog Lingayen Congregation"
    TestMode            = $false
    AdminMode           = $false
    OnlyTMode           = $true
    OnlyTWebPort        = 8096
    BluetoothMode       = $true
    BluetoothInstanceId = "BTHENUM\DEV_4142F4625775\7&1DA13D4F&0&BLUETOOTHDEVICE_4142F4625775"
    BluetoothDeviceName = "WN_AUDIO"
    ObsDynamicSceneMode = $true
    ObsAlwaysOnTopMode  = $false
    ObsProfile          = "WTLC - PROFILE"
    ObsSceneMidweek     = "WTLC | Midweek"
    ObsSceneWeekend     = "WTLC | Weekend"
    ZoomSelfHostingMode = $false
    EmeetIntegMode      = $false
    EmeetPath           = "C:\Program Files\EMEET STUDIO\bin\64bit\EMEET STUDIO.exe"
    # Position/size EMEET STUDIO is moved to during the "Let's enable the VCAM"
    # step -- large and prominent so the operator can watch the automated
    # clicks land. It's repositioned again into its regular tile (LayoutEmeet /
    # LayoutEmeetOnlyT) once the meeting actually launches.
    EmeetVcamRect       = @{ X = 786; Y = 180; W = 1140; H = 619 }
    StageCountdownMode          = $true
    StageCountdownPath          = "C:\Program Files\StageCountdown\StageCountdown.exe"
    WebcamName          = "PTZ Camera"
    WebcamInstanceId    = "USB\VID_328F&PID_00C0&MI_00\8&28D0322B&0&0000"
    JwLibraryShortcut   = "JW Library.lnk"
    ObsPath             = "C:\Program Files\obs-studio\bin\64bit\obs64.exe"
    M3Path              = "C:\Program Files\Meeting Media Manager\Meeting Media Manager.exe"
    ZoomPath            = (Join-Path $env:APPDATA "Zoom\bin\Zoom.exe")
    OnlyTPath           = "C:\Program Files\OnlyT\OnlyT.exe"
    UsbAudioInstanceId  = "USB\VID_0020&PID_0B21&MI_00\6&31E40A88&0&0000"

    ZoomHome = @{ X = 1300; Y = 40; W = 580; H = 640 }

    # Default launch order/position/size/timing per mode. Order/X/Y/W/H/DelayMs
    # are each individually overridable from Documents\Preflight Settings\Layout.conf
    # (or from Settings > Layout) -- a field left out of that file just falls
    # back to the value here.
    LaunchSequenceStandard = @(
        @{ App = "Obs";  Order = 1; X = -7;  Y = 0;   W = 974; H = 1039; DelayMs = 500 }
        @{ App = "Zoom"; Order = 2; X = 953; Y = 0;   W = 974; H = 392;  DelayMs = 500 }
        @{ App = "M3";   Order = 3; X = 953; Y = 385; W = 974; H = 654;  DelayMs = 500 }
    )
    LaunchSequenceOnlyT = @(
        @{ App = "M3";    Order = 1; X = 0;   Y = 0;   W = 688;  H = 568; DelayMs = 500 }
        @{ App = "OnlyT"; Order = 2; X = 0;   Y = 572; W = 688;  H = 468; DelayMs = 500 }
        @{ App = "Zoom";  Order = 3; X = 692; Y = 0;   W = 1228; H = 320; DelayMs = 500 }
        @{ App = "Obs";   Order = 4; X = 692; Y = 324; W = 1228; H = 716; DelayMs = 500 }
    )
    # EMEET sequences -- single primary monitor. EMEET sits behind OBS, offset
    # so roughly the left quarter of its window still peeks out (OBS launches
    # after EMEET, so it naturally lands on top in z-order).
    LaunchSequenceEmeet = @(
        @{ App = "Emeet"; Order = 1; X = 580; Y = 381; W = 1350; H = 658; DelayMs = 500 }
        @{ App = "Zoom";  Order = 2; X = 692; Y = 0;   W = 1228; H = 388; DelayMs = 500 }
        @{ App = "Obs";   Order = 3; X = 958; Y = 382; W = 962;  H = 658; DelayMs = 500 }
        @{ App = "M3";    Order = 4; X = -8;  Y = 0;   W = 748;  H = 691; DelayMs = 500 }
    )
    LaunchSequenceEmeetOnlyT = @(
        @{ App = "Emeet"; Order = 1; X = 580; Y = 381; W = 1350; H = 658; DelayMs = 500 }
        @{ App = "Zoom";  Order = 2; X = 692; Y = 0;   W = 1228; H = 388; DelayMs = 500 }
        @{ App = "Obs";   Order = 3; X = 958; Y = 382; W = 962;  H = 658; DelayMs = 500 }
        @{ App = "M3";    Order = 4; X = -8;  Y = 0;   W = 748;  H = 691; DelayMs = 500 }
        @{ App = "OnlyT"; Order = 5; X = -8;  Y = 684; W = 748;  H = 353; DelayMs = 500 }
    )
    M3ProcessNames    = @("Meeting Media Manager", "meeting-media-manager")
    ZoomProcessNames  = @("Zoom")
    ObsProcessNames   = @("obs64")
    OnlyTProcessNames = @("OnlyT")
    EmeetProcessNames = @("EMEET STUDIO", "EMEET_STUDIO", "EMEETStudio")
    StageCountdownProcessNames = @("StageCountdown")

    UiRefreshMs        = 600
    PollIntervalSec    = 2
    WindowWaitSeconds  = 30
    ZoomActivationWait = 1500
    ZoomFocusSettle    = 800
    ZoomSidebarRender  = 600
    FinalMessageHold   = 1200
    VideoErrorHold     = 4000
    DataFolder         = (Join-Path $env:LOCALAPPDATA "AV-Preflight")
}

function Get-PreflightModeName {
    # Which of the four launch layouts is currently active.
    if ($Script:Config.EmeetIntegMode) {
        if ($Script:Config.OnlyTMode) { return "EmeetOnlyT" } else { return "Emeet" }
    }
    if ($Script:Config.OnlyTMode) { return "OnlyT" }
    return "Standard"
}

function Get-PreflightSequenceDefaults {
    param([string]$ModeName)
    switch ($ModeName) {
        "EmeetOnlyT" { return $Script:Config.LaunchSequenceEmeetOnlyT }
        "Emeet"      { return $Script:Config.LaunchSequenceEmeet }
        "OnlyT"      { return $Script:Config.LaunchSequenceOnlyT }
        default      { return $Script:Config.LaunchSequenceStandard }
    }
}

function Resolve-LaunchSequence {
    # Merges a mode's default sequence with any per-field overrides loaded
    # from Layout.conf (field-level: a field left out of the file keeps the
    # script default for that field), then sorts by the effective Order.
    param([string]$ModeName)
    $defaults  = Get-PreflightSequenceDefaults -ModeName $ModeName
    $overrides = if ($Script:LayoutOverrides.ContainsKey($ModeName)) { $Script:LayoutOverrides[$ModeName] } else { @{} }

    $merged = foreach ($step in $defaults) {
        $row = @{ App = $step.App; Order = $step.Order; X = $step.X; Y = $step.Y; W = $step.W; H = $step.H; DelayMs = $step.DelayMs }
        if ($overrides.ContainsKey($step.App)) {
            foreach ($field in $overrides[$step.App].Keys) { $row[$field] = $overrides[$step.App][$field] }
        }
        $row
    }
    return @($merged | Sort-Object { $_.Order })
}

function Get-LaunchStep {
    # Convenience for code that needs just one app's resolved position outside
    # the main Start-Launch loop (e.g. OnlyT's early auto-launch on hardware-green).
    param([string]$ModeName, [string]$AppName)
    return (Resolve-LaunchSequence -ModeName $ModeName) | Where-Object { $_.App -eq $AppName } | Select-Object -First 1
}

# ----- QUESTIONS -------------------------------------------------------------
$Script:ZoomQuestionsHost = @(
    @{ Text = "Have you shared computer audio?"; Sub = "Remote participants need this to hear meeting media."; Video = "zoom-share-audio.mp4" }
)
$Script:ZoomQuestionsJoin = @(
    @{ Text = "Have you shared computer audio?"; Sub = "Remote participants need this to hear meeting media."; Video = "zoom-share-audio.mp4" }
)
$Script:EquipmentQuestionsRegular = @(
    @{ Text = "Are all cables plugged into the laptop?";                Sub = "Check the photo below to confirm each cable is connected to the correct port.";  Photo = "check-laptop-connections.jpg" }
    @{ Text = "Is the RCA-to-Aux cable connected to the mixer?";        Sub = "Connects Mixer Output to the Laptop Input";                                                        Photo = "check-rca-cable.jpg" }
    @{ Text = "Are the USB Audio Adapter cables on the adapter ports?"; Sub = "Mic Input should be plugged in as shown for Zoom Mic Input";                                            Photo = "check-usb-cables.jpg" }
    @{ Text = "Is the HDMI-to-Ethernet converter set up?";              Sub = "Required for a stable and reliable HDMI display signal to the TVs.";                                     Photo = "check-hdmi-converter.jpg" }
)
$Script:EquipmentQuestionsNonZoom = @(
    @{ Text = "Are the cables plugged into the laptop?"; Sub = "Check the photo below to confirm the AC Power and HDMI cables are connected — no RCA-Aux or USB Audio needed for this setup."; Photo = "check-admin-nonzoom-connections.jpg" }
    @{ Text = "Is the HDMI-to-Ethernet converter set up?"; Sub = "Required for a stable internet connection during the meeting."; Photo = "check-hdmi-converter.jpg" }
)

# Sections: Zoom -> Equipment  (OnlyT handled inside Detection flow)
$Script:Sections = @(
    @{ Id = "zoom";      Name = "Zoom Setup";      Type = "video"; Questions = $Script:ZoomQuestionsHost }
    @{ Id = "equipment"; Name = "Equipment Check"; Type = "photo"; Questions = $Script:EquipmentQuestionsRegular }
)

# ----- STATE -----------------------------------------------------------------
$Script:State = @{
    SectionIdx       = 0
    QuestionIdx      = 0
    CurrentVideo     = ""
    AllHwReady       = $false
    AutoLaunched     = $false
    ZoomMode         = ""
    Flow             = "Regular"
    NonZoomProgram   = ""
    OnlyTAccessCodes = @{ Wired = @(); Wireless = @() }
    OnlyTCodeStage   = "Wired"
    OnlyTLaunched    = $false
    OnlyTConfirmed   = $false
    BluetoothConfirmed = $false
    BluetoothSettingsOpened = $false
    StageCountdownAsked = $false
    UseStageCountdown   = $false
    EmeetVcamEnabled    = $false
}

# ----- HARDWARE CACHE --------------------------------------------------------
$Script:HwCache = [hashtable]::Synchronized(@{
    AcPower  = $false
    Internet = $false
    Display  = $false
    Webcam   = $false
    UsbAudio = $false
    Running  = $true
})

# ----- LOGGING ---------------------------------------------------------------
$Script:LogFile = Join-Path $Script:Config.DataFolder "preflight.log"

function Write-Log {
    param([string]$Message, [string]$Level = "INFO")
    $line = "[{0}] [{1}] {2}" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss"), $Level, $Message
    try {
        if (-not (Test-Path $Script:Config.DataFolder)) {
            New-Item -ItemType Directory -Path $Script:Config.DataFolder -Force | Out-Null
        }
        if ((Test-Path $Script:LogFile) -and (Get-Item $Script:LogFile).Length -gt 512000) {
            $old = $Script:LogFile -replace '\.log$', '.old.log'
            Move-Item -Path $Script:LogFile -Destination $old -Force -ErrorAction SilentlyContinue
        }
        Add-Content -Path $Script:LogFile -Value $line -ErrorAction SilentlyContinue
    } catch {}
    Write-Host $line
}

# ----- PREFERENCE FILE (external config) -------------------------------------
# Congregation-editable settings live in a plain-text file in My Documents so
# they can be tweaked in Notepad without touching this script. $Script:Config
# above still holds the in-memory defaults/schema; the file (if present)
# overrides it. Right-hand sides are real PowerShell expressions (so paths like
# `(Join-Path $env:APPDATA "Zoom\bin\Zoom.exe")` work), evaluated with
# Invoke-Expression -- this file is local and only ever edited by the operator
# or through this app's own Settings menu, the same trust level as a PS profile.
$Script:ConfigDir  = Join-Path ([Environment]::GetFolderPath('MyDocuments')) "Preflight Settings"
$Script:ConfigFile = Join-Path $Script:ConfigDir "Preflight.conf"
$Script:SelfPath   = if ($PSCommandPath) { $PSCommandPath } else { $MyInvocation.MyCommand.Path }

function ConvertTo-ConfigValueLiteral {
    param($Value)
    if ($Value -is [bool]) { if ($Value) { '$true' } else { '$false' } }
    elseif ($Value -is [int] -or $Value -is [double]) { $Value.ToString() }
    else { '"' + ($Value.ToString() -replace '"', '`"') + '"' }
}

function Import-PreflightConfig {
    param([string]$Path)
    if (-not (Test-Path $Path)) { return }
    foreach ($raw in (Get-Content -Path $Path -Encoding UTF8)) {
        $line = $raw.Trim()
        if (-not $line -or $line.StartsWith('#')) { continue }
        $eq = $line.IndexOf('=')
        if ($eq -lt 1) { continue }
        $key    = $line.Substring(0, $eq).Trim()
        $rawVal = $line.Substring($eq + 1).Trim()
        try { $Script:Config[$key] = Invoke-Expression $rawVal }
        catch { Write-Log "Preference file: couldn't read '$key' ($($_.Exception.Message))" "WARN" }
    }
}

function Export-PreflightConfig {
    # Writes a brand-new preference file from the current in-memory $Script:Config.
    # Only used once, by the first-run Setup Wizard -- after that,
    # Update-PreflightConfigFile does targeted line edits instead, so any
    # hand-edited or expression-based lines (like ZoomPath) are preserved.
    param([string]$Path)
    $keysInOrder = @(
        'CongregationName','TestMode','AdminMode','OnlyTMode','OnlyTWebPort','BluetoothMode',
        'BluetoothInstanceId','BluetoothDeviceName','ObsDynamicSceneMode','ObsProfile',
        'ObsSceneMidweek','ObsSceneWeekend','ZoomSelfHostingMode',
        'EmeetIntegMode','EmeetPath',
        'StageCountdownMode','StageCountdownPath','WebcamName','WebcamInstanceId',
        'JwLibraryShortcut','ObsPath','M3Path','ZoomPath','OnlyTPath','UsbAudioInstanceId'
    )
    $lines = foreach ($k in $keysInOrder) {
        "{0,-20}= {1}" -f $k, (ConvertTo-ConfigValueLiteral $Script:Config[$k])
    }
    $dir = Split-Path $Path -Parent
    if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
    Set-Content -Path $Path -Value $lines -Encoding UTF8
    Write-Log "Preference file created: $Path"
}

function Update-PreflightConfigFile {
    # Rewrites only the given keys in the existing preference file line-by-line,
    # leaving every other line untouched. Appends any key not already present.
    param([hashtable]$Updates, [string]$Path = $Script:ConfigFile)
    if (-not (Test-Path $Path)) { Export-PreflightConfig -Path $Path; return }
    $lines     = @(Get-Content -Path $Path -Encoding UTF8)
    $remaining = $Updates.Clone()
    for ($i = 0; $i -lt $lines.Count; $i++) {
        $trimmed = $lines[$i].Trim()
        if (-not $trimmed -or $trimmed.StartsWith('#')) { continue }
        $eq = $trimmed.IndexOf('=')
        if ($eq -lt 1) { continue }
        $key = $trimmed.Substring(0, $eq).Trim()
        if ($remaining.ContainsKey($key)) {
            $lines[$i] = "{0,-20}= {1}" -f $key, (ConvertTo-ConfigValueLiteral $remaining[$key])
            $remaining.Remove($key)
        }
    }
    if ($remaining.Count -gt 0) {
        $lines += foreach ($k in $remaining.Keys) { "{0,-20}= {1}" -f $k, (ConvertTo-ConfigValueLiteral $remaining[$k]) }
    }
    Set-Content -Path $Path -Value $lines -Encoding UTF8
    Write-Log "Preference file updated: $($Updates.Keys -join ', ')"
}

$Script:NeedsInitialSetup = -not (Test-Path $Script:ConfigFile)
if (-not $Script:NeedsInitialSetup) {
    Import-PreflightConfig -Path $Script:ConfigFile
    $Script:LogFile        = Join-Path $Script:Config.DataFolder "preflight.log"
}

# ----- LAYOUT FILE (window position/size/order/timing overrides) -------------
# A second, separate file from Preflight.conf -- a plain Notepad-friendly table,
# one [Mode] section per launch mode, one row per app. Any field left out of a
# row falls back to the script's built-in default for that field (field-level
# merge), so a hand-edit can be as small as one number.
$Script:LayoutFile = Join-Path $Script:ConfigDir "Layout.conf"

# ----- POWERSHELL INTEGRATION (position/resolution capture) ------------------
function Get-WindowPosition {
    # Captures current window positions from running applications
    param([string]$ProcessName)
    
    try {
        $processes = Get-Process -Name $ProcessName -ErrorAction SilentlyContinue | Where-Object { $_.MainWindowHandle -ne 0 }
        if (-not $processes) { return $null }
        
        $proc = $processes[0]  # Take first matching process
        $handle = $proc.MainWindowHandle
        
        if ($handle -eq 0) { return $null }
        
        # Get window rectangle using Windows API
        $rect = New-Object Win32Native+RECT
        if ([Win32Native]::GetWindowRect($handle, [ref]$rect)) {
            return @{
                X = $rect.Left
                Y = $rect.Top  
                W = $rect.Right - $rect.Left
                H = $rect.Bottom - $rect.Top
            }
        }
    } catch {
        Write-Log "Error getting window position for $ProcessName`: $($_.Exception.Message)" "WARN"
    }
    return $null
}

function Get-ScreenResolution {
    # Gets current primary screen resolution
    try {
        $screen = [System.Windows.Forms.Screen]::PrimaryScreen
        return @{
            Width = $screen.Bounds.Width
            Height = $screen.Bounds.Height
            WorkingWidth = $screen.WorkingArea.Width
            WorkingHeight = $screen.WorkingArea.Height
        }
    } catch {
        Write-Log "Error getting screen resolution: $($_.Exception.Message)" "WARN"
        return @{ Width = 1920; Height = 1080; WorkingWidth = 1920; WorkingHeight = 1040 }
    }
}

function Get-AllAppPositions {
    # Captures positions of all known applications
    $positions = @{}
    $processMap = @{
        "Obs" = @("obs64", "obs-studio", "obs")
        "Zoom" = @("Zoom", "CptHost")  
        "M3" = @("Meeting Media Manager", "M3")
        "OnlyT" = @("OnlyT")
        "Emeet" = @("EMEET STUDIO")
    }
    
    foreach ($app in $processMap.Keys) {
        foreach ($processName in $processMap[$app]) {
            $pos = Get-WindowPosition -ProcessName $processName
            if ($pos) {
                $positions[$app] = $pos
                Write-Log "Captured position for $app`: $($pos.X),$($pos.Y) $($pos.W)x$($pos.H)"
                break
            }
        }
    }
    
    return $positions
}

function Import-PreflightLayoutOverrides {
    param([string]$Path)
    $overrides = @{}
    if (-not (Test-Path $Path)) { return $overrides }
    $currentMode = $null
    foreach ($raw in (Get-Content -Path $Path -Encoding UTF8)) {
        $line = $raw.Trim()
        if (-not $line -or $line.StartsWith('#')) { continue }
        if ($line -match '^\[(.+)\]$') {
            $currentMode = $Matches[1].Trim()
            if (-not $overrides.ContainsKey($currentMode)) { $overrides[$currentMode] = @{} }
            continue
        }
        if (-not $currentMode) { continue }
        $tokens = $line -split '\s+'
        if ($tokens.Count -lt 1) { continue }
        $appName = $tokens[0]
        $fields  = @{}
        for ($i = 1; $i -lt $tokens.Count; $i++) {
            if ($tokens[$i] -match '^(App|Order|X|Y|W|H|DelayMs)=(-?\d+)$') {
                $fields[$Matches[1]] = [int]$Matches[2]
            }
        }
        if (-not $overrides[$currentMode].ContainsKey($appName)) { $overrides[$currentMode][$appName] = @{} }
        foreach ($f in $fields.Keys) { $overrides[$currentMode][$appName][$f] = $fields[$f] }
    }
    return $overrides
}

function Save-PreflightLayoutMode {
    # Replaces one [Mode] section in Layout.conf with a fresh, complete set of
    # rows (used when the Settings > Layout editor saves a mode the operator
    # actually touched) -- every other mode's section is left untouched.
    param([string]$ModeName, [array]$Rows, [string]$Path = $Script:LayoutFile)
    $newSection = @("[$ModeName]")
    foreach ($r in ($Rows | Sort-Object Order)) {
        $newSection += "{0,-8}Order={1}  X={2}  Y={3}  W={4}  H={5}  DelayMs={6}" -f `
            $r.App, $r.Order, $r.X, $r.Y, $r.W, $r.H, $r.DelayMs
    }

    $dir = Split-Path $Path -Parent
    if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }

    $existing = if (Test-Path $Path) { @(Get-Content -Path $Path -Encoding UTF8) } else { @() }
    $out = New-Object System.Collections.Generic.List[string]
    $inTargetSection = $false
    $replaced = $false
    foreach ($line in $existing) {
        $trimmed = $line.Trim()
        if ($trimmed -match '^\[(.+)\]$') {
            $isTarget = ($Matches[1].Trim() -eq $ModeName)
            if ($isTarget) {
                $out.AddRange([string[]]$newSection)
                $replaced = $true
            }
            $inTargetSection = $isTarget
            continue
        }
        if (-not $inTargetSection) { $out.Add($line) }
    }
    if (-not $replaced) {
        if ($out.Count -gt 0) { $out.Add("") }
        $out.AddRange([string[]]$newSection)
    }
    Set-Content -Path $Path -Value $out -Encoding UTF8
    Write-Log "Layout file: saved '$ModeName' ($($Rows.Count) apps)."
}

function Remove-PreflightLayoutMode {
    # "Reset to defaults" for one mode -- deletes its section entirely so the
    # script's built-in defaults take over again.
    param([string]$ModeName, [string]$Path = $Script:LayoutFile)
    if (-not (Test-Path $Path)) { return }
    $existing = @(Get-Content -Path $Path -Encoding UTF8)
    $out = New-Object System.Collections.Generic.List[string]
    $inTargetSection = $false
    foreach ($line in $existing) {
        $trimmed = $line.Trim()
        if ($trimmed -match '^\[(.+)\]$') {
            $inTargetSection = ($Matches[1].Trim() -eq $ModeName)
            if ($inTargetSection) { continue }
        }
        if (-not $inTargetSection) { $out.Add($line) }
    }
    Set-Content -Path $Path -Value $out -Encoding UTF8
    Write-Log "Layout file: reset '$ModeName' to script defaults."
}

$Script:LayoutOverrides = Import-PreflightLayoutOverrides -Path $Script:LayoutFile

# ----- PRE-FLIGHT CHECK ------------------------------------------------------
if ($Script:Config.TestMode) {
    Write-Log "=== TEST MODE -- pre-flight bypassed ==="
} else {
    if (Get-Process -Name "obs64" -ErrorAction SilentlyContinue) {
        Write-Log "OBS already running. Exiting silently."
        exit 0
    }
}
Write-Log "=== Audio-Video Preflight v5.4 (WTLC Edition) starting ==="

# ----- ASSEMBLIES ------------------------------------------------------------
Add-Type -AssemblyName PresentationFramework
Add-Type -AssemblyName PresentationCore
Add-Type -AssemblyName WindowsBase
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# ----- WIN32 -----------------------------------------------------------------
if (-not ([System.Management.Automation.PSTypeName]'Win32Native').Type) {
    Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public class Win32Native {
    [DllImport("user32.dll")] public static extern bool MoveWindow(IntPtr hWnd, int X, int Y, int W, int H, bool bRepaint);
    [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
    [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr hWnd);
    [DllImport("user32.dll")] public static extern bool AllowSetForegroundWindow(int dwProcessId);
    [DllImport("user32.dll")] public static extern bool SetWindowPos(IntPtr hWnd, IntPtr hWndInsertAfter, int X, int Y, int cx, int cy, uint uFlags);
    [DllImport("user32.dll")] public static extern void mouse_event(uint dwFlags, uint dx, uint dy, int dwData, uint dwExtraInfo);
    [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr hWnd, out RECT lpRect);
    [StructLayout(LayoutKind.Sequential)]
    public struct RECT { public int Left; public int Top; public int Right; public int Bottom; }
    public const int SW_RESTORE = 9;
    public const int SW_MINIMIZE = 6;
    public const int ASFW_ANY   = -1;
    public static readonly IntPtr HWND_BOTTOM = new IntPtr(1);
    public const uint SWP_NOSIZE     = 0x0001;
    public const uint SWP_NOMOVE     = 0x0002;
    public const uint SWP_NOACTIVATE = 0x0010;
    public const uint MOUSEEVENTF_LEFTDOWN = 0x0002;
    public const uint MOUSEEVENTF_LEFTUP   = 0x0004;
    public const uint MOUSEEVENTF_WHEEL    = 0x0800;
}
'@
}

# ----- ONLYT: MULTI-IP ACCESS CODES -----------------------------------------
function Get-OnlyTAccessCodes {
    # Returns @{ Wired = @(...); Wireless = @(...) } -- each entry is
    # @{ Code = "104"; IP = "192.168.254.104" }. Ethernet-derived codes are
    # kept separate from Wi-Fi-derived codes so the UI can prioritize Ethernet and
    # offer the Wi-Fi code as the fallback if the operator can't see the timer.
    $result = @{ Wired = @(); Wireless = @() }
    try {
        $adapters = Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue |
                    Where-Object {
                        $_.InterfaceAlias -notlike '*Loopback*' -and
                        $_.InterfaceAlias -notlike '*Bluetooth*' -and
                        $_.IPAddress      -match '^192\.168\.'  -and
                        $_.PrefixOrigin   -eq 'Dhcp'
                    }
        if (-not $adapters) {
            $adapters = Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue |
                        Where-Object { $_.IPAddress -match '^192\.168\.' }
        }
        foreach ($a in $adapters) {
            $entry = @{ Code = ($a.IPAddress -split '\.')[3]; IP = $a.IPAddress }
            if ($a.InterfaceAlias -match 'Wi-?Fi|Wireless') {
                $result.Wireless += $entry
                Write-Log "Wireless IPv4 detected: $($a.IPAddress)  ->  Access Code: $($entry.Code)"
            } else {
                $result.Wired += $entry
                Write-Log "Wired IPv4 detected: $($a.IPAddress)  ->  Access Code: $($entry.Code)"
            }
        }
        $result.Wired    = @($result.Wired    | Sort-Object -Property IP -Unique)
        $result.Wireless = @($result.Wireless | Sort-Object -Property IP -Unique)
        if (-not $result.Wired -and -not $result.Wireless) {
            Write-Log "No 192.168.x.x address found." "WARN"
        }
    } catch {
        Write-Log "Error reading IPv4: $($_.Exception.Message)" "ERROR"
    }
    return $result
}

function Format-AccessCodes {
    param([array]$Codes)
    if (-not $Codes -or $Codes.Count -eq 0) { return "---" }
    return (($Codes | ForEach-Object { $_.Code }) -join "  or  ")
}

function Format-WebPreviewAddresses {
    param([array]$Codes)
    if (-not $Codes -or $Codes.Count -eq 0) { return "---" }
    $urls = $Codes | ForEach-Object { "http://$($_.IP):$($Script:Config.OnlyTWebPort)/index" }
    return ($urls -join "`n")
}

# ----- BACKGROUND HARDWARE POLLING -------------------------------------------
$Script:HwRunspace   = $null
$Script:HwPowerShell = $null
$Script:HwHandle     = $null

function Start-HardwarePolling {
    if ($Script:Config.TestMode) { return }
    $Script:HwRunspace = [runspacefactory]::CreateRunspace()
    $Script:HwRunspace.ApartmentState = 'MTA'
    $Script:HwRunspace.Open()
    $Script:HwRunspace.SessionStateProxy.SetVariable('Cache',   $Script:HwCache)
    $Script:HwRunspace.SessionStateProxy.SetVariable('UsbId',   $Script:Config.UsbAudioInstanceId)
    $Script:HwRunspace.SessionStateProxy.SetVariable('CamId',   $Script:Config.WebcamInstanceId)
    $Script:HwRunspace.SessionStateProxy.SetVariable('PollSec', $Script:Config.PollIntervalSec)
    $Script:HwPowerShell = [powershell]::Create()
    $Script:HwPowerShell.Runspace = $Script:HwRunspace
    [void]$Script:HwPowerShell.AddScript({
        Add-Type -AssemblyName System.Windows.Forms -ErrorAction SilentlyContinue
        $pollCount = 0
        while ($Cache.Running) {
            try {
                $plStatus = [System.Windows.Forms.SystemInformation]::PowerStatus.PowerLineStatus
                if ($plStatus -eq 'Online') {
                    $Cache.AcPower = $true
                } elseif ($plStatus -eq 'Offline') {
                    $Cache.AcPower = $false
                } else {
                    # PowerLineStatus reported "Unknown" -- common on HP Victus/Omen EC firmware
                    # even while actively charging. Fall back to WMI battery status, which HP's
                    # embedded controller reports more reliably.
                    $batt = Get-CimInstance -ClassName Win32_Battery -ErrorAction Stop | Select-Object -First 1
                    if ($batt) {
                        # BatteryStatus: 2=AC line/on-line, 3=Fully charged, 6=Charging,
                        # 7=Charging+High, 8=Charging+Low, 9=Charging+Critical, 11=Partially charged
                        $Cache.AcPower = $batt.BatteryStatus -in 2,3,6,7,8,9,11
                    } else {
                        # No battery reported at all (desktop-like) -- treat as AC connected
                        $Cache.AcPower = $true
                    }
                }
            } catch { $Cache.AcPower = $false }
            try {
                $hasProfile = [bool](Get-NetConnectionProfile -ErrorAction Stop | Where-Object { $_.IPv4Connectivity -eq 'Internet' })
                if (-not $hasProfile) { $Cache.Internet = $false }
                elseif ($pollCount % 5 -eq 0) {
                    $p = New-Object System.Net.NetworkInformation.Ping
                    $Cache.Internet = ($p.Send("8.8.8.8", 1000).Status.ToString() -eq 'Success')
                    $p.Dispose()
                }
            } catch { $Cache.Internet = $false }
            try { $Cache.Display  = [System.Windows.Forms.Screen]::AllScreens.Count -gt 1 } catch { $Cache.Display  = $false }
            try { $Cache.Webcam   = [bool](Get-PnpDevice -PresentOnly -ErrorAction SilentlyContinue | Where-Object { $_.InstanceId -eq $CamId -and $_.Status -eq 'OK' }) } catch { $Cache.Webcam   = $false }
            try { $Cache.UsbAudio = [bool](Get-PnpDevice -PresentOnly -ErrorAction SilentlyContinue | Where-Object { $_.InstanceId -eq $UsbId -and $_.Status -eq 'OK' }) } catch { $Cache.UsbAudio = $false }
            $pollCount++
            Start-Sleep -Seconds $PollSec
        }
    })
    $Script:HwHandle = $Script:HwPowerShell.BeginInvoke()
    Write-Log "Background hardware polling started."
}

function Stop-HardwarePolling {
    try {
        $Script:HwCache.Running = $false
        if ($Script:HwPowerShell) {
            $Script:HwPowerShell.Stop()
            if ($Script:HwHandle) { try { $Script:HwPowerShell.EndInvoke($Script:HwHandle) } catch {} }
            $Script:HwPowerShell.Dispose()
        }
        if ($Script:HwRunspace) { $Script:HwRunspace.Close(); $Script:HwRunspace.Dispose() }
    } catch {}
}

# ----- HELPERS ---------------------------------------------------------------
function Get-DefaultMeetingType {
    $d = (Get-Date).DayOfWeek
    if ($d -eq 'Saturday' -or $d -eq 'Sunday') { 'Weekend' } else { 'Midweek' }
}
function Open-NetworkSettings { try { Start-Process "ms-settings:network-status" } catch {} }
function Open-DeviceManager   { try { Start-Process "devmgmt.msc"                } catch {} }

# =============================================================================
#  XAML
# =============================================================================
$xaml = @'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="Audio-Video Preflight"
        WindowStyle="None" ResizeMode="NoResize"
        WindowStartupLocation="Manual" Topmost="True"
        Background="#0D0F17" FontFamily="Segoe UI">

  <Window.Resources>

    <Style x:Key="BtnYes" TargetType="Button">
      <Setter Property="Background" Value="#166534"/>
      <Setter Property="Foreground" Value="#4ADE80"/>
      <Setter Property="FontSize" Value="15"/>
      <Setter Property="FontWeight" Value="SemiBold"/>
      <Setter Property="BorderThickness" Value="0"/>
      <Setter Property="Cursor" Value="Hand"/>
      <Setter Property="Padding" Value="44,17"/>
      <Setter Property="Template">
        <Setter.Value>
          <ControlTemplate TargetType="Button">
            <Border Background="{TemplateBinding Background}" CornerRadius="10" Padding="{TemplateBinding Padding}">
              <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/>
            </Border>
            <ControlTemplate.Triggers>
              <Trigger Property="IsMouseOver" Value="True"><Setter Property="Background" Value="#15803D"/></Trigger>
              <Trigger Property="IsPressed"   Value="True"><Setter Property="Background" Value="#14532D"/></Trigger>
            </ControlTemplate.Triggers>
          </ControlTemplate>
        </Setter.Value>
      </Setter>
    </Style>

    <Style x:Key="BtnGreen" TargetType="Button">
      <Setter Property="Background" Value="#15803D"/>
      <Setter Property="Foreground" Value="White"/>
      <Setter Property="FontSize" Value="16"/>
      <Setter Property="FontWeight" Value="Bold"/>
      <Setter Property="BorderThickness" Value="0"/>
      <Setter Property="Cursor" Value="Hand"/>
      <Setter Property="Padding" Value="44,17"/>
      <Setter Property="Template">
        <Setter.Value>
          <ControlTemplate TargetType="Button">
            <Border Background="{TemplateBinding Background}" CornerRadius="10" Padding="{TemplateBinding Padding}">
              <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/>
            </Border>
            <ControlTemplate.Triggers>
              <Trigger Property="IsMouseOver" Value="True"><Setter Property="Background" Value="#166534"/></Trigger>
              <Trigger Property="IsPressed"   Value="True"><Setter Property="Background" Value="#14532D"/></Trigger>
            </ControlTemplate.Triggers>
          </ControlTemplate>
        </Setter.Value>
      </Setter>
    </Style>

    <Style x:Key="BtnRed" TargetType="Button">
      <Setter Property="Background" Value="#DC2626"/>
      <Setter Property="Foreground" Value="White"/>
      <Setter Property="FontSize" Value="16"/>
      <Setter Property="FontWeight" Value="Bold"/>
      <Setter Property="BorderThickness" Value="0"/>
      <Setter Property="Cursor" Value="Hand"/>
      <Setter Property="Padding" Value="44,17"/>
      <Setter Property="Template">
        <Setter.Value>
          <ControlTemplate TargetType="Button">
            <Border Background="{TemplateBinding Background}" CornerRadius="10" Padding="{TemplateBinding Padding}">
              <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/>
            </Border>
            <ControlTemplate.Triggers>
              <Trigger Property="IsMouseOver" Value="True"><Setter Property="Background" Value="#B91C1C"/></Trigger>
              <Trigger Property="IsPressed"   Value="True"><Setter Property="Background" Value="#991B1B"/></Trigger>
            </ControlTemplate.Triggers>
          </ControlTemplate>
        </Setter.Value>
      </Setter>
    </Style>

    <Style x:Key="BtnStartOver" TargetType="Button">
      <Setter Property="Background" Value="#FF6B00"/>
      <Setter Property="Foreground" Value="#FFFFFF"/>
      <Setter Property="FontSize" Value="14"/>
      <Setter Property="FontWeight" Value="Bold"/>
      <Setter Property="BorderThickness" Value="0"/>
      <Setter Property="Cursor" Value="Hand"/>
      <Setter Property="Padding" Value="18,9"/>
      <Setter Property="Template">
        <Setter.Value>
          <ControlTemplate TargetType="Button">
            <Border Background="{TemplateBinding Background}" CornerRadius="8" Padding="{TemplateBinding Padding}">
              <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/>
            </Border>
            <ControlTemplate.Triggers>
              <Trigger Property="IsMouseOver" Value="True"><Setter Property="Background" Value="#E66000"/></Trigger>
              <Trigger Property="IsPressed"   Value="True"><Setter Property="Background" Value="#CC5500"/></Trigger>
            </ControlTemplate.Triggers>
          </ControlTemplate>
        </Setter.Value>
      </Setter>
    </Style>

    <Style x:Key="BtnShowHow" TargetType="Button">
      <Setter Property="Background" Value="#0F1929"/>
      <Setter Property="Foreground" Value="#60A5FA"/>
      <Setter Property="FontSize" Value="15"/>
      <Setter Property="FontWeight" Value="SemiBold"/>
      <Setter Property="BorderBrush" Value="#1E3A60"/>
      <Setter Property="BorderThickness" Value="1"/>
      <Setter Property="Cursor" Value="Hand"/>
      <Setter Property="Padding" Value="40,17"/>
      <Setter Property="Template">
        <Setter.Value>
          <ControlTemplate TargetType="Button">
            <Border Background="{TemplateBinding Background}" BorderBrush="{TemplateBinding BorderBrush}"
                    BorderThickness="{TemplateBinding BorderThickness}" CornerRadius="10" Padding="{TemplateBinding Padding}">
              <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/>
            </Border>
            <ControlTemplate.Triggers>
              <Trigger Property="IsMouseOver" Value="True"><Setter Property="Background" Value="#132040"/></Trigger>
              <Trigger Property="IsPressed"   Value="True"><Setter Property="Background" Value="#0E1A35"/></Trigger>
            </ControlTemplate.Triggers>
          </ControlTemplate>
        </Setter.Value>
      </Setter>
    </Style>

    <Style x:Key="BtnClose" TargetType="Button">
      <Setter Property="Background" Value="#1A1D2E"/>
      <Setter Property="Foreground" Value="#9CA3AF"/>
      <Setter Property="FontSize" Value="15"/>
      <Setter Property="FontWeight" Value="Bold"/>
      <Setter Property="BorderThickness" Value="0"/>
      <Setter Property="Cursor" Value="Hand"/>
      <Setter Property="Width" Value="44"/>
      <Setter Property="Height" Value="44"/>
      <Setter Property="Template">
        <Setter.Value>
          <ControlTemplate TargetType="Button">
            <Border Background="{TemplateBinding Background}" CornerRadius="22">
              <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/>
            </Border>
            <ControlTemplate.Triggers>
              <Trigger Property="IsMouseOver" Value="True">
                <Setter Property="Background" Value="#2A2D3E"/>
                <Setter Property="Foreground" Value="#F87171"/>
              </Trigger>
            </ControlTemplate.Triggers>
          </ControlTemplate>
        </Setter.Value>
      </Setter>
    </Style>

    <Style x:Key="BtnLaunch" TargetType="Button">
      <Setter Property="Background" Value="#15803D"/>
      <Setter Property="Foreground" Value="White"/>
      <Setter Property="FontSize" Value="18"/>
      <Setter Property="FontWeight" Value="Bold"/>
      <Setter Property="BorderThickness" Value="0"/>
      <Setter Property="Cursor" Value="Hand"/>
      <Setter Property="Padding" Value="0,22"/>
      <Setter Property="Template">
        <Setter.Value>
          <ControlTemplate TargetType="Button">
            <Border Background="{TemplateBinding Background}" CornerRadius="12" Padding="{TemplateBinding Padding}">
              <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/>
            </Border>
            <ControlTemplate.Triggers>
              <Trigger Property="IsMouseOver" Value="True"><Setter Property="Background" Value="#166534"/></Trigger>
              <Trigger Property="IsPressed"   Value="True"><Setter Property="Background" Value="#14532D"/></Trigger>
            </ControlTemplate.Triggers>
          </ControlTemplate>
        </Setter.Value>
      </Setter>
    </Style>

    <Style x:Key="BtnMeetingType" TargetType="RadioButton">
      <Setter Property="Cursor" Value="Hand"/>
      <Setter Property="FontSize" Value="14"/>
      <Setter Property="FontWeight" Value="SemiBold"/>
      <Setter Property="Template">
        <Setter.Value>
          <ControlTemplate TargetType="RadioButton">
            <Border x:Name="bd" Background="#161923" CornerRadius="10" Padding="36,14"
                    BorderBrush="#252836" BorderThickness="1">
              <TextBlock x:Name="tb" Text="{TemplateBinding Content}"
                         Foreground="#9CA3AF" FontSize="{TemplateBinding FontSize}"
                         FontWeight="{TemplateBinding FontWeight}"
                         HorizontalAlignment="Center" VerticalAlignment="Center"/>
            </Border>
            <ControlTemplate.Triggers>
              <Trigger Property="IsChecked" Value="True">
                <Setter TargetName="bd" Property="Background" Value="#0F2040"/>
                <Setter TargetName="bd" Property="BorderBrush" Value="#3D8EF0"/>
                <Setter TargetName="tb" Property="Foreground" Value="#60A5FA"/>
              </Trigger>
              <Trigger Property="IsMouseOver" Value="True">
                <Setter TargetName="bd" Property="Background" Value="#1C1F30"/>
              </Trigger>
            </ControlTemplate.Triggers>
          </ControlTemplate>
        </Setter.Value>
      </Setter>
    </Style>

    <Style x:Key="BtnHelp" TargetType="Button">
      <Setter Property="Background" Value="#1A1D2E"/>
      <Setter Property="Foreground" Value="#9CA3AF"/>
      <Setter Property="FontSize" Value="11"/>
      <Setter Property="FontWeight" Value="SemiBold"/>
      <Setter Property="BorderThickness" Value="0"/>
      <Setter Property="Cursor" Value="Hand"/>
      <Setter Property="Padding" Value="14,7"/>
      <Setter Property="Template">
        <Setter.Value>
          <ControlTemplate TargetType="Button">
            <Border Background="{TemplateBinding Background}" CornerRadius="6" Padding="{TemplateBinding Padding}">
              <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/>
            </Border>
            <ControlTemplate.Triggers>
              <Trigger Property="IsMouseOver" Value="True"><Setter Property="Background" Value="#252836"/></Trigger>
            </ControlTemplate.Triggers>
          </ControlTemplate>
        </Setter.Value>
      </Setter>
    </Style>

    <Style x:Key="BtnBack" TargetType="Button">
      <Setter Property="Background" Value="Transparent"/>
      <Setter Property="Foreground" Value="#4B5563"/>
      <Setter Property="FontSize" Value="12"/>
      <Setter Property="BorderThickness" Value="0"/>
      <Setter Property="Cursor" Value="Hand"/>
      <Setter Property="Padding" Value="0,8"/>
      <Setter Property="Template">
        <Setter.Value>
          <ControlTemplate TargetType="Button">
            <Border Background="{TemplateBinding Background}" Padding="{TemplateBinding Padding}">
              <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/>
            </Border>
            <ControlTemplate.Triggers>
              <Trigger Property="IsMouseOver" Value="True"><Setter Property="Foreground" Value="#9CA3AF"/></Trigger>
            </ControlTemplate.Triggers>
          </ControlTemplate>
        </Setter.Value>
      </Setter>
    </Style>

    <Style x:Key="BtnGear" TargetType="Button">
      <Setter Property="Background" Value="#1A1D2E"/>
      <Setter Property="Foreground" Value="#9CA3AF"/>
      <Setter Property="FontSize" Value="14"/>
      <Setter Property="FontWeight" Value="SemiBold"/>
      <Setter Property="BorderThickness" Value="0"/>
      <Setter Property="Cursor" Value="Hand"/>
      <Setter Property="Padding" Value="16,9"/>
      <Setter Property="Template">
        <Setter.Value>
          <ControlTemplate TargetType="Button">
            <Border Background="{TemplateBinding Background}" CornerRadius="8" Padding="{TemplateBinding Padding}">
              <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/>
            </Border>
            <ControlTemplate.Triggers>
              <Trigger Property="IsMouseOver" Value="True"><Setter Property="Background" Value="#252836"/></Trigger>
              <Trigger Property="IsPressed"   Value="True"><Setter Property="Background" Value="#2A2D3E"/></Trigger>
            </ControlTemplate.Triggers>
          </ControlTemplate>
        </Setter.Value>
      </Setter>
    </Style>

    <Style x:Key="ToggleSwitchStyle" TargetType="CheckBox">
      <Setter Property="Cursor" Value="Hand"/>
      <Setter Property="Template">
        <Setter.Value>
          <ControlTemplate TargetType="CheckBox">
            <Border x:Name="Track" Width="52" Height="28" CornerRadius="14"
                    Background="#252836" BorderBrush="#333748" BorderThickness="1">
              <Border x:Name="Thumb" Width="22" Height="22" CornerRadius="11"
                      Background="#6B7280" HorizontalAlignment="Left" Margin="2,0,0,0"/>
            </Border>
            <ControlTemplate.Triggers>
              <Trigger Property="IsChecked" Value="True">
                <Setter TargetName="Track" Property="Background"  Value="#1D4ED8"/>
                <Setter TargetName="Track" Property="BorderBrush" Value="#3D8EF0"/>
                <Setter TargetName="Thumb" Property="Background"  Value="#FFFFFF"/>
                <Setter TargetName="Thumb" Property="HorizontalAlignment" Value="Right"/>
                <Setter TargetName="Thumb" Property="Margin" Value="0,0,2,0"/>
              </Trigger>
              <Trigger Property="IsMouseOver" Value="True">
                <Setter TargetName="Track" Property="BorderBrush" Value="#4B5563"/>
              </Trigger>
            </ControlTemplate.Triggers>
          </ControlTemplate>
        </Setter.Value>
      </Setter>
    </Style>

    <Style x:Key="SettingsTextBox" TargetType="TextBox">
      <Setter Property="Background" Value="#161923"/>
      <Setter Property="Foreground" Value="#E8EAF0"/>
      <Setter Property="CaretBrush" Value="#E8EAF0"/>
      <Setter Property="BorderBrush" Value="#252836"/>
      <Setter Property="BorderThickness" Value="1"/>
      <Setter Property="Padding" Value="14,10"/>
      <Setter Property="FontSize" Value="16"/>
      <Setter Property="Template">
        <Setter.Value>
          <ControlTemplate TargetType="TextBox">
            <Border Background="{TemplateBinding Background}" BorderBrush="{TemplateBinding BorderBrush}"
                    BorderThickness="{TemplateBinding BorderThickness}" CornerRadius="8">
              <ScrollViewer x:Name="PART_ContentHost" Margin="{TemplateBinding Padding}" VerticalAlignment="Center"/>
            </Border>
          </ControlTemplate>
        </Setter.Value>
      </Setter>
    </Style>

    <Style x:Key="LayoutPillTextBox" TargetType="TextBox">
      <Setter Property="Background" Value="#161923"/>
      <Setter Property="Foreground" Value="#E8EAF0"/>
      <Setter Property="CaretBrush" Value="#E8EAF0"/>
      <Setter Property="BorderBrush" Value="#252836"/>
      <Setter Property="BorderThickness" Value="1"/>
      <Setter Property="Padding" Value="10,6"/>
      <Setter Property="FontSize" Value="14"/>
      <Setter Property="FontWeight" Value="SemiBold"/>
      <Setter Property="TextAlignment" Value="Center"/>
      <Setter Property="Template">
        <Setter.Value>
          <ControlTemplate TargetType="TextBox">
            <Border Background="{TemplateBinding Background}" BorderBrush="{TemplateBinding BorderBrush}"
                    BorderThickness="{TemplateBinding BorderThickness}" CornerRadius="16">
              <ScrollViewer x:Name="PART_ContentHost" Margin="{TemplateBinding Padding}" VerticalAlignment="Center"/>
            </Border>
          </ControlTemplate>
        </Setter.Value>
      </Setter>
    </Style>

    <Style x:Key="LayoutOrderBtn" TargetType="Button">
      <Setter Property="Background" Value="#161923"/>
      <Setter Property="Foreground" Value="#9CA3AF"/>
      <Setter Property="FontSize" Value="13"/>
      <Setter Property="FontWeight" Value="Bold"/>
      <Setter Property="BorderThickness" Value="0"/>
      <Setter Property="Cursor" Value="Hand"/>
      <Setter Property="Width" Value="30"/>
      <Setter Property="Height" Value="22"/>
      <Setter Property="Template">
        <Setter.Value>
          <ControlTemplate TargetType="Button">
            <Border Background="{TemplateBinding Background}" CornerRadius="5">
              <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/>
            </Border>
            <ControlTemplate.Triggers>
              <Trigger Property="IsMouseOver" Value="True"><Setter Property="Background" Value="#252836"/></Trigger>
            </ControlTemplate.Triggers>
          </ControlTemplate>
        </Setter.Value>
      </Setter>
    </Style>

  </Window.Resources>

  <Grid>
    <Grid.RowDefinitions>
      <RowDefinition Height="84"/>
      <RowDefinition Height="*"/>
      <RowDefinition Height="56"/>
    </Grid.RowDefinitions>
    <Grid.ColumnDefinitions>
      <ColumnDefinition Width="120"/>
      <ColumnDefinition Width="*"/>
    </Grid.ColumnDefinitions>

    <!-- HEADER -->
    <Border Grid.Row="0" Grid.ColumnSpan="2" Background="#090B12" BorderBrush="#181B26" BorderThickness="0,0,0,1">
      <Grid Margin="32,0">
        <StackPanel Orientation="Horizontal" VerticalAlignment="Center">
          <Button x:Name="BtnSettings" Content="⚙ Settings" Style="{StaticResource BtnGear}" Margin="0,0,20,0"/>
          <Button x:Name="BtnStartOver" Content="Start Over" Style="{StaticResource BtnStartOver}"
                  Visibility="Collapsed" Margin="0,0,20,0"/>
          <Ellipse Width="8" Height="8" Fill="#3D8EF0" Margin="0,0,10,0" VerticalAlignment="Center"/>
          <TextBlock x:Name="HeaderTitle" Text="Audio-Video Preflight"
                     Foreground="#E8EAF0" FontSize="23" FontWeight="SemiBold" VerticalAlignment="Center"/>
        </StackPanel>
        <StackPanel Orientation="Horizontal" HorizontalAlignment="Right" VerticalAlignment="Center">
          <Border x:Name="MeetingTypeBadge" Visibility="Collapsed"
                  Background="#0F2040" CornerRadius="12" Padding="14,5" Margin="0,0,18,0">
            <TextBlock x:Name="MeetingTypeBadgeText" Text="MIDWEEK"
                       Foreground="#60A5FA" FontSize="17" FontWeight="Bold"/>
          </Border>
          <TextBlock x:Name="ClockText" Text="" Foreground="#374151" FontSize="20" VerticalAlignment="Center"/>
        </StackPanel>
      </Grid>
    </Border>

    <Border x:Name="TestModeBanner" Grid.Row="0" Grid.ColumnSpan="2" Background="#78350F"
            VerticalAlignment="Bottom" Height="26" Visibility="Collapsed">
      <TextBlock Text="TEST MODE  —  HARDWARE DETECTION BYPASSED"
                 Foreground="#FCD34D" FontSize="15" FontWeight="Bold"
                 HorizontalAlignment="Center" VerticalAlignment="Center"/>
    </Border>

    <!-- SIDEBAR -->
    <Border Grid.Row="1" Grid.Column="0" Background="#090B12" BorderBrush="#181B26" BorderThickness="0,0,1,0">
      <StackPanel x:Name="SubwayTrack"
                  HorizontalAlignment="Center" VerticalAlignment="Top"
                  Margin="0,36,0,0"/>
    </Border>

    <!-- USE CASE SCREEN -->
    <Grid x:Name="ScreenUseCase" Grid.Row="1" Grid.Column="1" Visibility="Collapsed">
      <StackPanel HorizontalAlignment="Center" VerticalAlignment="Center" Width="920">
        <TextBlock Text="What are you setting up today?"
                   Foreground="#F1F5F9" FontSize="35" FontWeight="SemiBold" TextWrapping="Wrap" Margin="0,0,0,10"/>
        <TextBlock Text="Choose how this laptop should be configured for today's meeting."
                   Foreground="#4B5563" FontSize="20" TextWrapping="Wrap" Margin="0,0,0,30"/>
        <Border Background="#0F1118" CornerRadius="16" Padding="36,32" Margin="0,0,0,20">
          <Grid>
            <Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions>
            <StackPanel Grid.Column="0" Margin="0,0,24,0">
              <TextBlock Text="Regular Meeting" Foreground="#F1F5F9" FontSize="28" FontWeight="Bold" Margin="0,0,0,12"/>
              <TextBlock Foreground="#9CA3AF" FontSize="18" Margin="0,0,0,4" TextWrapping="Wrap"><Run Text="• Hosts Midweek and Weekend Meetings."/></TextBlock>
              <TextBlock Foreground="#9CA3AF" FontSize="18" Margin="0,0,0,4" TextWrapping="Wrap"><Run Text="• Applies default audio and visual setup."/></TextBlock>
              <TextBlock Foreground="#9CA3AF" FontSize="18" TextWrapping="Wrap"><Run Text="• Configures Zoom, OBS, OnlyT, and Meeting Media Manager."/></TextBlock>
            </StackPanel>
            <Button x:Name="BtnUseCaseRegular" Grid.Column="1" Content="Select" Style="{StaticResource BtnYes}" VerticalAlignment="Center"/>
          </Grid>
        </Border>
        <Border Background="#0F1118" CornerRadius="16" Padding="36,32">
          <Grid>
            <Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions>
            <StackPanel Grid.Column="0" Margin="0,0,24,0">
              <TextBlock Text="Non-Zoom Meeting" Foreground="#F1F5F9" FontSize="28" FontWeight="Bold" Margin="0,0,0,12"/>
              <TextBlock Foreground="#9CA3AF" FontSize="18" Margin="0,0,0,4" TextWrapping="Wrap"><Run Text="• Displays media for PSS, SCE, Pioneer's, and Elders &amp; MS meetings."/></TextBlock>
              <TextBlock Foreground="#9CA3AF" FontSize="18" Margin="0,0,0,4" TextWrapping="Wrap"><Run Text="• Ideal for any gathering that does not require Zoom."/></TextBlock>
              <TextBlock Foreground="#9CA3AF" FontSize="18" TextWrapping="Wrap"><Run Text="• Configures the laptop specifically for local/offline use."/></TextBlock>
            </StackPanel>
            <Button x:Name="BtnUseCaseNonZoom" Grid.Column="1" Content="Select" Style="{StaticResource BtnYes}" VerticalAlignment="Center"/>
          </Grid>
        </Border>
      </StackPanel>
    </Grid>

    <!-- ZOOM CHOICE SCREEN -->
    <Grid x:Name="ScreenZoomChoice" Grid.Row="1" Grid.Column="1" Visibility="Collapsed">
      <StackPanel HorizontalAlignment="Center" VerticalAlignment="Center" Width="920">
        <TextBlock Text="Are you hosting or joining today's meeting?"
                   Foreground="#F1F5F9" FontSize="35" FontWeight="SemiBold" TextWrapping="Wrap" Margin="0,0,0,10"/>
        <TextBlock Text="Choose how this laptop connects to Zoom for today's meeting."
                   Foreground="#4B5563" FontSize="20" TextWrapping="Wrap" Margin="0,0,0,30"/>
        <Border Background="#0F1118" CornerRadius="16" Padding="36,32" Margin="0,0,0,20">
          <Grid>
            <Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions>
            <TextBlock Grid.Column="0" Text="I will Host Zoom from this Laptop"
                       Foreground="#F1F5F9" FontSize="28" FontWeight="Bold"
                       VerticalAlignment="Center" TextWrapping="Wrap" Margin="0,0,24,0"/>
            <Button x:Name="BtnZoomModeHost" Grid.Column="1" Content="Select" Style="{StaticResource BtnYes}" VerticalAlignment="Center"/>
          </Grid>
        </Border>
        <Border Background="#0F1118" CornerRadius="16" Padding="36,32">
          <Grid>
            <Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions>
            <StackPanel Grid.Column="0" Margin="0,0,24,0">
              <TextBlock Text="This Laptop will join a Zoom Meeting"
                         Foreground="#F1F5F9" FontSize="28" FontWeight="Bold" Margin="0,0,0,12" TextWrapping="Wrap"/>
              <TextBlock Foreground="#9CA3AF" FontSize="18" Margin="0,0,0,4" TextWrapping="Wrap"><Run Text="• You will join your congregation's Zoom Meeting"/></TextBlock>
              <TextBlock Foreground="#F87171" FontSize="18" TextWrapping="Wrap">
                <Run Text="• " FontWeight="Bold"/>
                <Run Text="This laptop will need to be assigned as HOST or CO-HOST" FontWeight="Bold"/>
              </TextBlock>
            </StackPanel>
            <Button x:Name="BtnZoomModeJoin" Grid.Column="1" Content="Select" Style="{StaticResource BtnYes}" VerticalAlignment="Center"/>
          </Grid>
        </Border>
      </StackPanel>
    </Grid>

    <!-- PROGRAM CHOICE SCREEN -->
    <Grid x:Name="ScreenProgramChoice" Grid.Row="1" Grid.Column="1" Visibility="Collapsed">
      <StackPanel HorizontalAlignment="Center" VerticalAlignment="Center" Width="920">
        <TextBlock Text="Which program will you use?"
                   Foreground="#F1F5F9" FontSize="35" FontWeight="SemiBold" TextWrapping="Wrap" Margin="0,0,0,10"/>
        <TextBlock Text="Preflight will launch only the one program you pick."
                   Foreground="#4B5563" FontSize="20" TextWrapping="Wrap" Margin="0,0,0,30"/>
        <Border Background="#0F1118" CornerRadius="16" Padding="36,32" Margin="0,0,0,20">
          <Grid>
            <Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions>
            <TextBlock Grid.Column="0" Text="Meeting Media Manager"
                       Foreground="#F1F5F9" FontSize="28" FontWeight="Bold"
                       VerticalAlignment="Center" TextWrapping="Wrap" Margin="0,0,24,0"/>
            <Button x:Name="BtnProgramM3" Grid.Column="1" Content="Select" Style="{StaticResource BtnYes}" VerticalAlignment="Center"/>
          </Grid>
        </Border>
        <Border Background="#0F1118" CornerRadius="16" Padding="36,32">
          <Grid>
            <Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions>
            <StackPanel Grid.Column="0" Margin="0,0,24,0">
              <TextBlock Text="JW Library" Foreground="#F1F5F9" FontSize="28" FontWeight="Bold" Margin="0,0,0,8" TextWrapping="Wrap"/>
              <TextBlock Foreground="#9CA3AF" FontSize="18" TextWrapping="Wrap"><Run Text="• Microsoft Store app"/></TextBlock>
            </StackPanel>
            <Button x:Name="BtnProgramJwLibrary" Grid.Column="1" Content="Select" Style="{StaticResource BtnYes}" VerticalAlignment="Center"/>
          </Grid>
        </Border>
      </StackPanel>
    </Grid>

    <!-- ZOOM INTRO SCREEN -->
    <Grid x:Name="ScreenZoomIntro" Grid.Row="1" Grid.Column="1" Visibility="Collapsed">
      <StackPanel HorizontalAlignment="Left" VerticalAlignment="Center" Width="640" Margin="80,0,0,0">
        <Border Background="#0F1118" CornerRadius="16" Padding="52,46">
          <StackPanel>
            <TextBlock x:Name="ZoomIntroHeading" Text="First, let's start Zoom"
                       Foreground="#F1F5F9" FontSize="35" FontWeight="SemiBold"
                       TextWrapping="Wrap" Margin="0,0,0,12"/>
            <TextBlock x:Name="ZoomIntroSubtext"
                       Text="• Click Open Zoom below&#10;• Start today's meeting&#10;• Come back here once it has started"
                       Foreground="#4B5563" FontSize="20" TextWrapping="Wrap" Margin="0,0,0,34"/>
            <StackPanel Orientation="Horizontal">
              <Button x:Name="BtnOpenZoomIntro" Content="Open Zoom" Style="{StaticResource BtnYes}" Margin="0,0,14,0"/>
              <Button x:Name="BtnZoomIntroContinue" Content="&#9654;   Continue"
                      Style="{StaticResource BtnShowHow}" Visibility="Collapsed"/>
            </StackPanel>
          </StackPanel>
        </Border>
      </StackPanel>
    </Grid>

    <!-- QUESTIONS SCREEN -->
    <Grid x:Name="ScreenQuestion" Grid.Row="1" Grid.Column="1" Visibility="Collapsed">
      <StackPanel HorizontalAlignment="Center" VerticalAlignment="Center">

        <StackPanel Orientation="Horizontal" HorizontalAlignment="Center" Margin="0,0,0,26">
          <Border Background="#111929" CornerRadius="20" Padding="16,6">
            <TextBlock x:Name="SectionBadgeText" Text="ZOOM SETUP" Foreground="#60A5FA" FontSize="17" FontWeight="Bold"/>
          </Border>
          <TextBlock x:Name="QuestionCounter" Text="  —  1 of 2"
                     Foreground="#374151" FontSize="20" VerticalAlignment="Center"/>
        </StackPanel>

        <StackPanel x:Name="DotsPanel" Orientation="Horizontal"
                    HorizontalAlignment="Center" Margin="0,0,0,34"/>

        <!-- Zoom card -->
        <Border x:Name="QuestionCardZoom" Background="#0F1118" CornerRadius="16" Padding="60,54" Width="780">
          <StackPanel>
            <TextBlock x:Name="QuestionText"
                       Foreground="#F1F5F9" FontSize="35" FontWeight="SemiBold"
                       TextWrapping="Wrap" TextAlignment="Center" Margin="0,0,0,12"/>
            <TextBlock x:Name="QuestionSubtext"
                       Foreground="#4B5563" FontSize="20"
                       TextWrapping="Wrap" TextAlignment="Center" Margin="0,0,0,42"/>
            <StackPanel Orientation="Horizontal" HorizontalAlignment="Center">
              <Button x:Name="BtnYes"     Content="&#10003;   Yes"         Style="{StaticResource BtnYes}"     Margin="0,0,14,0"/>
              <Button x:Name="BtnShowHow" Content="&#9654;   Show me how"  Style="{StaticResource BtnShowHow}" Visibility="Collapsed"/>
            </StackPanel>
          </StackPanel>
        </Border>

        <!-- Equipment card -->
        <Border x:Name="QuestionCardEquipment" Background="#0F1118" CornerRadius="16" Visibility="Collapsed">
          <Grid>
            <Grid.ColumnDefinitions>
              <ColumnDefinition Width="540"/>
              <ColumnDefinition Width="Auto"/>
            </Grid.ColumnDefinitions>
            <StackPanel Grid.Column="0" VerticalAlignment="Center" Margin="56,52">
              <TextBlock x:Name="EqQuestionText"
                         Foreground="#F1F5F9" FontSize="35" FontWeight="SemiBold"
                         TextWrapping="Wrap" Margin="0,0,0,12"/>
              <TextBlock x:Name="EqQuestionSubtext"
                         Foreground="#4B5563" FontSize="20"
                         TextWrapping="Wrap" Margin="0,0,0,36"/>
              <Button x:Name="BtnYesEq" Content="&#10003;   Yes"
                      Style="{StaticResource BtnYes}" HorizontalAlignment="Left"/>
            </StackPanel>
            <Border Grid.Column="1" Width="560" Height="560" CornerRadius="12"
                    Margin="0,28,28,28" Background="#07090E" ClipToBounds="True">
              <Image x:Name="EqPhotoImage" Stretch="UniformToFill"/>
            </Border>
          </Grid>
        </Border>

        <TextBlock x:Name="VideoErrorText" Foreground="#F87171" FontSize="18"
                   HorizontalAlignment="Center" Margin="0,14,0,0" Visibility="Collapsed"/>
      </StackPanel>
    </Grid>

    <!-- BLUETOOTH SETUP SCREEN (only shown when BluetoothMode is true) -->
    <Grid x:Name="ScreenBluetoothSetup" Grid.Row="1" Grid.Column="1" Visibility="Collapsed">
      <StackPanel HorizontalAlignment="Center" VerticalAlignment="Center">

        <StackPanel Orientation="Horizontal" HorizontalAlignment="Center" Margin="0,0,0,26">
          <Border Background="#111929" CornerRadius="20" Padding="16,6">
            <TextBlock Text="EQUIPMENT CHECK" Foreground="#60A5FA" FontSize="17" FontWeight="Bold"/>
          </Border>
        </StackPanel>

        <!-- Sub-question 1: Mixer Bluetooth on? -->
        <Border x:Name="BtSubQ1Panel" Background="#0F1118" CornerRadius="16">
          <Grid>
            <Grid.ColumnDefinitions>
              <ColumnDefinition Width="540"/>
              <ColumnDefinition Width="Auto"/>
            </Grid.ColumnDefinitions>
            <StackPanel Grid.Column="0" VerticalAlignment="Center" Margin="56,52">
              <TextBlock Text="Is the Mixer's Bluetooth turned on?"
                         Foreground="#F1F5F9" FontSize="35" FontWeight="SemiBold"
                         TextWrapping="Wrap" Margin="0,0,0,12"/>
              <TextBlock Foreground="#4B5563" FontSize="20" TextWrapping="Wrap" Margin="0,0,0,36">
                <Run Text="&#8226; Refer to the picture for how to turn on Bluetooth on the mixer"/>
              </TextBlock>
              <Button x:Name="BtnBtSubQ1Yes" Content="&#10003;   Yes"
                      Style="{StaticResource BtnYes}" HorizontalAlignment="Left"/>
            </StackPanel>
            <Border Grid.Column="1" Width="560" Height="560" CornerRadius="12"
                    Margin="0,28,28,28" Background="#07090E" ClipToBounds="True">
              <Image x:Name="BtMixerPhotoImage" Stretch="UniformToFill"/>
            </Border>
          </Grid>
        </Border>

        <!-- Sub-question 2: Connect laptop + verify -->
        <Border x:Name="BtSubQ2Panel" Background="#0F1118" CornerRadius="16" Visibility="Collapsed">
          <Grid>
            <Grid.ColumnDefinitions>
              <ColumnDefinition Width="540"/>
              <ColumnDefinition Width="Auto"/>
            </Grid.ColumnDefinitions>
            <StackPanel Grid.Column="0" VerticalAlignment="Center" Margin="56,52">
              <TextBlock Text="CHECK THE SETTINGS" Foreground="#60A5FA" FontSize="17" FontWeight="Bold" Margin="0,0,0,16"/>
              <TextBlock Text="Are you connected to the Bluetooth?"
                         Foreground="#F1F5F9" FontSize="35" FontWeight="SemiBold"
                         TextWrapping="Wrap" Margin="0,0,0,12"/>
              <TextBlock Foreground="#4B5563" FontSize="20" TextWrapping="Wrap" Margin="0,0,0,20">
                <Run Text="&#8226; "/><Run Text="Bluetooth Device Name: " FontWeight="Bold" Foreground="#9CA3AF"/><Run x:Name="BtDeviceNameRun" Text="" FontWeight="Bold" Foreground="#E8EAF0"/>
              </TextBlock>
              <TextBlock x:Name="BtCheckStatusText" Foreground="#F87171" FontSize="17"
                         TextWrapping="Wrap" Margin="0,0,0,20" Visibility="Collapsed"/>
              <StackPanel Orientation="Horizontal" HorizontalAlignment="Left">
                <Button x:Name="BtnBluetoothCheck" Content="&#10003;   Check"
                        Style="{StaticResource BtnYes}" Margin="0,0,14,0"/>
                <Button x:Name="BtnBtNotConnected" Content="Not Connected"
                        Style="{StaticResource BtnShowHow}"/>
              </StackPanel>
            </StackPanel>
            <Border x:Name="BtSettingsAnchor" Grid.Column="1" Width="560" Height="560" CornerRadius="12"
                    Margin="0,28,28,28" Background="#07090E" ClipToBounds="True">
              <TextBlock Text="Opening Bluetooth Settings..." Foreground="#374151" FontSize="16"
                         HorizontalAlignment="Center" VerticalAlignment="Center" TextWrapping="Wrap"/>
            </Border>
          </Grid>
        </Border>

        <!-- Sub-question 2 (not connected): reconnect instructions -->
        <Border x:Name="BtInstructionsPanel" Background="#0F1118" CornerRadius="16" Padding="56,52" Width="780" Visibility="Collapsed">
          <StackPanel>
            <TextBlock Text="Let's reconnect the Bluetooth"
                       Foreground="#F1F5F9" FontSize="35" FontWeight="SemiBold"
                       TextWrapping="Wrap" Margin="0,0,0,24"/>
            <TextBlock Foreground="#D1D5DB" FontSize="18" TextWrapping="Wrap" Margin="0,0,0,10">
              <Run Foreground="#60A5FA" FontWeight="Bold" Text="1.  "/>
              <Run Text="Make sure the mixer's Bluetooth light is blinking red."/>
            </TextBlock>
            <TextBlock Foreground="#D1D5DB" FontSize="18" TextWrapping="Wrap" Margin="0,0,0,10">
              <Run Foreground="#60A5FA" FontWeight="Bold" Text="2.  "/>
              <Run Text="Click Add Device."/>
            </TextBlock>
            <TextBlock Foreground="#D1D5DB" FontSize="18" TextWrapping="Wrap" Margin="0,0,0,10">
              <Run Foreground="#60A5FA" FontWeight="Bold" Text="3.  "/>
              <Run Text="Click Bluetooth."/>
            </TextBlock>
            <TextBlock Foreground="#D1D5DB" FontSize="18" TextWrapping="Wrap" Margin="0,0,0,32">
              <Run Foreground="#60A5FA" FontWeight="Bold" Text="4.  "/>
              <Run Text="Click WN_Audio."/>
            </TextBlock>
            <StackPanel Orientation="Horizontal">
              <Button x:Name="BtnBtSkip" Content="Skip" Style="{StaticResource BtnRed}" Margin="0,0,14,0"/>
              <Button x:Name="BtnBtTryAgain" Content="&#8634;   Let's try again" Style="{StaticResource BtnGreen}"/>
            </StackPanel>
          </StackPanel>
        </Border>

        <!-- Restarting Bluetooth screen -->
        <Border x:Name="BtRestartingPanel" Background="#0F1118" CornerRadius="16" Padding="56,52" Width="780" Visibility="Collapsed">
          <TextBlock Text="Restarting Bluetooth..." Foreground="#F1F5F9" FontSize="30" FontWeight="SemiBold"
                     TextAlignment="Center" TextWrapping="Wrap"/>
        </Border>

      </StackPanel>
    </Grid>

    <!-- EMEET SETUP SCREEN (only shown when EmeetIntegMode is on) -->
    <Grid x:Name="ScreenEmeetSetup" Grid.Row="1" Grid.Column="1" Visibility="Collapsed">
      <!-- Left-aligned and width-constrained on purpose: EMEET STUDIO opens at
           (786,180) sized 1140x619 on a 1080p screen, so this card stays clear
           of that area instead of centering across the whole screen. -->
      <StackPanel HorizontalAlignment="Left" VerticalAlignment="Center" Margin="40,0,0,0" Width="620">

        <StackPanel Orientation="Horizontal" HorizontalAlignment="Left" Margin="0,0,0,26">
          <Border Background="#111929" CornerRadius="20" Padding="16,6">
            <TextBlock Text="EMEET" Foreground="#60A5FA" FontSize="17" FontWeight="Bold"/>
          </Border>
        </StackPanel>

        <Border Background="#0F1118" CornerRadius="16" Padding="56,52">
          <StackPanel>
            <TextBlock Text="Let's enable the VCAM"
                       Foreground="#F1F5F9" FontSize="35" FontWeight="SemiBold"
                       TextWrapping="Wrap" Margin="0,0,0,12"/>
            <TextBlock Foreground="#4B5563" FontSize="20" TextWrapping="Wrap" Margin="0,0,0,10">
              <Run Text="&#8226; EMEET STUDIO will open on the right side of the screen"/>
            </TextBlock>
            <TextBlock Foreground="#4B5563" FontSize="20" TextWrapping="Wrap" Margin="0,0,0,36">
              <Run Text="&#8226; The virtual camera turns on automatically -- just wait for it to finish"/>
            </TextBlock>
            <TextBlock x:Name="EmeetVcamStatusText" Foreground="#60A5FA" FontSize="18" FontWeight="SemiBold"
                       TextWrapping="Wrap" Margin="0,0,0,24" Visibility="Collapsed"/>
            <Button x:Name="BtnEmeetEnable" Content="&#9889;   Enable"
                    Style="{StaticResource BtnYes}" HorizontalAlignment="Left"/>
          </StackPanel>
        </Border>

      </StackPanel>
    </Grid>

    <!-- VIDEO SCREEN -->
    <Grid x:Name="ScreenVideo" Grid.Row="1" Grid.Column="1" Visibility="Collapsed" Background="#000000">
      <MediaElement x:Name="VideoPlayer" LoadedBehavior="Manual" UnloadedBehavior="Stop"
                    Stretch="Uniform" HorizontalAlignment="Stretch" VerticalAlignment="Stretch"/>
      <Button x:Name="BtnCloseVideo" Content="&#10005;" Style="{StaticResource BtnClose}"
              HorizontalAlignment="Right" VerticalAlignment="Top" Margin="20"/>
    </Grid>

    <!-- CONFIRM SCREEN -->
    <Grid x:Name="ScreenConfirm" Grid.Row="1" Grid.Column="1" Visibility="Collapsed">
      <StackPanel HorizontalAlignment="Center" VerticalAlignment="Center" Width="700">
        <Border Background="#0F1118" CornerRadius="16" Padding="52,46">
          <StackPanel>
            <TextBlock x:Name="ConfirmText"
                       Foreground="#F1F5F9" FontSize="35" FontWeight="SemiBold"
                       TextWrapping="Wrap" TextAlignment="Center" Margin="0,0,0,12"/>
            <TextBlock Text="Now that you've seen how — did you do it?"
                       Foreground="#4B5563" FontSize="20" TextAlignment="Center" Margin="0,0,0,42"/>
            <StackPanel Orientation="Horizontal" HorizontalAlignment="Center">
              <Button x:Name="BtnConfirmYes" Content="&#10003;   Yes, I have" Style="{StaticResource BtnYes}"     Margin="0,0,14,0"/>
              <Button x:Name="BtnWatchAgain" Content="&#8634;   Watch again"  Style="{StaticResource BtnShowHow}"/>
            </StackPanel>
          </StackPanel>
        </Border>
      </StackPanel>
    </Grid>

    <!-- DETECTION SCREEN -->
    <Grid x:Name="ScreenDetection" Grid.Row="1" Grid.Column="1" Visibility="Collapsed">
      <ScrollViewer VerticalScrollBarVisibility="Auto" HorizontalScrollBarVisibility="Disabled">
        <Grid Margin="40,32,40,40" Width="1230" HorizontalAlignment="Center">
          <Grid.ColumnDefinitions>
            <ColumnDefinition Width="420"/>
            <ColumnDefinition Width="28"/>
            <ColumnDefinition Width="*"/>
          </Grid.ColumnDefinitions>

          <!-- Left panel -->
          <StackPanel Grid.Column="0" VerticalAlignment="Top">
            <Border Background="#111420" CornerRadius="20" Padding="14,6"
                    Margin="0,0,0,28" HorizontalAlignment="Left">
              <TextBlock Text="DETECTION" Foreground="#9CA3AF" FontSize="15" FontWeight="Bold"/>
            </Border>
            <StackPanel x:Name="DetSubwayTrack"/>

            <!-- OnlyT Access Codes box -->
            <Border x:Name="DetOnlyTCard" Visibility="Collapsed"
                    Background="#0A1628" BorderBrush="#1E3A60" BorderThickness="1"
                    CornerRadius="14" Padding="18,16" Margin="0,28,0,0">
              <StackPanel>
                <TextBlock x:Name="DetOnlyTCardLabel" Text="OnlyT Access Code (Ethernet)" Foreground="#60A5FA"
                           FontSize="13" FontWeight="Bold" Margin="0,0,0,10"/>
                <TextBlock x:Name="DetOnlyTAccessCodes" Text="---"
                           Foreground="#F1F5F9" FontSize="26" FontWeight="Bold"
                           HorizontalAlignment="Center" TextAlignment="Center"/>
              </StackPanel>
            </Border>

            <!-- OnlyT Web Preview Address box -->
            <Border x:Name="DetOnlyTWebCard" Visibility="Collapsed"
                    Background="#0A1628" BorderBrush="#1E3A60" BorderThickness="1"
                    CornerRadius="14" Padding="18,16" Margin="0,14,0,0">
              <StackPanel>
                <TextBlock Text="OnlyT Web Preview Address" Foreground="#60A5FA"
                           FontSize="13" FontWeight="Bold" Margin="0,0,0,10"/>
                <TextBlock x:Name="DetOnlyTWebAddress" Text="---"
                           Foreground="#F1F5F9" FontSize="18" FontWeight="Bold"
                           TextWrapping="Wrap" HorizontalAlignment="Center" TextAlignment="Center"/>
              </StackPanel>
            </Border>
          </StackPanel>

          <!-- Right panel: hardware cards + action panels -->
          <StackPanel Grid.Column="2">

            <Grid>
              <Grid.ColumnDefinitions>
                <ColumnDefinition Width="*"/>
                <ColumnDefinition Width="14"/>
                <ColumnDefinition Width="*"/>
              </Grid.ColumnDefinitions>
              <Grid.RowDefinitions>
                <RowDefinition Height="Auto"/>
                <RowDefinition Height="14"/>
                <RowDefinition Height="Auto"/>
                <RowDefinition Height="14"/>
                <RowDefinition Height="Auto"/>
              </Grid.RowDefinitions>

              <!-- AC Power -->
              <Border Grid.Column="0" Grid.Row="0" Background="#0F1118" CornerRadius="12" Padding="22,20">
                <StackPanel>
                  <StackPanel Orientation="Horizontal" Margin="0,0,0,6">
                    <Border x:Name="DetIconAcPower" Width="52" Height="52" CornerRadius="6" Margin="0,0,14,0"/>
                    <TextBlock Text="Charger" Foreground="#E8EAF0" FontSize="20" FontWeight="SemiBold" VerticalAlignment="Center"/>
                  </StackPanel>
                  <TextBlock x:Name="DetStatusAcPower" Text="Checking..." Foreground="#374151" FontSize="17" Margin="66,0,0,0"/>
                  <StackPanel x:Name="DetHelpAcPower" Visibility="Collapsed" Margin="0,10,0,0">
                    <TextBlock Text="Laptop is on battery. Connect the power adapter." Foreground="#9CA3AF" FontSize="16" TextWrapping="Wrap"/>
                  </StackPanel>
                </StackPanel>
              </Border>

              <!-- Internet -->
              <Border Grid.Column="2" Grid.Row="0" Background="#0F1118" CornerRadius="12" Padding="22,20">
                <StackPanel>
                  <StackPanel Orientation="Horizontal" Margin="0,0,0,6">
                    <Border x:Name="DetIconInternet" Width="52" Height="52" CornerRadius="6" Margin="0,0,14,0"/>
                    <TextBlock Text="Internet" Foreground="#E8EAF0" FontSize="20" FontWeight="SemiBold" VerticalAlignment="Center"/>
                  </StackPanel>
                  <TextBlock x:Name="DetStatusInternet" Text="Checking..." Foreground="#374151" FontSize="17" Margin="66,0,0,0"/>
                  <StackPanel x:Name="DetHelpInternet" Visibility="Collapsed" Margin="0,10,0,0">
                    <TextBlock Text="No internet detected. Check the Ethernet converter." Foreground="#9CA3AF" FontSize="16" Margin="0,0,0,8"/>
                    <Button x:Name="BtnOpenInternet" Content="Open Network Settings" Style="{StaticResource BtnHelp}" HorizontalAlignment="Left"/>
                  </StackPanel>
                </StackPanel>
              </Border>

              <!-- HDMI Display -->
              <Border Grid.Column="0" Grid.Row="2" Background="#0F1118" CornerRadius="12" Padding="22,20">
                <StackPanel>
                  <StackPanel Orientation="Horizontal" Margin="0,0,0,6">
                    <Border x:Name="DetIconDisplay" Width="52" Height="52" CornerRadius="6" Margin="0,0,14,0"/>
                    <TextBlock Text="HDMI Display" Foreground="#E8EAF0" FontSize="20" FontWeight="SemiBold" VerticalAlignment="Center"/>
                  </StackPanel>
                  <TextBlock x:Name="DetStatusDisplay" Text="Checking..." Foreground="#374151" FontSize="17" Margin="66,0,0,0"/>
                  <StackPanel x:Name="DetHelpDisplay" Visibility="Collapsed" Margin="0,10,0,0">
                    <TextBlock Text="Extended display not found. Check the HDMI cable." Foreground="#9CA3AF" FontSize="16" TextWrapping="Wrap"/>
                  </StackPanel>
                </StackPanel>
              </Border>

              <!-- Webcam -->
              <Border Grid.Column="2" Grid.Row="2" Background="#0F1118" CornerRadius="12" Padding="22,20">
                <StackPanel>
                  <StackPanel Orientation="Horizontal" Margin="0,0,0,6">
                    <Border x:Name="DetIconWebcam" Width="52" Height="52" CornerRadius="6" Margin="0,0,14,0"/>
                    <TextBlock x:Name="DetLabelWebcam" Text="Webcam" Foreground="#E8EAF0" FontSize="20" FontWeight="SemiBold" VerticalAlignment="Center"/>
                  </StackPanel>
                  <TextBlock x:Name="DetStatusWebcam" Text="Checking..." Foreground="#374151" FontSize="17" Margin="66,0,0,0"/>
                  <StackPanel x:Name="DetHelpWebcam" Visibility="Collapsed" Margin="0,10,0,0">
                    <TextBlock Text="Webcam not detected. Check the USB connection." Foreground="#9CA3AF" FontSize="16" Margin="0,0,0,8"/>
                    <Button x:Name="BtnOpenWebcam" Content="Open Device Manager" Style="{StaticResource BtnHelp}" HorizontalAlignment="Left"/>
                  </StackPanel>
                </StackPanel>
              </Border>

              <!-- USB Audio -->
              <Border x:Name="DetCardUsbAudio" Grid.Column="0" Grid.Row="4"
                      Background="#0F1118" CornerRadius="12" Padding="22,20">
                <StackPanel>
                  <StackPanel Orientation="Horizontal" Margin="0,0,0,6">
                    <Border x:Name="DetIconUsbAudio" Width="52" Height="52" CornerRadius="6" Margin="0,0,14,0"/>
                    <TextBlock Text="USB Audio Adapter" Foreground="#E8EAF0" FontSize="20" FontWeight="SemiBold" VerticalAlignment="Center"/>
                  </StackPanel>
                  <TextBlock x:Name="DetStatusUsbAudio" Text="Checking..." Foreground="#374151" FontSize="17" Margin="66,0,0,0"/>
                  <StackPanel x:Name="DetHelpUsbAudio" Visibility="Collapsed" Margin="0,10,0,0">
                    <TextBlock Text="USB Audio Adapter not found. Check the USB cable." Foreground="#9CA3AF" FontSize="16" TextWrapping="Wrap"/>
                  </StackPanel>
                </StackPanel>
              </Border>

            </Grid>

            <!-- OnlyT Confirm Panel -->
            <Border x:Name="DetOnlyTConfirmPanel" Visibility="Collapsed"
                    Background="#0A1628" BorderBrush="#1E3A60" BorderThickness="1"
                    CornerRadius="16" Padding="44,36" Margin="0,20,0,0">
              <StackPanel>
                <TextBlock Text="OnlyT Timer is running."
                           Foreground="#60A5FA" FontSize="22" FontWeight="Bold"
                           TextAlignment="Center" Margin="0,0,0,8"/>
                <TextBlock x:Name="DetOnlyTConfirmQuestion" Text="Is the timer display showing on the second laptop?"
                           Foreground="#D1D5DB" FontSize="18"
                           TextAlignment="Center" TextWrapping="Wrap" Margin="0,0,0,28"/>
                <StackPanel Orientation="Horizontal" HorizontalAlignment="Center">
                  <Button x:Name="BtnOnlyTConfirmYes" Content="&#10003;   Yes, it is showing"
                          Style="{StaticResource BtnGreen}" Margin="0,0,14,0"/>
                  <Button x:Name="BtnOnlyTConfirmNo"  Content="&#10007;   No, it is not"
                          Style="{StaticResource BtnShowHow}"/>
                </StackPanel>
              </StackPanel>
            </Border>

            <!-- OnlyT Help Panel (shown when both access codes have been tried) -->
            <Border x:Name="DetOnlyTHelpPanel" Visibility="Collapsed"
                    Background="#1A1000" BorderBrush="#78350F" BorderThickness="1"
                    CornerRadius="16" Padding="44,36" Margin="0,20,0,0">
              <StackPanel>
                <TextBlock Text="Skipping OnlyT for this meeting."
                           Foreground="#FCD34D" FontSize="20" FontWeight="Bold"
                           TextAlignment="Center" Margin="0,0,0,14"/>
                <TextBlock Foreground="#D1D5DB" FontSize="17" TextWrapping="Wrap" TextAlignment="Center" Margin="0,0,0,24">
                  <Run Text="Neither access code showed the timer on the second laptop, so OnlyT has been closed. You can start it manually later if it's needed — the meeting will continue without it for now."/>
                </TextBlock>
                <Button x:Name="BtnOnlyTRetry" Content="Continue"
                        Style="{StaticResource BtnGreen}" HorizontalAlignment="Center"/>
              </StackPanel>
            </Border>

            <!-- Ready Panel -->
            <Border x:Name="DetReadyPanel" Visibility="Collapsed"
                    Background="#0F1118" CornerRadius="16" Padding="52,40" Margin="0,20,0,0">
              <StackPanel>
                <TextBlock Text="All systems ready. Select your meeting type."
                           Foreground="#6B7280" FontSize="20" TextAlignment="Center" Margin="0,0,0,24"/>
                <StackPanel Orientation="Horizontal" HorizontalAlignment="Center" Margin="0,0,0,28">
                  <RadioButton x:Name="RadioMidweek" GroupName="MeetingType" Content="Midweek"
                               Style="{StaticResource BtnMeetingType}" Margin="0,0,12,0"/>
                  <RadioButton x:Name="RadioWeekend" GroupName="MeetingType" Content="Weekend"
                               Style="{StaticResource BtnMeetingType}"/>
                </StackPanel>
                <Button x:Name="LaunchButton" Content="Launch Meeting Setup"
                        Style="{StaticResource BtnLaunch}" Visibility="Collapsed"/>
              </StackPanel>
            </Border>

            <Button x:Name="BtnBackToEquipment"
                    Content="&#8592; Back to Equipment Check"
                    Style="{StaticResource BtnBack}"
                    HorizontalAlignment="Center" Margin="0,20,0,0"/>

          </StackPanel>
        </Grid>
      </ScrollViewer>
    </Grid>

    <!-- FOOTER -->
    <Border Grid.Row="2" Grid.ColumnSpan="2" Background="#090B12" BorderBrush="#181B26" BorderThickness="0,1,0,0">
      <TextBlock Text="Ctrl+Shift+S  —  Exit without launch"
                 Foreground="#1E2130" FontSize="17"
                 HorizontalAlignment="Center" VerticalAlignment="Center"/>
    </Border>

    <!-- SETTING-UP OVERLAY -->
    <Border Grid.Row="0" Grid.RowSpan="3" Grid.ColumnSpan="2" x:Name="SettingUpOverlay"
            Background="#0D0F17" Panel.ZIndex="100" Visibility="Collapsed">
      <Border.Triggers>
        <EventTrigger RoutedEvent="FrameworkElement.Loaded">
          <BeginStoryboard>
            <Storyboard RepeatBehavior="Forever" AutoReverse="True">
              <DoubleAnimation Storyboard.TargetName="SpinDot1" Storyboard.TargetProperty="Opacity" From="1.0" To="0.2" Duration="0:0:0.5" BeginTime="0:0:0.0"/>
              <DoubleAnimation Storyboard.TargetName="SpinDot2" Storyboard.TargetProperty="Opacity" From="1.0" To="0.2" Duration="0:0:0.5" BeginTime="0:0:0.15"/>
              <DoubleAnimation Storyboard.TargetName="SpinDot3" Storyboard.TargetProperty="Opacity" From="1.0" To="0.2" Duration="0:0:0.5" BeginTime="0:0:0.3"/>
            </Storyboard>
          </BeginStoryboard>
        </EventTrigger>
      </Border.Triggers>
      <StackPanel HorizontalAlignment="Center" VerticalAlignment="Center">
        <StackPanel Orientation="Horizontal" HorizontalAlignment="Center" Margin="0,0,0,30">
          <Ellipse x:Name="SpinDot1" Width="12" Height="12" Fill="#3D8EF0" Margin="7,0"/>
          <Ellipse x:Name="SpinDot2" Width="12" Height="12" Fill="#3D8EF0" Margin="7,0"/>
          <Ellipse x:Name="SpinDot3" Width="12" Height="12" Fill="#3D8EF0" Margin="7,0"/>
        </StackPanel>
        <TextBlock x:Name="SetupStatusText" Text="Starting services..."
                   Foreground="#E8EAF0" FontSize="32" FontWeight="SemiBold"
                   HorizontalAlignment="Center" Margin="0,0,0,10"/>
        <TextBlock x:Name="SetupStepText" Text=""
                   Foreground="#374151" FontSize="20" HorizontalAlignment="Center"/>
      </StackPanel>
    </Border>

    <!-- WELCOME OVERLAY -->
    <Border Grid.Row="0" Grid.RowSpan="3" Grid.ColumnSpan="2" x:Name="WelcomeOverlay"
            Background="#0D0F17" Panel.ZIndex="200" Visibility="Visible">
      <Border Background="#0F1118" CornerRadius="20" Padding="64,56" Width="820"
              HorizontalAlignment="Center" VerticalAlignment="Center">
        <StackPanel>
          <TextBlock x:Name="WelcomeHeading" Text="Welcome to the Audio-Video Preflight"
                     Foreground="#F1F5F9" FontSize="32" FontWeight="SemiBold"
                     TextWrapping="Wrap" TextAlignment="Center" Margin="0,0,0,10"/>
          <TextBlock Text="This wizard checks and starts everything needed for the meeting — Zoom, OBS, OnlyT, and Meeting Media Manager — step by step."
                     Foreground="#9CA3AF" FontSize="20" TextWrapping="Wrap" TextAlignment="Center" Margin="0,0,0,34"/>
          <StackPanel Orientation="Horizontal" Margin="0,0,0,20">
            <Border Background="#0F2040" CornerRadius="18" Width="36" Height="36" Margin="0,0,18,0">
              <TextBlock Text="1" Foreground="#60A5FA" FontSize="18" FontWeight="Bold" HorizontalAlignment="Center" VerticalAlignment="Center"/>
            </Border>
            <TextBlock Text="Answer each question with Yes. Tap Show me how for a demo video if needed."
                       Foreground="#D1D5DB" FontSize="18" TextWrapping="Wrap" VerticalAlignment="Center" Width="620"/>
          </StackPanel>
          <StackPanel Orientation="Horizontal" Margin="0,0,0,20">
            <Border Background="#0F2040" CornerRadius="18" Width="36" Height="36" Margin="0,0,18,0">
              <TextBlock Text="2" Foreground="#60A5FA" FontSize="18" FontWeight="Bold" HorizontalAlignment="Center" VerticalAlignment="Center"/>
            </Border>
            <TextBlock Text="For Equipment Check, follow the reference photo on the right of each question."
                       Foreground="#D1D5DB" FontSize="18" TextWrapping="Wrap" VerticalAlignment="Center" Width="620"/>
          </StackPanel>
          <StackPanel Orientation="Horizontal" Margin="0,0,0,20">
            <Border Background="#0F2040" CornerRadius="18" Width="36" Height="36" Margin="0,0,18,0">
              <TextBlock Text="3" Foreground="#60A5FA" FontSize="18" FontWeight="Bold" HorizontalAlignment="Center" VerticalAlignment="Center"/>
            </Border>
            <TextBlock Text="Detection checks your hardware automatically. Anything not ready shows a red indicator with instructions."
                       Foreground="#D1D5DB" FontSize="18" TextWrapping="Wrap" VerticalAlignment="Center" Width="620"/>
          </StackPanel>
          <StackPanel Orientation="Horizontal" Margin="0,0,0,34">
            <Border Background="#0F2040" CornerRadius="18" Width="36" Height="36" Margin="0,0,18,0">
              <TextBlock Text="4" Foreground="#60A5FA" FontSize="18" FontWeight="Bold" HorizontalAlignment="Center" VerticalAlignment="Center"/>
            </Border>
            <TextBlock Text="Once ready, choose Midweek or Weekend and press Launch. All programs open and position themselves automatically."
                       Foreground="#D1D5DB" FontSize="18" TextWrapping="Wrap" VerticalAlignment="Center" Width="620"/>
          </StackPanel>
          <TextBlock Text="Tip: Ctrl+Shift+S exits the wizard at any time without launching anything."
                     Foreground="#4B5563" FontSize="16" TextAlignment="Center" Margin="0,0,0,30"/>
          <Button x:Name="BtnWelcomeStart" Content="Got it — let's start"
                  Style="{StaticResource BtnYes}" HorizontalAlignment="Center"/>
        </StackPanel>
      </Border>
    </Border>

    <!-- CONFIRM-ACTION OVERLAY -->
    <Border Grid.Row="0" Grid.RowSpan="3" Grid.ColumnSpan="2" x:Name="ConfirmActionOverlay"
            Background="#0D0F17" Panel.ZIndex="180" Visibility="Collapsed">
      <Border Background="#0F1118" BorderBrush="#181B26" BorderThickness="1" CornerRadius="16"
              Padding="52,46" Width="680" HorizontalAlignment="Center" VerticalAlignment="Center">
        <StackPanel>
          <TextBlock x:Name="ConfirmActionHeader"
                     Foreground="#F1F5F9" FontSize="26" FontWeight="SemiBold"
                     TextWrapping="Wrap" Margin="0,0,0,20"/>
          <StackPanel x:Name="ConfirmActionBullets" Margin="0,0,0,34"/>
          <StackPanel Orientation="Horizontal">
            <Button x:Name="BtnConfirmActionYes" Content="&#10003;   Yes, continue"
                    Style="{StaticResource BtnYes}" Margin="0,0,14,0"/>
            <Button x:Name="BtnConfirmActionBack" Content="&#8592;   Go back"
                    Style="{StaticResource BtnShowHow}"/>
          </StackPanel>
        </StackPanel>
      </Border>
    </Border>

    <!-- STAGECOUNTDOWN OVERLAY -->
    <Border Grid.Row="0" Grid.RowSpan="3" Grid.ColumnSpan="2" x:Name="StageCountdownOverlay"
            Background="#0D0F17" Panel.ZIndex="185" Visibility="Collapsed">
      <Border Background="#0F1118" BorderBrush="#181B26" BorderThickness="1" CornerRadius="16"
              Padding="0" Width="1040" HorizontalAlignment="Center" VerticalAlignment="Center">
        <Grid>
          <Grid.ColumnDefinitions>
            <ColumnDefinition Width="480"/>
            <ColumnDefinition Width="560"/>
          </Grid.ColumnDefinitions>
          <StackPanel Grid.Column="0" VerticalAlignment="Center" Margin="44,40">
            <TextBlock Text="Would you like to use StageCountdown?"
                       Foreground="#F1F5F9" FontSize="26" FontWeight="SemiBold"
                       TextWrapping="Wrap" Margin="0,0,0,20"/>
            <StackPanel Margin="0,0,0,10">
              <TextBlock Foreground="#D1D5DB" FontSize="17" TextWrapping="Wrap" Margin="0,0,0,10">
                <Run Foreground="#60A5FA" FontWeight="Bold" Text="&#8226;  "/>
                <Run Text="Set it to a specific time, like 8:30 AM, and it counts down to the start"/>
              </TextBlock>
              <TextBlock Foreground="#D1D5DB" FontSize="17" TextWrapping="Wrap" Margin="0,0,0,10">
                <Run Foreground="#60A5FA" FontWeight="Bold" Text="&#8226;  "/>
                <Run Text="Or run a manual countdown for any length, from 1 to 60 minutes"/>
              </TextBlock>
              <TextBlock Foreground="#D1D5DB" FontSize="17" TextWrapping="Wrap" Margin="0,0,0,10">
                <Run Foreground="#60A5FA" FontWeight="Bold" Text="&#8226;  "/>
                <Run Text="Plays right on the second display, so the congregation sees it too"/>
              </TextBlock>
              <TextBlock Foreground="#D1D5DB" FontSize="17" TextWrapping="Wrap" Margin="0,0,0,26">
                <Run Foreground="#60A5FA" FontWeight="Bold" Text="&#8226;  "/>
                <Run Text="Built to work right alongside M3 — no extra setup needed"/>
              </TextBlock>
            </StackPanel>
            <StackPanel Orientation="Horizontal">
              <Button x:Name="BtnStageCountdownYes" Content="&#10003;   Yes, use it"
                      Style="{StaticResource BtnYes}" Margin="0,0,14,0"/>
              <Button x:Name="BtnStageCountdownNo" Content="&#10007;   No thanks"
                      Style="{StaticResource BtnShowHow}"/>
            </StackPanel>
          </StackPanel>
          <Border Grid.Column="1" Width="560" Height="560" CornerRadius="0,16,16,0"
                  Background="#07090E" ClipToBounds="True">
            <Image x:Name="StageCountdownPhotoImage" Stretch="UniformToFill"/>
          </Border>
        </Grid>
      </Border>
    </Border>

    <!-- INITIAL SETUP OVERLAY (first run only) -->
    <Border Grid.Row="0" Grid.RowSpan="3" Grid.ColumnSpan="2" x:Name="SetupOverlay"
            Background="#0D0F17" Panel.ZIndex="215" Visibility="Collapsed">
      <ScrollViewer VerticalScrollBarVisibility="Auto" HorizontalAlignment="Center" VerticalAlignment="Center">
        <Border Background="#0F1118" CornerRadius="20" Padding="60,50" Width="820" Margin="0,30">
          <StackPanel>
            <TextBlock Text="Let's set up this laptop"
                       Foreground="#F1F5F9" FontSize="32" FontWeight="SemiBold" TextAlignment="Center" Margin="0,0,0,8"/>
            <TextBlock Text="Just a few questions — you can change any of this later from Settings."
                       Foreground="#9CA3AF" FontSize="18" TextWrapping="Wrap" TextAlignment="Center" Margin="0,0,0,34"/>

            <TextBlock Text="Congregation name" Foreground="#D1D5DB" FontSize="16" FontWeight="SemiBold" Margin="0,0,0,8"/>
            <TextBox x:Name="SetupCongregationName" Style="{StaticResource SettingsTextBox}" Margin="0,0,0,28"/>

            <Grid Margin="0,0,0,24">
              <Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions>
              <StackPanel Grid.Column="0" Margin="0,0,24,0">
                <TextBlock Text="Do you host Zoom on this laptop?" Foreground="#D1D5DB" FontSize="16" FontWeight="SemiBold" TextWrapping="Wrap"/>
                <TextBlock Text="Turn this on if this laptop is always the Zoom host, so the wizard can skip the Host/Join choice." Foreground="#4B5563" FontSize="14" TextWrapping="Wrap" Margin="0,4,0,0"/>
              </StackPanel>
              <CheckBox x:Name="SetupZoomHosting" Grid.Column="1" Style="{StaticResource ToggleSwitchStyle}" VerticalAlignment="Center"/>
            </Grid>

            <Grid Margin="0,0,0,14">
              <Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions>
              <StackPanel Grid.Column="0" Margin="0,0,24,0">
                <TextBlock Text="Different OBS scenes for Midweek and Weekend?" Foreground="#D1D5DB" FontSize="16" FontWeight="SemiBold" TextWrapping="Wrap"/>
                <TextBlock Text="Turn this on if your OBS scene collection has separate scenes for each meeting type." Foreground="#4B5563" FontSize="14" TextWrapping="Wrap" Margin="0,4,0,0"/>
              </StackPanel>
              <CheckBox x:Name="SetupObsScenes" Grid.Column="1" Style="{StaticResource ToggleSwitchStyle}" VerticalAlignment="Center"/>
            </Grid>
            <StackPanel x:Name="SetupObsSceneNamesPanel" Visibility="Collapsed" Margin="0,10,0,24">
              <TextBlock Text="Weekend scene name" Foreground="#D1D5DB" FontSize="15" Margin="0,0,0,6"/>
              <TextBox x:Name="SetupObsSceneWeekend" Style="{StaticResource SettingsTextBox}" Margin="0,0,0,14"/>
              <TextBlock Text="Midweek scene name" Foreground="#D1D5DB" FontSize="15" Margin="0,0,0,6"/>
              <TextBox x:Name="SetupObsSceneMidweek" Style="{StaticResource SettingsTextBox}"/>
            </StackPanel>

            <Grid Margin="0,0,0,14">
              <Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions>
              <StackPanel Grid.Column="0" Margin="0,0,24,0">
                <TextBlock Text="Launch OBS Studio with Always-on-Top?" Foreground="#D1D5DB" FontSize="16" FontWeight="SemiBold" TextWrapping="Wrap"/>
                <TextBlock Text="Keep OBS Studio visible above all other windows during meetings." Foreground="#4B5563" FontSize="14" TextWrapping="Wrap" Margin="0,4,0,0"/>
              </StackPanel>
              <CheckBox x:Name="SetupObsAlwaysOnTop" Grid.Column="1" Style="{StaticResource ToggleSwitchStyle}" VerticalAlignment="Center"/>
            </Grid>

            <Grid Margin="0,0,0,38">
              <Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions>
              <StackPanel Grid.Column="0" Margin="0,0,24,0">
                <TextBlock Text="Would you like to use StageCountdown?" Foreground="#D1D5DB" FontSize="16" FontWeight="SemiBold" TextWrapping="Wrap"/>
                <TextBlock Text="Shows a countdown to start time on the second display, alongside M3. You'll be asked each meeting whether to launch it." Foreground="#4B5563" FontSize="14" TextWrapping="Wrap" Margin="0,4,0,0"/>
              </StackPanel>
              <CheckBox x:Name="SetupStageCountdown" Grid.Column="1" Style="{StaticResource ToggleSwitchStyle}" VerticalAlignment="Center"/>
            </Grid>

            <Button x:Name="BtnSetupFinish" Content="Finish setup"
                    Style="{StaticResource BtnYes}" HorizontalAlignment="Center"/>
          </StackPanel>
        </Border>
      </ScrollViewer>
    </Border>

    <!-- SETTINGS MENU OVERLAY -->
    <Border Grid.Row="0" Grid.RowSpan="3" Grid.ColumnSpan="2" x:Name="SettingsOverlay"
            Background="#0D0F17" Panel.ZIndex="210" Visibility="Collapsed">
      <Border Background="#0F1118" CornerRadius="20" Width="880" Height="720"
              HorizontalAlignment="Center" VerticalAlignment="Center">
        <Grid>
          <Grid.RowDefinitions>
            <RowDefinition Height="Auto"/>
            <RowDefinition Height="Auto"/>
            <RowDefinition Height="*"/>
            <RowDefinition Height="Auto"/>
          </Grid.RowDefinitions>

          <Grid Grid.Row="0" Margin="40,32,40,20">
            <TextBlock Text="Settings" Foreground="#F1F5F9" FontSize="28" FontWeight="SemiBold"/>
            <Button x:Name="BtnSettingsClose" Content="&#10005;" Style="{StaticResource BtnClose}" HorizontalAlignment="Right"/>
          </Grid>

          <StackPanel Grid.Row="1" Orientation="Horizontal" Margin="40,0,40,20">
            <Button x:Name="BtnSettingsTabSimple" Content="Simple" Style="{StaticResource BtnHelp}" Margin="0,0,10,0" Padding="22,10"/>
            <Button x:Name="BtnSettingsTabAdvanced" Content="Advanced" Style="{StaticResource BtnHelp}" Margin="0,0,10,0" Padding="22,10"/>
            <Button x:Name="BtnSettingsTabLayout" Content="Layout" Style="{StaticResource BtnHelp}" Padding="22,10"/>
          </StackPanel>

          <ScrollViewer Grid.Row="2" Margin="40,0,40,0" VerticalScrollBarVisibility="Auto">
            <StackPanel>

              <StackPanel x:Name="SettingsSimplePanel">
                <TextBlock Text="Congregation name" Foreground="#D1D5DB" FontSize="16" FontWeight="SemiBold" Margin="0,0,0,8"/>
                <TextBox x:Name="SetCongregationName" Style="{StaticResource SettingsTextBox}" Margin="0,0,0,26"/>

                <Grid Margin="0,0,0,22">
                  <Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions>
                  <TextBlock Grid.Column="0" Text="Do you host Zoom on this laptop?" Foreground="#D1D5DB" FontSize="16" FontWeight="SemiBold" TextWrapping="Wrap" VerticalAlignment="Center" Margin="0,0,24,0"/>
                  <CheckBox x:Name="SetZoomHosting" Grid.Column="1" Style="{StaticResource ToggleSwitchStyle}" VerticalAlignment="Center"/>
                </Grid>

                <Grid Margin="0,0,0,14">
                  <Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions>
                  <TextBlock Grid.Column="0" Text="Different OBS scenes for Midweek and Weekend?" Foreground="#D1D5DB" FontSize="16" FontWeight="SemiBold" TextWrapping="Wrap" VerticalAlignment="Center" Margin="0,0,24,0"/>
                  <CheckBox x:Name="SetObsScenes" Grid.Column="1" Style="{StaticResource ToggleSwitchStyle}" VerticalAlignment="Center"/>
                </Grid>
                <StackPanel x:Name="SetObsSceneNamesPanel" Visibility="Collapsed" Margin="0,10,0,22">
                  <TextBlock Text="Weekend scene name" Foreground="#D1D5DB" FontSize="15" Margin="0,0,0,6"/>
                  <TextBox x:Name="SetObsSceneWeekend" Style="{StaticResource SettingsTextBox}" Margin="0,0,0,14"/>
                  <TextBlock Text="Midweek scene name" Foreground="#D1D5DB" FontSize="15" Margin="0,0,0,6"/>
                  <TextBox x:Name="SetObsSceneMidweek" Style="{StaticResource SettingsTextBox}"/>
                </StackPanel>

                <Grid Margin="0,0,0,14">
                  <Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions>
                  <TextBlock Grid.Column="0" Text="Launch OBS Studio with Always-on-Top?" Foreground="#D1D5DB" FontSize="16" FontWeight="SemiBold" TextWrapping="Wrap" VerticalAlignment="Center" Margin="0,0,24,0"/>
                  <CheckBox x:Name="SetObsAlwaysOnTop" Grid.Column="1" Style="{StaticResource ToggleSwitchStyle}" VerticalAlignment="Center"/>
                </Grid>

                <Grid Margin="0,0,0,22">
                  <Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions>
                  <TextBlock Grid.Column="0" Text="Would you like to use StageCountdown?" Foreground="#D1D5DB" FontSize="16" FontWeight="SemiBold" TextWrapping="Wrap" VerticalAlignment="Center" Margin="0,0,24,0"/>
                  <CheckBox x:Name="SetStageCountdown" Grid.Column="1" Style="{StaticResource ToggleSwitchStyle}" VerticalAlignment="Center"/>
                </Grid>
              </StackPanel>

              <StackPanel x:Name="SettingsAdvancedPanel" Visibility="Collapsed"/>

              <StackPanel x:Name="SettingsLayoutPanel" Visibility="Collapsed">
                <TextBlock Text="Which layout are you editing?" Foreground="#D1D5DB" FontSize="16" FontWeight="SemiBold" Margin="0,0,0,10"/>
                <StackPanel Orientation="Horizontal" Margin="0,0,0,22">
                  <Button x:Name="BtnLayoutModeStandard"    Content="Standard"      Style="{StaticResource BtnHelp}" Margin="0,0,6,0" Padding="12,6"/>
                  <Button x:Name="BtnLayoutModeOnlyT"       Content="OnlyT"         Style="{StaticResource BtnHelp}" Margin="0,0,6,0" Padding="12,6"/>
                  <Button x:Name="BtnLayoutModeEmeet"       Content="EMEET"         Style="{StaticResource BtnHelp}" Margin="0,0,6,0" Padding="12,6"/>
                  <Button x:Name="BtnLayoutModeEmeetOnlyT"  Content="EMEET+OnlyT"   Style="{StaticResource BtnHelp}" Padding="12,6"/>
                </StackPanel>

                <!-- PowerShell Integration Tools -->
                <Border Background="#0F1118" CornerRadius="12" Padding="16,12" Margin="0,0,0,16">
                  <StackPanel>
                    <TextBlock Text="PowerShell Integration Tools" Foreground="#E8EAF0" FontSize="14" FontWeight="SemiBold" Margin="0,0,0,12"/>
                    <StackPanel Orientation="Horizontal" Margin="0,0,0,10">
                      <Button x:Name="BtnCapturePositions" Content="📍 Capture Current Positions" Style="{StaticResource BtnHelp}" Margin="0,0,8,0" Padding="12,6"/>
                      <Button x:Name="BtnDetectResolution" Content="🖥️ Detect Screen Resolution" Style="{StaticResource BtnHelp}" Margin="0,0,8,0" Padding="12,6"/>
                      <Button x:Name="BtnShowPreview" Content="👁️ Visual Preview" Style="{StaticResource BtnHelp}" Padding="12,6"/>
                    </StackPanel>
                    <TextBlock x:Name="LayoutToolsStatus" Text="" Foreground="#9CA3AF" FontSize="12" Margin="0,0,0,0"/>
                  </StackPanel>
                </Border>

                <!-- Layout Quick Actions -->
                <Border Background="#0F1118" CornerRadius="12" Padding="16,12" Margin="0,0,0,16">
                  <StackPanel>
                    <TextBlock Text="Quick Actions" Foreground="#E8EAF0" FontSize="14" FontWeight="SemiBold" Margin="0,0,0,12"/>
                    <StackPanel Orientation="Horizontal" Margin="0,0,0,10">
                      <Button x:Name="BtnLayoutPresetTileLeft" Content="Tile Left" Style="{StaticResource BtnHelp}" Margin="0,0,8,0" Padding="12,6"/>
                      <Button x:Name="BtnLayoutPresetTileRight" Content="Tile Right" Style="{StaticResource BtnHelp}" Margin="0,0,8,0" Padding="12,6"/>
                      <Button x:Name="BtnLayoutPresetCenter" Content="Center" Style="{StaticResource BtnHelp}" Margin="0,0,8,0" Padding="12,6"/>
                      <Button x:Name="BtnLayoutPresetFullscreen" Content="Fullscreen" Style="{StaticResource BtnHelp}" Padding="12,6"/>
                    </StackPanel>
                    <StackPanel Orientation="Horizontal" Margin="0,0,0,0">
                      <Button x:Name="BtnLayoutValidate" Content="✓ Validate Layout" Style="{StaticResource BtnHelp}" Margin="0,0,8,0" Padding="12,6"/>
                      <Button x:Name="BtnLayoutAutoAlign" Content="⚡ Auto-Align" Style="{StaticResource BtnHelp}" Margin="0,0,8,0" Padding="12,6"/>
                      <Button x:Name="BtnLayoutCopy" Content="📋 Copy App Settings" Style="{StaticResource BtnHelp}" Padding="12,6"/>
                    </StackPanel>
                  </StackPanel>
                </Border>

                <StackPanel x:Name="LayoutRowsContainer"/>

                <StackPanel Orientation="Horizontal" Margin="0,12,0,0">
                  <Button x:Name="BtnLayoutResetMode" Content="Reset this layout to defaults" Style="{StaticResource BtnBack}" HorizontalAlignment="Left" Margin="0,0,12,0"/>
                  <Button x:Name="BtnLayoutSaveMode" Content="💾 Save Changes" Style="{StaticResource BtnYes}" Padding="12,6"/>
                </StackPanel>
              </StackPanel>

            </StackPanel>
          </ScrollViewer>

          <StackPanel Grid.Row="3" Orientation="Horizontal" HorizontalAlignment="Right" Margin="40,20,40,32">
            <Button x:Name="BtnSettingsCancel" Content="Cancel" Style="{StaticResource BtnShowHow}" Margin="0,0,16,0"/>
            <Button x:Name="BtnSettingsSave" Content="Save changes" Style="{StaticResource BtnYes}"/>
          </StackPanel>
        </Grid>
      </Border>
    </Border>

    <!-- RESTART OVERLAY -->
    <Border Grid.Row="0" Grid.RowSpan="3" Grid.ColumnSpan="2" x:Name="RestartOverlay"
            Background="#0D0F17" Panel.ZIndex="220" Visibility="Collapsed">
      <Border Background="#0F1118" CornerRadius="20" Padding="60,50" Width="620"
              HorizontalAlignment="Center" VerticalAlignment="Center">
        <StackPanel>
          <TextBlock Text="Settings saved" Foreground="#F1F5F9" FontSize="28" FontWeight="SemiBold" TextAlignment="Center" Margin="0,0,0,10"/>
          <TextBlock Text="Restart Preflight now so the new settings take effect."
                     Foreground="#9CA3AF" FontSize="18" TextAlignment="Center" TextWrapping="Wrap" Margin="0,0,0,30"/>
          <Button x:Name="BtnRestartNow" Content="Restart now" Style="{StaticResource BtnYes}" HorizontalAlignment="Center" Margin="0,0,0,18"/>
          <Button x:Name="BtnRestartLater" Content="I'll restart later" Style="{StaticResource BtnBack}" HorizontalAlignment="Center"/>
        </StackPanel>
      </Border>
    </Border>

  </Grid>
</Window>
'@

# =============================================================================
#  LOAD WINDOW
# =============================================================================
try {
    $Script:window = [Windows.Markup.XamlReader]::Parse($xaml)
} catch {
    Write-Log "XAML parse failed: $($_.Exception.Message)" "ERROR"
    [System.Windows.Forms.MessageBox]::Show(
        "UI failed to load.`n`nError: $($_.Exception.Message)`n`nLog: $Script:LogFile",
        "$($Script:Config.CongregationName) Audio-Video Preflight", 'OK', 'Error') | Out-Null
    exit 1
}

$wa = [System.Windows.SystemParameters]::WorkArea
$Script:window.Left   = $wa.Left;  $Script:window.Top    = $wa.Top
$Script:window.Width  = $wa.Width; $Script:window.Height = $wa.Height

# =============================================================================
#  CONTROL REFERENCES
# =============================================================================
$Script:clockText            = $Script:window.FindName("ClockText")
$Script:meetingTypeBadge     = $Script:window.FindName("MeetingTypeBadge")
$Script:meetingTypeBadgeText = $Script:window.FindName("MeetingTypeBadgeText")
$Script:testModeBanner       = $Script:window.FindName("TestModeBanner")
$Script:subwayTrack          = $Script:window.FindName("SubwayTrack")
$Script:detSubwayTrack       = $Script:window.FindName("DetSubwayTrack")
$Script:headerTitle          = $Script:window.FindName("HeaderTitle")
$Script:btnStartOver         = $Script:window.FindName("BtnStartOver")
$Script:welcomeHeading       = $Script:window.FindName("WelcomeHeading")
$Script:window.Title         = "$($Script:Config.CongregationName) Audio-Video Preflight"
$Script:headerTitle.Text     = "$($Script:Config.CongregationName) Audio-Video Preflight"
$Script:welcomeHeading.Text  = "Welcome to the $($Script:Config.CongregationName) Audio-Video Preflight"

$Script:screenQuestion       = $Script:window.FindName("ScreenQuestion")
$Script:screenBluetoothSetup = $Script:window.FindName("ScreenBluetoothSetup")
$Script:btSubQ1Panel         = $Script:window.FindName("BtSubQ1Panel")
$Script:btSubQ2Panel         = $Script:window.FindName("BtSubQ2Panel")
$Script:btMixerPhotoImage    = $Script:window.FindName("BtMixerPhotoImage")
$Script:btnBtSubQ1Yes        = $Script:window.FindName("BtnBtSubQ1Yes")
$Script:btDeviceNameRun      = $Script:window.FindName("BtDeviceNameRun")
$Script:btCheckStatusText    = $Script:window.FindName("BtCheckStatusText")
$Script:btnBluetoothCheck    = $Script:window.FindName("BtnBluetoothCheck")
$Script:btnBtNotConnected    = $Script:window.FindName("BtnBtNotConnected")
$Script:btInstructionsPanel  = $Script:window.FindName("BtInstructionsPanel")
$Script:btnBtSkip            = $Script:window.FindName("BtnBtSkip")
$Script:btnBtTryAgain        = $Script:window.FindName("BtnBtTryAgain")
$Script:btRestartingPanel    = $Script:window.FindName("BtRestartingPanel")
$Script:btSettingsAnchor     = $Script:window.FindName("BtSettingsAnchor")
$Script:screenEmeetSetup     = $Script:window.FindName("ScreenEmeetSetup")
$Script:emeetVcamStatusText  = $Script:window.FindName("EmeetVcamStatusText")
$Script:btnEmeetEnable       = $Script:window.FindName("BtnEmeetEnable")
$Script:screenVideo          = $Script:window.FindName("ScreenVideo")
$Script:screenConfirm        = $Script:window.FindName("ScreenConfirm")
$Script:screenDetection      = $Script:window.FindName("ScreenDetection")
$Script:screenUseCase        = $Script:window.FindName("ScreenUseCase")
$Script:btnUseCaseRegular    = $Script:window.FindName("BtnUseCaseRegular")
$Script:btnUseCaseNonZoom    = $Script:window.FindName("BtnUseCaseNonZoom")
$Script:screenZoomChoice     = $Script:window.FindName("ScreenZoomChoice")
$Script:btnZoomModeHost      = $Script:window.FindName("BtnZoomModeHost")
$Script:btnZoomModeJoin      = $Script:window.FindName("BtnZoomModeJoin")
$Script:screenProgramChoice  = $Script:window.FindName("ScreenProgramChoice")
$Script:btnProgramM3         = $Script:window.FindName("BtnProgramM3")
$Script:btnProgramJwLibrary  = $Script:window.FindName("BtnProgramJwLibrary")
$Script:confirmActionOverlay = $Script:window.FindName("ConfirmActionOverlay")
$Script:confirmActionHeader  = $Script:window.FindName("ConfirmActionHeader")
$Script:confirmActionBullets = $Script:window.FindName("ConfirmActionBullets")
$Script:btnConfirmActionYes  = $Script:window.FindName("BtnConfirmActionYes")
$Script:btnConfirmActionBack = $Script:window.FindName("BtnConfirmActionBack")
$Script:screenZoomIntro      = $Script:window.FindName("ScreenZoomIntro")
$Script:zoomIntroHeading     = $Script:window.FindName("ZoomIntroHeading")
$Script:btnOpenZoomIntro     = $Script:window.FindName("BtnOpenZoomIntro")
$Script:btnZoomIntroContinue = $Script:window.FindName("BtnZoomIntroContinue")
$Script:zoomIntroSubtext     = $Script:window.FindName("ZoomIntroSubtext")
$Script:sectionBadgeText     = $Script:window.FindName("SectionBadgeText")
$Script:questionCounter      = $Script:window.FindName("QuestionCounter")
$Script:dotsPanel            = $Script:window.FindName("DotsPanel")
$Script:questionCardZoom     = $Script:window.FindName("QuestionCardZoom")
$Script:questionText         = $Script:window.FindName("QuestionText")
$Script:questionSubtext      = $Script:window.FindName("QuestionSubtext")
$Script:btnYes               = $Script:window.FindName("BtnYes")
$Script:btnShowHow           = $Script:window.FindName("BtnShowHow")
$Script:videoErrorText       = $Script:window.FindName("VideoErrorText")
$Script:questionCardEquip    = $Script:window.FindName("QuestionCardEquipment")
$Script:eqQuestionText       = $Script:window.FindName("EqQuestionText")
$Script:eqQuestionSubtext    = $Script:window.FindName("EqQuestionSubtext")
$Script:btnYesEq             = $Script:window.FindName("BtnYesEq")
$Script:eqPhotoImage         = $Script:window.FindName("EqPhotoImage")
$Script:videoPlayer          = $Script:window.FindName("VideoPlayer")
$Script:btnCloseVideo        = $Script:window.FindName("BtnCloseVideo")
$Script:confirmText          = $Script:window.FindName("ConfirmText")
$Script:btnConfirmYes        = $Script:window.FindName("BtnConfirmYes")
$Script:btnWatchAgain        = $Script:window.FindName("BtnWatchAgain")
$Script:detIconAcPower       = $Script:window.FindName("DetIconAcPower")
$Script:detIconInternet      = $Script:window.FindName("DetIconInternet")
$Script:detIconDisplay       = $Script:window.FindName("DetIconDisplay")
$Script:detIconWebcam        = $Script:window.FindName("DetIconWebcam")
$Script:detIconUsbAudio      = $Script:window.FindName("DetIconUsbAudio")
$Script:detStatusAcPower     = $Script:window.FindName("DetStatusAcPower")
$Script:detStatusInternet    = $Script:window.FindName("DetStatusInternet")
$Script:detStatusDisplay     = $Script:window.FindName("DetStatusDisplay")
$Script:detStatusWebcam      = $Script:window.FindName("DetStatusWebcam")
$Script:detStatusUsbAudio    = $Script:window.FindName("DetStatusUsbAudio")
$Script:detHelpAcPower       = $Script:window.FindName("DetHelpAcPower")
$Script:detHelpInternet      = $Script:window.FindName("DetHelpInternet")
$Script:detHelpDisplay       = $Script:window.FindName("DetHelpDisplay")
$Script:detHelpWebcam        = $Script:window.FindName("DetHelpWebcam")
$Script:detHelpUsbAudio      = $Script:window.FindName("DetHelpUsbAudio")
$Script:detLabelWebcam       = $Script:window.FindName("DetLabelWebcam")
$Script:detCardUsbAudio      = $Script:window.FindName("DetCardUsbAudio")
$Script:btnOpenInternet      = $Script:window.FindName("BtnOpenInternet")
$Script:btnOpenWebcam        = $Script:window.FindName("BtnOpenWebcam")
$Script:detReadyPanel        = $Script:window.FindName("DetReadyPanel")
$Script:radioMidweek         = $Script:window.FindName("RadioMidweek")
$Script:radioWeekend         = $Script:window.FindName("RadioWeekend")
$Script:launchButton         = $Script:window.FindName("LaunchButton")
$Script:btnBackToEquipment   = $Script:window.FindName("BtnBackToEquipment")
$Script:detOnlyTCard         = $Script:window.FindName("DetOnlyTCard")
$Script:detOnlyTCardLabel    = $Script:window.FindName("DetOnlyTCardLabel")
$Script:detOnlyTAccessCodes  = $Script:window.FindName("DetOnlyTAccessCodes")
$Script:detOnlyTWebCard      = $Script:window.FindName("DetOnlyTWebCard")
$Script:detOnlyTWebAddress   = $Script:window.FindName("DetOnlyTWebAddress")
$Script:detOnlyTConfirmPanel = $Script:window.FindName("DetOnlyTConfirmPanel")
$Script:detOnlyTConfirmQuestion = $Script:window.FindName("DetOnlyTConfirmQuestion")
$Script:detOnlyTHelpPanel    = $Script:window.FindName("DetOnlyTHelpPanel")
$Script:btnOnlyTConfirmYes   = $Script:window.FindName("BtnOnlyTConfirmYes")
$Script:btnOnlyTConfirmNo    = $Script:window.FindName("BtnOnlyTConfirmNo")
$Script:btnOnlyTRetry        = $Script:window.FindName("BtnOnlyTRetry")
$Script:settingUpOverlay     = $Script:window.FindName("SettingUpOverlay")
$Script:setupStatusText      = $Script:window.FindName("SetupStatusText")
$Script:setupStepText        = $Script:window.FindName("SetupStepText")
$Script:welcomeOverlay       = $Script:window.FindName("WelcomeOverlay")
$Script:btnWelcomeStart      = $Script:window.FindName("BtnWelcomeStart")
$Script:stageCountdownOverlay     = $Script:window.FindName("StageCountdownOverlay")
$Script:stageCountdownPhotoImage  = $Script:window.FindName("StageCountdownPhotoImage")
$Script:btnStageCountdownYes      = $Script:window.FindName("BtnStageCountdownYes")
$Script:btnStageCountdownNo       = $Script:window.FindName("BtnStageCountdownNo")

# Settings / Setup Wizard
$Script:btnSettings          = $Script:window.FindName("BtnSettings")

$Script:setupOverlay              = $Script:window.FindName("SetupOverlay")
$Script:setupCongregationName     = $Script:window.FindName("SetupCongregationName")
$Script:setupZoomHosting          = $Script:window.FindName("SetupZoomHosting")
$Script:setupObsScenes            = $Script:window.FindName("SetupObsScenes")
$Script:setupObsSceneNamesPanel   = $Script:window.FindName("SetupObsSceneNamesPanel")
$Script:setupObsSceneWeekend      = $Script:window.FindName("SetupObsSceneWeekend")
$Script:setupObsSceneMidweek      = $Script:window.FindName("SetupObsSceneMidweek")
$Script:setupObsAlwaysOnTop       = $Script:window.FindName("SetupObsAlwaysOnTop")
$Script:setupStageCountdown       = $Script:window.FindName("SetupStageCountdown")
$Script:btnSetupFinish            = $Script:window.FindName("BtnSetupFinish")

$Script:settingsOverlay           = $Script:window.FindName("SettingsOverlay")
$Script:btnSettingsClose          = $Script:window.FindName("BtnSettingsClose")
$Script:btnSettingsTabSimple      = $Script:window.FindName("BtnSettingsTabSimple")
$Script:btnSettingsTabAdvanced    = $Script:window.FindName("BtnSettingsTabAdvanced")
$Script:btnSettingsTabLayout      = $Script:window.FindName("BtnSettingsTabLayout")
$Script:settingsSimplePanel       = $Script:window.FindName("SettingsSimplePanel")
$Script:settingsAdvancedPanel     = $Script:window.FindName("SettingsAdvancedPanel")
$Script:settingsLayoutPanel       = $Script:window.FindName("SettingsLayoutPanel")
$Script:btnLayoutModeStandard     = $Script:window.FindName("BtnLayoutModeStandard")
$Script:btnLayoutModeOnlyT        = $Script:window.FindName("BtnLayoutModeOnlyT")
$Script:btnLayoutModeEmeet        = $Script:window.FindName("BtnLayoutModeEmeet")
$Script:btnLayoutModeEmeetOnlyT   = $Script:window.FindName("BtnLayoutModeEmeetOnlyT")
$Script:layoutRowsContainer       = $Script:window.FindName("LayoutRowsContainer")
$Script:btnLayoutResetMode        = $Script:window.FindName("BtnLayoutResetMode")
$Script:btnLayoutSaveMode         = $Script:window.FindName("BtnLayoutSaveMode")

# PowerShell Integration Tool Controls
$Script:btnCapturePositions      = $Script:window.FindName("BtnCapturePositions")
$Script:btnDetectResolution      = $Script:window.FindName("BtnDetectResolution")
$Script:btnShowPreview           = $Script:window.FindName("BtnShowPreview")
$Script:layoutToolsStatus        = $Script:window.FindName("LayoutToolsStatus")

# Layout Quick Action Controls  
$Script:btnLayoutPresetTileLeft  = $Script:window.FindName("BtnLayoutPresetTileLeft")
$Script:btnLayoutPresetTileRight = $Script:window.FindName("BtnLayoutPresetTileRight")
$Script:btnLayoutPresetCenter    = $Script:window.FindName("BtnLayoutPresetCenter")
$Script:btnLayoutPresetFullscreen = $Script:window.FindName("BtnLayoutPresetFullscreen")
$Script:btnLayoutValidate        = $Script:window.FindName("BtnLayoutValidate")
$Script:btnLayoutAutoAlign       = $Script:window.FindName("BtnLayoutAutoAlign")
$Script:btnLayoutCopy            = $Script:window.FindName("BtnLayoutCopy")
$Script:setCongregationName       = $Script:window.FindName("SetCongregationName")
$Script:setZoomHosting            = $Script:window.FindName("SetZoomHosting")
$Script:setObsScenes              = $Script:window.FindName("SetObsScenes")
$Script:setObsSceneNamesPanel     = $Script:window.FindName("SetObsSceneNamesPanel")
$Script:setObsSceneWeekend        = $Script:window.FindName("SetObsSceneWeekend")
$Script:setObsSceneMidweek        = $Script:window.FindName("SetObsSceneMidweek")
$Script:setObsAlwaysOnTop         = $Script:window.FindName("SetObsAlwaysOnTop")
$Script:setStageCountdown         = $Script:window.FindName("SetStageCountdown")
$Script:btnSettingsCancel         = $Script:window.FindName("BtnSettingsCancel")
$Script:btnSettingsSave           = $Script:window.FindName("BtnSettingsSave")

$Script:restartOverlay            = $Script:window.FindName("RestartOverlay")
$Script:btnRestartNow             = $Script:window.FindName("BtnRestartNow")
$Script:btnRestartLater           = $Script:window.FindName("BtnRestartLater")

# ----- BRUSHES ---------------------------------------------------------------
$bc = [System.Windows.Media.BrushConverter]::new()
$Script:brushGreen       = $bc.ConvertFromString("#22C55E")
$Script:brushRed         = $bc.ConvertFromString("#EF4444")
$Script:brushBlue        = $bc.ConvertFromString("#3D8EF0")
$Script:brushPending     = $bc.ConvertFromString("#1E2130")
$Script:brushPendingIcon = $bc.ConvertFromString("#374151")

# =============================================================================
#  HELPER / UI FUNCTIONS
# =============================================================================

function Show-ConfirmAction {
    param([string]$Header, [string[]]$Bullets, [scriptblock]$OnConfirm, [scriptblock]$OnCancel)
    $Script:confirmActionHeader.Text = $Header
    $Script:confirmActionBullets.Children.Clear()
    foreach ($b in $Bullets) {
        $tb = New-Object System.Windows.Controls.TextBlock
        $tb.Text         = "  $b"
        $tb.Foreground   = $bc.ConvertFromString("#9CA3AF")
        $tb.FontSize     = 16
        $tb.TextWrapping = 'Wrap'
        $tb.Margin       = [System.Windows.Thickness]::new(0,0,0,8)
        [void]$Script:confirmActionBullets.Children.Add($tb)
    }
    $Script:PendingConfirmYes    = $OnConfirm
    $Script:PendingConfirmCancel = $OnCancel
    $Script:confirmActionOverlay.Visibility = 'Visible'
}

$Script:IconsFolder = Join-Path $Script:MediaFolder "icons"

function Build-DetCards {
    $cards = @(
        @{ Key="Charger";     HwKey="AcPower";  Icon=$Script:detIconAcPower;  Status=$Script:detStatusAcPower;  Help=$Script:detHelpAcPower;  Ok="Connected"; Bad="On battery";    IconFile="icon-ac-power.png"     }
        @{ Key="Internet";    HwKey="Internet"; Icon=$Script:detIconInternet; Status=$Script:detStatusInternet; Help=$Script:detHelpInternet; Ok="Online";    Bad="Not reachable"; IconFile="icon-internet.png"     }
        @{ Key="Display";     HwKey="Display";  Icon=$Script:detIconDisplay;  Status=$Script:detStatusDisplay;  Help=$Script:detHelpDisplay;  Ok="Detected";  Bad="Not found";     IconFile="icon-hdmi-display.png" }
        @{ Key="PTZ Camera";  HwKey="Webcam";   Icon=$Script:detIconWebcam;   Status=$Script:detStatusWebcam;   Help=$Script:detHelpWebcam;   Ok="Ready";     Bad="Not detected";  IconFile="icon-camera.png"       }
    )
    if ($Script:State.Flow -eq "NonZoom") {
        $Script:detCardUsbAudio.Visibility = 'Collapsed'
    } else {
        $Script:detCardUsbAudio.Visibility = 'Visible'
        $cards += @{ Key="USB Audio"; HwKey="UsbAudio"; Icon=$Script:detIconUsbAudio; Status=$Script:detStatusUsbAudio; Help=$Script:detHelpUsbAudio; Ok="Ready"; Bad="Not found"; IconFile="icon-usb-audio.png" }
    }
    $Script:DetCards = $cards
}
$Script:detLabelWebcam.Text = $Script:Config.WebcamName
Build-DetCards

function Show-Screen {
    param([string]$Name)
    $Script:screenUseCase.Visibility       = if ($Name -eq "ScreenUseCase")       { 'Visible' } else { 'Collapsed' }
    $Script:screenZoomChoice.Visibility    = if ($Name -eq "ScreenZoomChoice")    { 'Visible' } else { 'Collapsed' }
    $Script:screenZoomIntro.Visibility     = if ($Name -eq "ScreenZoomIntro")     { 'Visible' } else { 'Collapsed' }
    $Script:screenProgramChoice.Visibility = if ($Name -eq "ScreenProgramChoice") { 'Visible' } else { 'Collapsed' }
    $Script:screenQuestion.Visibility      = if ($Name -eq "ScreenQuestion")      { 'Visible' } else { 'Collapsed' }
    $Script:screenBluetoothSetup.Visibility = if ($Name -eq "ScreenBluetoothSetup") { 'Visible' } else { 'Collapsed' }
    $Script:screenEmeetSetup.Visibility     = if ($Name -eq "ScreenEmeetSetup")     { 'Visible' } else { 'Collapsed' }
    $Script:screenVideo.Visibility         = if ($Name -eq "ScreenVideo")         { 'Visible' } else { 'Collapsed' }
    $Script:screenConfirm.Visibility       = if ($Name -eq "ScreenConfirm")       { 'Visible' } else { 'Collapsed' }
    $Script:screenDetection.Visibility     = if ($Name -eq "ScreenDetection")     { 'Visible' } else { 'Collapsed' }
}

function Update-ProgressDots {
    $sec = $Script:Sections[$Script:State.SectionIdx]
    $Script:dotsPanel.Children.Clear()
    for ($i = 0; $i -lt $sec.Questions.Count; $i++) {
        $dot = New-Object System.Windows.Shapes.Ellipse
        $dot.Width             = 10
        $dot.Height            = 10
        $dot.Margin            = [System.Windows.Thickness]::new(7,0,7,0)
        $dot.VerticalAlignment = [System.Windows.VerticalAlignment]::Center
        $dot.Fill = if     ($i -lt  $Script:State.QuestionIdx) { $Script:brushGreen   }
                    elseif ($i -eq  $Script:State.QuestionIdx) { $Script:brushBlue    }
                    else                                        { $Script:brushPending }
        [void]$Script:dotsPanel.Children.Add($dot)
    }
}

function Set-EquipmentPhoto {
    param([hashtable]$Q)
    $Script:eqPhotoImage.Source = $null
    if (-not $Q.ContainsKey('Photo') -or -not $Q.Photo) { return }
    $path = Join-Path $Script:MediaFolder $Q.Photo
    if (-not (Test-Path $path)) { Write-Log "Equipment photo not found: $path" "WARN"; return }
    try {
        $bmp = [System.Windows.Media.Imaging.BitmapImage]::new()
        $bmp.BeginInit()
        $bmp.UriSource   = [Uri]::new($path)
        $bmp.CacheOption = [System.Windows.Media.Imaging.BitmapCacheOption]::OnLoad
        $bmp.EndInit()
        $Script:eqPhotoImage.Source = $bmp
    } catch { Write-Log "Photo load failed ($($Q.Photo)): $($_.Exception.Message)" "WARN" }
}

function Set-DetectionIcons {
    foreach ($card in $Script:DetCards) {
        $path = Join-Path $Script:IconsFolder $card.IconFile
        if (-not (Test-Path $path)) { Write-Log "Icon not found: $path" "WARN"; continue }
        try {
            $bmp = [System.Windows.Media.Imaging.BitmapImage]::new()
            $bmp.BeginInit()
            $bmp.UriSource   = [Uri]::new($path)
            $bmp.CacheOption = [System.Windows.Media.Imaging.BitmapCacheOption]::OnLoad
            $bmp.EndInit()
            $card.Icon.OpacityMask = [System.Windows.Media.ImageBrush]::new($bmp)
            $card.Icon.Background  = $Script:brushPendingIcon
        } catch { Write-Log "Icon load failed ($($card.IconFile)): $($_.Exception.Message)" "WARN" }
    }
}

function Set-IconTint { param($IconImage, $Brush); $IconImage.Background = $Brush }

function Build-SubwayStop {
    param([string]$LabelText, [string]$State, [string]$Initial)
    $stop = New-Object System.Windows.Controls.StackPanel
    $stop.HorizontalAlignment = 'Center'
    $stop.Margin              = [System.Windows.Thickness]::new(0,0,0,4)

    $node = New-Object System.Windows.Controls.Border
    $node.Width               = 42
    $node.Height              = 42
    $node.CornerRadius        = [System.Windows.CornerRadius]::new(21)
    $node.HorizontalAlignment = 'Center'
    $node.BorderThickness     = [System.Windows.Thickness]::new(2)

    $nodeText = New-Object System.Windows.Controls.TextBlock
    $nodeText.HorizontalAlignment = 'Center'
    $nodeText.VerticalAlignment   = 'Center'
    $nodeText.FontSize            = 18
    $nodeText.FontWeight          = 'Bold'

    switch ($State) {
        'done' {
            $node.Background     = $bc.ConvertFromString("#1A3A2A")
            $node.BorderBrush    = $Script:brushGreen
            $nodeText.Text       = [char]0x2713
            $nodeText.Foreground = $Script:brushGreen
        }
        'active' {
            $node.Background     = $bc.ConvertFromString("#0F2040")
            $node.BorderBrush    = $Script:brushBlue
            $nodeText.Text       = $Initial
            $nodeText.Foreground = $Script:brushBlue
        }
        default {
            $node.Background     = $bc.ConvertFromString("#111420")
            $node.BorderBrush    = $bc.ConvertFromString("#252836")
            $nodeText.Text       = $Initial
            $nodeText.Foreground = $bc.ConvertFromString("#374151")
        }
    }
    $node.Child = $nodeText

    $label = New-Object System.Windows.Controls.TextBlock
    $label.Text               = $LabelText
    $label.FontSize           = 11
    $label.FontWeight         = 'SemiBold'
    $label.HorizontalAlignment = 'Center'
    $label.TextAlignment      = 'Center'
    $label.Margin             = [System.Windows.Thickness]::new(2,5,2,0)
    $label.Foreground = switch ($State) {
        'done'   { $Script:brushGreen }
        'active' { $Script:brushBlue  }
        default  { $bc.ConvertFromString("#374151") }
    }

    [void]$stop.Children.Add($node)
    [void]$stop.Children.Add($label)
    return $stop
}

function Build-SubwayLine {
    param([string]$State)
    $line = New-Object System.Windows.Shapes.Rectangle
    $line.Width               = 2
    $line.Height              = 32
    $line.Margin              = [System.Windows.Thickness]::new(0,4,0,4)
    $line.HorizontalAlignment = 'Center'
    $line.Fill = switch ($State) {
        'done'   { $Script:brushGreen }
        'active' { $Script:brushBlue  }
        default  { $bc.ConvertFromString("#1E2130") }
    }
    return $line
}

function Update-MainSubway {
    $Script:subwayTrack.Children.Clear()
    $labels = @{ zoom = @("ZOOM","Z"); equipment = @("EQUIP","E") }

    for ($i = 0; $i -lt $Script:Sections.Count; $i++) {
        $sec   = $Script:Sections[$i]
        $state = if     ($Script:State.SectionIdx -gt $i -or $Script:screenDetection.Visibility -eq 'Visible' -or $Script:screenEmeetSetup.Visibility -eq 'Visible') { 'done'   }
                 elseif (($Script:screenQuestion.Visibility -eq 'Visible' -or $Script:screenBluetoothSetup.Visibility -eq 'Visible') -and $Script:State.SectionIdx -eq $i)  { 'active' }
                 else                                                                                             { 'pending' }
        $lbl = $labels[$sec.Id]
        if (-not $lbl) { $lbl = @($sec.Name.ToUpper(), $sec.Name.Substring(0,1)) }
        [void]$Script:subwayTrack.Children.Add((Build-SubwayStop $lbl[0] $state $lbl[1]))
        [void]$Script:subwayTrack.Children.Add((Build-SubwayLine (if ($state -eq 'done') {'done'} elseif ($state -eq 'active') {'active'} else {'pending'})))
    }

    $detState = if ($Script:screenDetection.Visibility -eq 'Visible' -and $Script:State.AllHwReady) { 'done'   }
                elseif ($Script:screenDetection.Visibility -eq 'Visible')                            { 'active' }
                else                                                                                  { 'pending' }
    [void]$Script:subwayTrack.Children.Add((Build-SubwayStop "DETECT" $detState "D"))
}

function Update-DetectionSubway {
    $Script:detSubwayTrack.Children.Clear()

    for ($i = 0; $i -lt $Script:DetCards.Count; $i++) {
        $card  = $Script:DetCards[$i]
        $state = if     ($card.Status.Text -eq $card.Ok)                                                    { 'done'    }
                 elseif ($card.Status.Text -eq 'Checking...' -or $card.Status.Text -eq 'Checking...') { 'pending' }
                 else                                                                                        { 'fail'    }

        $row             = New-Object System.Windows.Controls.StackPanel
        $row.Orientation = 'Horizontal'
        $row.Margin      = [System.Windows.Thickness]::new(0,0,0,4)

        # 52x52 icon tile
        $iconBorder                   = New-Object System.Windows.Controls.Border
        $iconBorder.Width             = 52
        $iconBorder.Height            = 52
        $iconBorder.CornerRadius      = [System.Windows.CornerRadius]::new(8)
        $iconBorder.VerticalAlignment = 'Center'
        $iconBorder.Margin            = [System.Windows.Thickness]::new(0,0,12,0)

        $iconPath = Join-Path $Script:IconsFolder $card.IconFile
        if (Test-Path $iconPath) {
            try {
                $bmp = [System.Windows.Media.Imaging.BitmapImage]::new()
                $bmp.BeginInit()
                $bmp.UriSource   = [Uri]::new($iconPath)
                $bmp.CacheOption = [System.Windows.Media.Imaging.BitmapCacheOption]::OnLoad
                $bmp.EndInit()
                $iconBorder.OpacityMask = [System.Windows.Media.ImageBrush]::new($bmp)
            } catch {}
        }
        $iconBorder.Background = switch ($state) {
            'done'   { $Script:brushGreen }
            'fail'   { $Script:brushRed   }
            default  { $Script:brushPendingIcon }
        }

        $labelStack                   = New-Object System.Windows.Controls.StackPanel
        $labelStack.VerticalAlignment = 'Center'

        $lbl          = New-Object System.Windows.Controls.TextBlock
        $lbl.Text     = $card.Key
        $lbl.FontSize = 14
        $lbl.FontWeight = 'SemiBold'
        $lbl.Foreground = switch ($state) {
            'done'   { $Script:brushGreen }
            'fail'   { $bc.ConvertFromString("#F87171") }
            default  { $bc.ConvertFromString("#374151")  }
        }

        $sub          = New-Object System.Windows.Controls.TextBlock
        $sub.Text     = if ($state -eq 'done') { $card.Ok } elseif ($state -eq 'fail') { $card.Bad } else { "Checking..." }
        $sub.FontSize = 12
        $sub.Foreground = switch ($state) {
            'done'   { $bc.ConvertFromString("#4ADE80") }
            'fail'   { $bc.ConvertFromString("#F87171") }
            default  { $bc.ConvertFromString("#374151")  }
        }

        [void]$labelStack.Children.Add($lbl)
        [void]$labelStack.Children.Add($sub)
        [void]$row.Children.Add($iconBorder)
        [void]$row.Children.Add($labelStack)
        [void]$Script:detSubwayTrack.Children.Add($row)

        if ($i -lt $Script:DetCards.Count - 1) {
            $line                      = New-Object System.Windows.Shapes.Rectangle
            $line.Width                = 2
            $line.Height               = 18
            $line.Margin               = [System.Windows.Thickness]::new(24,2,0,2)
            $line.HorizontalAlignment  = 'Left'
            $line.Fill = switch ($state) {
                'done'  { $Script:brushGreen }
                'fail'  { $Script:brushRed   }
                default { $bc.ConvertFromString("#1E2130") }
            }
            [void]$Script:detSubwayTrack.Children.Add($line)
        }
    }
}

function Set-MeetingTypeBadge {
    param([string]$Type)
    $Script:meetingTypeBadgeText.Text   = $Type.ToUpper()
    $Script:meetingTypeBadge.Visibility = 'Visible'
}

function Show-CurrentQuestion {
    $sec = $Script:Sections[$Script:State.SectionIdx]
    $q   = $sec.Questions[$Script:State.QuestionIdx]

    $Script:window.Topmost = ($sec.Id -ne 'zoom')

    $Script:sectionBadgeText.Text = $sec.Name.ToUpper()
    $Script:questionCounter.Text  = "  —  $($Script:State.QuestionIdx + 1) of $($sec.Questions.Count)"
    Update-ProgressDots

    $Script:questionCardZoom.Visibility  = 'Collapsed'
    $Script:questionCardEquip.Visibility = 'Collapsed'

    if ($sec.Type -eq 'video') {
        $Script:questionText.Text    = $q.Text
        $Script:questionSubtext.Text = $q.Sub
        $hasVid = $q.ContainsKey('Video') -and $q.Video -and (Test-Path (Join-Path $Script:MediaFolder $q.Video))
        $Script:btnShowHow.Visibility       = if ($hasVid) { 'Visible' } else { 'Collapsed' }
        $Script:questionCardZoom.Visibility = 'Visible'
    } else {
        $Script:eqQuestionText.Text    = $q.Text
        $Script:eqQuestionSubtext.Text = $q.Sub
        Set-EquipmentPhoto $q
        $Script:questionCardEquip.Visibility = 'Visible'
    }

    $Script:videoErrorText.Visibility = 'Collapsed'
    Show-Screen "ScreenQuestion"
    Update-MainSubway
    Write-Log "Showing: [$($sec.Name)] Q$($Script:State.QuestionIdx + 1) -- $($q.Text)"
}

function Advance-Question {
    $sec   = $Script:Sections[$Script:State.SectionIdx]
    $nextQ = $Script:State.QuestionIdx + 1
    if ($nextQ -lt $sec.Questions.Count) {
        $Script:State.QuestionIdx = $nextQ
        Show-CurrentQuestion
    } else {
        $nextSec = $Script:State.SectionIdx + 1
        if ($nextSec -lt $Script:Sections.Count) {
            $Script:State.SectionIdx  = $nextSec
            $Script:State.QuestionIdx = 0
            if ($Script:Sections[$nextSec].Id -eq "equipment") {
                Start-EquipmentSection
            } else {
                Show-CurrentQuestion
            }
        } else {
            Write-Log "All sections complete -- moving to Detection."
            if ($Script:State.Flow -eq "NonZoom") {
                Show-Screen "ScreenProgramChoice"
            } elseif ($Script:Config.EmeetIntegMode -and -not $Script:State.EmeetVcamEnabled) {
                Show-EmeetSetupScreen
            } else {
                Show-DetectionScreen
            }
        }
    }
}

function Start-EquipmentSection {
    if ($Script:Config.BluetoothMode -and -not $Script:State.BluetoothConfirmed) {
        Show-BluetoothSetupScreen
    } else {
        Show-Screen "ScreenQuestion"
        Show-CurrentQuestion
    }
}

function Open-MediaVideo {
    $q = $Script:Sections[$Script:State.SectionIdx].Questions[$Script:State.QuestionIdx]
    if (-not $q.ContainsKey('Video')) { return }
    $path = Join-Path $Script:MediaFolder $q.Video
    if (-not (Test-Path $path)) { Write-Log "Video not found: $path" "WARN"; return }
    $Script:State.CurrentVideo = $path
    $Script:videoPlayer.Source = [Uri]::new($path)
    $Script:videoPlayer.Play()
    Show-Screen "ScreenVideo"
    Write-Log "Playing video: $($q.Video)"
}

function Show-OnlyTCode {
    # Displays the codes for the current $Script:State.OnlyTCodeStage ("Wired" or
    # "Wireless"). Falls back to whichever list actually has codes if the
    # preferred one is empty (e.g. no Ethernet link detected).
    $codes = $Script:State.OnlyTAccessCodes
    $stage = $Script:State.OnlyTCodeStage
    if ($stage -eq "Wired" -and -not $codes.Wired -and $codes.Wireless) {
        $stage = "Wireless"
        $Script:State.OnlyTCodeStage = $stage
    } elseif ($stage -eq "Wireless" -and -not $codes.Wireless -and $codes.Wired) {
        $stage = "Wired"
        $Script:State.OnlyTCodeStage = $stage
    }
    $active = if ($stage -eq "Wired") { $codes.Wired } else { $codes.Wireless }
    $Script:detOnlyTCardLabel.Text   = if ($stage -eq "Wired") { "OnlyT Access Code (Ethernet)" } else { "OnlyT Access Code (Wi-Fi)" }
    $Script:detOnlyTAccessCodes.Text = Format-AccessCodes $active
    $Script:detOnlyTWebAddress.Text  = Format-WebPreviewAddresses $active
}

function Show-DetectionScreen {
    # In case the operator opened Settings mid-flow, close it out so it doesn't
    # sit on top of the Detection screen.
    $Script:settingsOverlay.Visibility      = 'Collapsed'
    Close-BluetoothSettingsWindow
    # The EMEET VCAM step drops Topmost so EMEET STUDIO can appear above us --
    # restore it here regardless of which screen we arrived from.
    $Script:window.Topmost                  = $true

    $Script:State.AllHwReady                = $false
    $Script:State.OnlyTLaunched             = $false
    $Script:State.OnlyTConfirmed            = $false
    $Script:State.OnlyTCodeStage            = "Wired"
    $Script:State.StageCountdownAsked       = $false
    $Script:State.UseStageCountdown         = $false
    $Script:detReadyPanel.Visibility        = 'Collapsed'
    $Script:launchButton.Visibility         = 'Collapsed'
    $Script:detOnlyTConfirmPanel.Visibility = 'Collapsed'
    $Script:detOnlyTHelpPanel.Visibility    = 'Collapsed'

    if ($Script:Config.OnlyTMode) {
        $Script:detOnlyTCard.Visibility    = 'Visible'
        $Script:detOnlyTWebCard.Visibility = 'Visible'
        Show-OnlyTCode
    } else {
        $Script:detOnlyTCard.Visibility    = 'Collapsed'
        $Script:detOnlyTWebCard.Visibility = 'Collapsed'
    }

    Show-Screen "ScreenDetection"
    Update-MainSubway
    Update-DetectionSubway
    $Script:detectionTimer.Start()
}

function Update-DetectionCard {
    param([bool]$IsOk, $Card)
    if ($IsOk) {
        Set-IconTint $Card.Icon $Script:brushGreen
        $Card.Status.Text       = $Card.Ok
        $Card.Status.Foreground = $Script:brushGreen
        $Card.Help.Visibility   = 'Collapsed'
    } else {
        Set-IconTint $Card.Icon $Script:brushRed
        $Card.Status.Text       = $Card.Bad
        $Card.Status.Foreground = $Script:brushRed
        $Card.Help.Visibility   = 'Visible'
    }
}

function Launch-OnlyTNow {
    if (Test-Path $Script:Config.OnlyTPath) {
        try {
            Start-Process -FilePath $Script:Config.OnlyTPath
            Write-Log "OnlyT auto-launched on hardware-green."
        } catch {
            Write-Log "OnlyT auto-launch failed: $($_.Exception.Message)" "ERROR"
        }
        $step = Get-LaunchStep -ModeName (Get-PreflightModeName) -AppName "OnlyT"
        if ($step) {
            Move-AppWindow -ProcessNames $Script:Config.OnlyTProcessNames -DisplayName "OnlyT" `
                           -X $step.X -Y $step.Y -W $step.W -H $step.H
        }
    } else {
        Write-Log "OnlyT path not found: $($Script:Config.OnlyTPath)" "WARN"
    }
}

function Close-OnlyT {
    # Best-effort close -- used when the operator couldn't get the timer showing
    # on either access code and we're moving on without it.
    foreach ($name in $Script:Config.OnlyTProcessNames) {
        try {
            Get-Process -Name $name -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
        } catch {
            Write-Log "Could not close OnlyT process '$name': $($_.Exception.Message)" "WARN"
        }
    }
    Write-Log "OnlyT closed -- skipping it for this meeting."
}

function Complete-OnlyTStep {
    # Called once OnlyT is confirmed showing, skipped, or was never in play.
    # Next stop is the StageCountdown prompt (if configured and not already
    # asked this run), otherwise straight to the Ready panel.
    if ($Script:Config.StageCountdownMode -and -not $Script:State.StageCountdownAsked) {
        Show-StageCountdownPrompt
    } else {
        Show-ReadyPanel
    }
}

function Show-StageCountdownPrompt {
    $Script:State.StageCountdownAsked = $true
    $Script:stageCountdownPhotoImage.Source = $null
    $photoPath = Join-Path $Script:MediaFolder "stagecountdown-screenshot.jpg"
    if (Test-Path $photoPath) {
        try {
            $bmp = [System.Windows.Media.Imaging.BitmapImage]::new()
            $bmp.BeginInit()
            $bmp.UriSource   = [Uri]::new($photoPath)
            $bmp.CacheOption = [System.Windows.Media.Imaging.BitmapCacheOption]::OnLoad
            $bmp.EndInit()
            $Script:stageCountdownPhotoImage.Source = $bmp
        } catch { Write-Log "StageCountdown screenshot load failed: $($_.Exception.Message)" "WARN" }
    } else {
        Write-Log "StageCountdown screenshot not found: $photoPath" "WARN"
    }
    $Script:stageCountdownOverlay.Visibility = 'Visible'
}

function Invoke-EmeetStep {
    # Most of the time EMEET is already running (and already has its virtual
    # camera on) from the "Let's enable the VCAM" step earlier in the flow --
    # this just makes sure it's running and moves it into its real
    # meeting-time tile. If the operator skipped straight here somehow
    # (EmeetIntegMode flipped on after that step ran, etc.) it launches it
    # fresh, though the VCAM won't have been enabled.
    param($Step, $StepNum, $AppCount)
    Set-SetupStatus "Positioning EMEET STUDIO..." "$StepNum of $AppCount  —  EMEET"
    if (-not (Test-Path $Script:Config.EmeetPath)) {
        Write-Log "EMEET STUDIO path not found: $($Script:Config.EmeetPath)" "WARN"
        return
    }
    $already = Get-Process -Name $Script:Config.EmeetProcessNames -ErrorAction SilentlyContinue |
               Where-Object { $_.MainWindowHandle -ne 0 }
    if ($already) {
        Write-Log "EMEET STUDIO already running."
    } else {
        Set-SetupStatus "Starting EMEET STUDIO..." "$StepNum of $AppCount  —  EMEET"
        try {
            Start-Process -FilePath $Script:Config.EmeetPath `
                          -WorkingDirectory (Split-Path $Script:Config.EmeetPath)
            Write-Log "EMEET STUDIO launched."
            Start-Sleep -Milliseconds 1500
        } catch {
            Write-Log "EMEET STUDIO launch failed: $($_.Exception.Message)" "ERROR"
            return
        }
    }

    Move-AppWindow -ProcessNames $Script:Config.EmeetProcessNames -DisplayName "EMEET STUDIO" `
                   -X $Step.X -Y $Step.Y -W $Step.W -H $Step.H
}

function Invoke-ObsStep {
    param($Step, $StepNum, $AppCount)
    Set-SetupStatus "Starting OBS Studio..." "$StepNum of $AppCount  —  OBS"
    if (Test-Path $Script:Config.ObsPath) {
        $obsArgs = if ($Script:Config.ObsDynamicSceneMode) {
            $sc = if ($Script:radioMidweek.IsChecked -eq $true) { $Script:Config.ObsSceneMidweek } else { $Script:Config.ObsSceneWeekend }
            "--collection `"$sc`" --profile `"$($Script:Config.ObsProfile)`" --disable-shutdown-check --startvirtualcam --studio-mode"
        } else {
            "--disable-shutdown-check --startvirtualcam --studio-mode"
        }
        
        # Add always-on-top argument if enabled
        Write-Log "OBS Always-on-Top Mode: $($Script:Config.ObsAlwaysOnTopMode)"
        if ($Script:Config.ObsAlwaysOnTopMode) {
            $obsArgs += " --always-on-top"
            Write-Log "Added --always-on-top argument to OBS launch"
        }
        Write-Log "Final OBS arguments: $obsArgs"
        try {
            # Convert argument string to array for proper parsing
            $obsArgsArray = if ($obsArgs.Trim()) { 
                # Split arguments properly, respecting quoted parameters
                [System.Text.RegularExpressions.Regex]::Matches($obsArgs, '(?:[^\s"]+|"[^"]*")+') | ForEach-Object { $_.Value.Trim('"') }
            } else { 
                @() 
            }
            Write-Log "OBS arguments array: [$($obsArgsArray -join '], [')]"
            
            Start-Process -FilePath $Script:Config.ObsPath -ArgumentList $obsArgsArray `
                          -WorkingDirectory (Split-Path $Script:Config.ObsPath)
            Write-Log "Launched OBS with arguments: $($obsArgsArray -join ' ')"
        } catch { Write-Log "OBS launch failed: $($_.Exception.Message)" "ERROR" }
    } else { Write-Log "OBS path not found." "WARN" }
    Set-SetupStatus "Positioning OBS..." "$StepNum of $AppCount  —  OBS"
    Move-AppWindow -ProcessNames $Script:Config.ObsProcessNames -DisplayName "OBS" `
                   -X $Step.X -Y $Step.Y -W $Step.W -H $Step.H
}

function Invoke-ZoomStep {
    param($Step, $StepNum, $AppCount)
    Set-SetupStatus "Opening Participants sidebar in Zoom..." "$StepNum of $AppCount  —  Zoom"
    if (Test-Path $Script:Config.ZoomPath) {
        $zoomVisible = Get-Process -Name "Zoom" -ErrorAction SilentlyContinue |
                       Where-Object { $_.MainWindowHandle -ne 0 -and $_.MainWindowTitle -match "Meeting" }
        if (-not $zoomVisible) {
            Start-Process -FilePath $Script:Config.ZoomPath -ErrorAction SilentlyContinue
            Write-Log "Zoom activation triggered."
            Start-Sleep -Milliseconds $Script:Config.ZoomActivationWait
        }
        $zp = Find-AppMainWindow -ProcessNames $Script:Config.ZoomProcessNames -TimeoutSeconds 20 -TitleContains "Meeting"
        if ($zp) {
            $Script:window.Topmost = $false
            [Win32Native]::AllowSetForegroundWindow([Win32Native]::ASFW_ANY) | Out-Null
            [Win32Native]::SetForegroundWindow($zp.MainWindowHandle) | Out-Null
            Start-Sleep -Milliseconds $Script:Config.ZoomFocusSettle
            [System.Windows.Forms.SendKeys]::SendWait("%u")
            Write-Log "Alt+U sent to Zoom."
            Start-Sleep -Milliseconds $Script:Config.ZoomSidebarRender
        } else { Write-Log "Zoom Meeting window not found." "WARN" }
    } else { Write-Log "Zoom path not found." "WARN" }
    Set-SetupStatus "Positioning Zoom..." "$StepNum of $AppCount  —  Zoom"
    Move-AppWindow -ProcessNames $Script:Config.ZoomProcessNames -DisplayName "Zoom" `
                   -X $Step.X -Y $Step.Y -W $Step.W -H $Step.H -TitleContains "Meeting"
}

function Invoke-M3Step {
    param($Step, $StepNum, $AppCount)
    Set-SetupStatus "Starting Meeting Media Manager..." "$StepNum of $AppCount  —  M3"
    if (Test-Path $Script:Config.M3Path) {
        try { Start-Process -FilePath $Script:Config.M3Path; Write-Log "Launched M3." }
        catch { Write-Log "M3 launch failed: $($_.Exception.Message)" "ERROR" }
    } else { Write-Log "M3 path not found." "WARN" }
    Set-SetupStatus "Positioning Meeting Media Manager..." "$StepNum of $AppCount  —  M3"
    Move-AppWindow -ProcessNames $Script:Config.M3ProcessNames -DisplayName "M3" `
                   -X $Step.X -Y $Step.Y -W $Step.W -H $Step.H
}

function Invoke-OnlyTStep {
    # Already launched earlier in the flow (auto-launched on hardware-green) --
    # just re-position into its meeting-time tile.
    param($Step, $StepNum, $AppCount)
    Set-SetupStatus "Positioning OnlyT..." "$StepNum of $AppCount  —  OnlyT"
    Move-AppWindow -ProcessNames $Script:Config.OnlyTProcessNames -DisplayName "OnlyT" `
                   -X $Step.X -Y $Step.Y -W $Step.W -H $Step.H
}

function Set-EmeetVcamStatus {
    param([string]$Message)
    $Script:emeetVcamStatusText.Visibility = if ($Message) { 'Visible' } else { 'Collapsed' }
    $Script:emeetVcamStatusText.Text       = $Message
    $Script:window.Dispatcher.Invoke([action]{}, [System.Windows.Threading.DispatcherPriority]::Render)
}

function Send-EmeetAutoClicks {
    # Turns on EMEET STUDIO's virtual camera by replaying the same clicks an
    # operator would make by hand: open the V Cam tab, click Enable Virtual
    # Camera, then nudge the mouse down over the panel so it settles on the
    # right view. Coordinates are absolute screen pixels (1080p, 100% scale) --
    # matching where EMEET STUDIO was just positioned.
    function Send-Click {
        param([int]$X, [int]$Y)
        [System.Windows.Forms.Cursor]::Position = "$X,$Y"
        Start-Sleep -Milliseconds 80
        [Win32Native]::mouse_event([Win32Native]::MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0)
        Start-Sleep -Milliseconds 60
        [Win32Native]::mouse_event([Win32Native]::MOUSEEVENTF_LEFTUP, 0, 0, 0, 0)
    }

    Set-EmeetVcamStatus "Opening the V Cam tab..."
    Send-Click -X 1401 -Y 561
    Start-Sleep -Milliseconds 500

    Set-EmeetVcamStatus "Turning on the virtual camera..."
    Send-Click -X 1593 -Y 703
    Start-Sleep -Milliseconds 500

    Set-EmeetVcamStatus "Settling the view..."
    [System.Windows.Forms.Cursor]::Position = "1200,600"
    Start-Sleep -Milliseconds 500

    [Win32Native]::mouse_event([Win32Native]::MOUSEEVENTF_WHEEL, 0, 0, -2000, 0)
    Write-Log "EMEET STUDIO virtual-camera click sequence complete."
}

function Show-EmeetSetupScreen {
    $Script:window.Topmost = $false
    Set-EmeetVcamStatus ""
    $Script:btnEmeetEnable.IsEnabled = $true
    $Script:btnEmeetEnable.Content   = "⚡   Enable"
    Show-Screen "ScreenEmeetSetup"
    Update-MainSubway
}

function Enable-EmeetVcam {
    $Script:btnEmeetEnable.IsEnabled = $false
    $Script:window.Topmost = $false

    if (-not (Test-Path $Script:Config.EmeetPath)) {
        Set-EmeetVcamStatus "EMEET STUDIO wasn't found on this laptop -- skipping."
        Write-Log "EMEET STUDIO path not found: $($Script:Config.EmeetPath)" "WARN"
        Start-Sleep -Milliseconds 900
        $Script:State.EmeetVcamEnabled = $true
        Show-DetectionScreen
        return
    }

    $already = Get-Process -Name $Script:Config.EmeetProcessNames -ErrorAction SilentlyContinue |
               Where-Object { $_.MainWindowHandle -ne 0 }
    if ($already) {
        Set-EmeetVcamStatus "EMEET STUDIO is already running..."
        Write-Log "EMEET STUDIO already running for VCAM setup."
    } else {
        Set-EmeetVcamStatus "Opening EMEET STUDIO..."
        try {
            Start-Process -FilePath $Script:Config.EmeetPath `
                          -WorkingDirectory (Split-Path $Script:Config.EmeetPath)
            Write-Log "EMEET STUDIO launched for VCAM setup."
        } catch {
            Set-EmeetVcamStatus "Couldn't open EMEET STUDIO -- continuing without it."
            Write-Log "EMEET STUDIO launch failed: $($_.Exception.Message)" "ERROR"
            Start-Sleep -Milliseconds 900
            $Script:State.EmeetVcamEnabled = $true
            Show-DetectionScreen
            return
        }
    }

    $rect = $Script:Config.EmeetVcamRect
    $proc = Find-AppMainWindow -ProcessNames $Script:Config.EmeetProcessNames -TimeoutSeconds 25
    $vcamOk = $false
    if ($proc) {
        try {
            $landed = $false
            for ($attempt = 1; $attempt -le 2; $attempt++) {
                [Win32Native]::ShowWindow($proc.MainWindowHandle, [Win32Native]::SW_RESTORE) | Out-Null
                Start-Sleep -Milliseconds 300
                [Win32Native]::MoveWindow($proc.MainWindowHandle, $rect.X, $rect.Y, $rect.W, $rect.H, $true) | Out-Null
                [Win32Native]::AllowSetForegroundWindow([Win32Native]::ASFW_ANY) | Out-Null
                [Win32Native]::SetForegroundWindow($proc.MainWindowHandle) | Out-Null
                Start-Sleep -Milliseconds 300

                $winRect = New-Object Win32Native+RECT
                [Win32Native]::GetWindowRect($proc.MainWindowHandle, [ref]$winRect) | Out-Null
                $landed = ([Math]::Abs($winRect.Left - $rect.X) -le 10) -and ([Math]::Abs($winRect.Top - $rect.Y) -le 10) -and
                          ([Math]::Abs(($winRect.Right - $winRect.Left) - $rect.W) -le 20) -and
                          ([Math]::Abs(($winRect.Bottom - $winRect.Top) - $rect.H) -le 20)
                if ($landed) {
                    Write-Log "Positioned EMEET STUDIO for VCAM setup: ($($rect.X),$($rect.Y)) $($rect.W)x$($rect.H)"
                    break
                }
                Write-Log "EMEET STUDIO didn't land at the VCAM rect (attempt $attempt): wanted ($($rect.X),$($rect.Y)) $($rect.W)x$($rect.H), got ($($winRect.Left),$($winRect.Top)) $($winRect.Right - $winRect.Left)x$($winRect.Bottom - $winRect.Top)" "WARN"
            }

            if ($landed) {
                Start-Sleep -Milliseconds 500
                Send-EmeetAutoClicks
                $vcamOk = $true
            } else {
                # The click sequence targets fixed absolute coordinates that
                # only line up with the window at its VCAM rect -- clicking
                # blind at the wrong window position could hit the wrong
                # thing entirely, so skip the automation rather than guess.
                Set-EmeetVcamStatus "Couldn't position EMEET STUDIO -- enable the virtual camera manually, then continue."
                Write-Log "Skipped EMEET click automation -- window never landed at the expected rect." "ERROR"
            }
        } catch {
            Write-Log "EMEET STUDIO VCAM automation failed: $($_.Exception.Message)" "ERROR"
        }
    } else {
        Set-EmeetVcamStatus "Couldn't find the EMEET STUDIO window -- continuing without it."
        Write-Log "EMEET STUDIO window not found for VCAM setup." "WARN"
    }

    if ($vcamOk) {
        Set-EmeetVcamStatus "Virtual camera enabled."
        Start-Sleep -Milliseconds 700
    } else {
        Start-Sleep -Milliseconds 1500
    }
    $Script:State.EmeetVcamEnabled = $true
    Show-DetectionScreen
}

function Launch-StageCountdownNow {
    if (Test-Path $Script:Config.StageCountdownPath) {
        try {
            Start-Process -FilePath $Script:Config.StageCountdownPath
            Write-Log "StageCountdown launched."
        } catch {
            Write-Log "StageCountdown launch failed: $($_.Exception.Message)" "ERROR"
        }
    } else {
        Write-Log "StageCountdown path not found: $($Script:Config.StageCountdownPath)" "WARN"
    }
}

function Update-Detection {
    if ($Script:Config.TestMode) {
        $hw = @{ AcPower=$true; Internet=$true; Display=$true; Webcam=$true; UsbAudio=$true }
    } else {
        $hw = @{
            AcPower  = $Script:HwCache.AcPower
            Internet = $Script:HwCache.Internet
            Display  = $Script:HwCache.Display
            Webcam   = $Script:HwCache.Webcam
            UsbAudio = $Script:HwCache.UsbAudio
        }
    }
    if ($Script:State.Flow -eq "NonZoom") { $hw.Remove("UsbAudio") }

    foreach ($card in $Script:DetCards) { Update-DetectionCard $hw[$card.HwKey] $card }
    Update-DetectionSubway

    $allGreen = -not ($hw.Values -contains $false)

    if ($allGreen -and -not $Script:State.AllHwReady) {
        $Script:State.AllHwReady = $true
        $Script:detectionTimer.Stop()
        Update-MainSubway
        Write-Log "All hardware checks passed."

        if ($Script:State.Flow -eq "NonZoom") {
            Write-Log "Non-Zoom: auto-launching $($Script:State.NonZoomProgram)."
            Invoke-Launch
        } elseif ($Script:Config.OnlyTMode -and -not $Script:State.OnlyTLaunched) {
            $Script:State.OnlyTLaunched = $true
            $Script:State.OnlyTCodeStage = "Wired"
            Show-OnlyTCode
            $Script:detOnlyTConfirmQuestion.Text = "Is the timer display showing on the second laptop?"
            Launch-OnlyTNow
            $Script:detOnlyTConfirmPanel.Visibility = 'Visible'
        } else {
            Complete-OnlyTStep
        }
    }
}

function Show-ReadyPanel {
    $Script:detReadyPanel.Visibility = 'Visible'
    $d = Get-DefaultMeetingType
    if ($d -eq 'Midweek') { $Script:radioMidweek.IsChecked = $true }
    else                   { $Script:radioWeekend.IsChecked = $true }
    Set-MeetingTypeBadge $d
    Update-LaunchVisibility
}

function Update-LaunchVisibility {
    if ($Script:State.Flow -eq "NonZoom") { $Script:launchButton.Visibility = 'Collapsed'; return }
    $hasType = ($Script:radioMidweek.IsChecked -eq $true) -or ($Script:radioWeekend.IsChecked -eq $true)
    $Script:launchButton.Visibility = if ($hasType -and $Script:State.AllHwReady) { 'Visible' } else { 'Collapsed' }
}

# =============================================================================
#  SETUP WIZARD & SETTINGS MENU
# =============================================================================

function ConvertTo-Brush {
    param([string]$Hex)
    (New-Object System.Windows.Media.BrushConverter).ConvertFromString($Hex)
}

function Show-InitialSetup {
    $Script:welcomeOverlay.Visibility          = 'Collapsed'
    $Script:setupCongregationName.Text         = $Script:Config.CongregationName
    $Script:setupZoomHosting.IsChecked         = $Script:Config.ZoomSelfHostingMode
    $Script:setupObsScenes.IsChecked           = $Script:Config.ObsDynamicSceneMode
    $Script:setupObsSceneNamesPanel.Visibility = if ($Script:Config.ObsDynamicSceneMode) { 'Visible' } else { 'Collapsed' }
    $Script:setupObsSceneWeekend.Text          = $Script:Config.ObsSceneWeekend
    $Script:setupObsSceneMidweek.Text          = $Script:Config.ObsSceneMidweek
    $Script:setupObsAlwaysOnTop.IsChecked      = $Script:Config.ObsAlwaysOnTopMode
    $Script:setupStageCountdown.IsChecked      = $Script:Config.StageCountdownMode
    $Script:setupOverlay.Visibility            = 'Visible'
}

function Start-PreflightFlow {
    # The normal startup pipeline -- runs once a preference file is in place,
    # whether that's because it already existed, or the Setup Wizard just wrote one.
    Show-CurrentQuestion
    $Script:window.Topmost = $true
    Set-DetectionIcons
    Start-HardwarePolling

    if ($Script:Config.OnlyTMode) {
        $Script:State.OnlyTAccessCodes = Get-OnlyTAccessCodes
        Write-Log "OnlyT codes ready -- Wired: $(Format-AccessCodes $Script:State.OnlyTAccessCodes.Wired)  |  Wireless: $(Format-AccessCodes $Script:State.OnlyTAccessCodes.Wireless)"
    }

    $Script:zoomStartTimer          = New-Object System.Windows.Threading.DispatcherTimer
    $Script:zoomStartTimer.Interval = [TimeSpan]::FromMilliseconds(600)
    $Script:zoomStartTimer.Add_Tick({
        $Script:zoomStartTimer.Stop()
        $alreadyUp = Get-Process -Name "Zoom" -ErrorAction SilentlyContinue |
                     Where-Object { $_.MainWindowHandle -ne 0 -and $_.MainWindowTitle.Length -gt 0 }
        if ($alreadyUp) {
            Write-Log "Zoom already visible -- skipping background launch."
        } elseif (Test-Path $Script:Config.ZoomPath) {
            try   { Start-Process -FilePath $Script:Config.ZoomPath; Write-Log "Zoom launched in background." }
            catch { Write-Log "Zoom background launch failed: $($_.Exception.Message)" "WARN" }
        }
    })
    $Script:zoomStartTimer.Start()
}

# Keys never surfaced in the Settings UI -- technical paths/IDs, edit the
# preference file directly (or reinstall) to change these.
$Script:HiddenConfigKeys = @(
    'OnlyTMode','AdminMode','TestMode','WebcamInstanceId','UsbAudioInstanceId',
    'JwLibraryShortcut','StageCountdownPath','ObsPath','M3Path','ZoomPath','OnlyTPath',
    'EmeetIntegMode','EmeetPath'
)
# Keys already covered by the Simple tab (and Setup Wizard).
$Script:SimpleConfigKeys = @(
    'CongregationName','ZoomSelfHostingMode','ObsDynamicSceneMode',
    'ObsSceneWeekend','ObsSceneMidweek','StageCountdownMode'
)
# Structural/technical values that aren't a single toggle or text field.
$Script:TechnicalConfigKeys = @(
    'UiRefreshMs','PollIntervalSec','WindowWaitSeconds','ZoomActivationWait',
    'ZoomFocusSettle','ZoomSidebarRender','FinalMessageHold','VideoErrorHold',
    'DataFolder','Layout','LayoutStandard','LayoutOnlyT','LayoutEmeet','LayoutEmeetOnlyT',
    'EmeetVcamRect','OnlyTWebPort',
    'M3ProcessNames','ZoomProcessNames','ObsProcessNames','OnlyTProcessNames','EmeetProcessNames','StageCountdownProcessNames'
)
$Script:FriendlyConfigLabels = @{
    BluetoothMode       = "Use Bluetooth mixer link"
    BluetoothInstanceId = "Bluetooth device ID"
    BluetoothDeviceName = "Bluetooth device name"
    ObsProfile          = "OBS profile name"
    WebcamName          = "Camera display name"
}

function Build-AdvancedSettingsPanel {
    $Script:settingsAdvancedPanel.Children.Clear()
    $Script:AdvancedControls = @{}

    $keys = $Script:Config.Keys | Where-Object {
        $_ -notin $Script:HiddenConfigKeys -and
        $_ -notin $Script:SimpleConfigKeys -and
        $_ -notin $Script:TechnicalConfigKeys -and
        ($Script:Config[$_] -is [bool] -or $Script:Config[$_] -is [string])
    } | Sort-Object

    foreach ($key in $keys) {
        $value = $Script:Config[$key]
        $label = if ($Script:FriendlyConfigLabels.ContainsKey($key)) {
            $Script:FriendlyConfigLabels[$key]
        } else {
            ($key -creplace '([a-z])([A-Z])', '$1 $2')
        }

        $row  = New-Object System.Windows.Controls.Grid
        $row.Margin = '0,0,0,22'
        $col1 = New-Object System.Windows.Controls.ColumnDefinition
        $col1.Width = New-Object System.Windows.GridLength(1, [System.Windows.GridUnitType]::Star)
        $col2 = New-Object System.Windows.Controls.ColumnDefinition
        $col2.Width = [System.Windows.GridLength]::Auto
        [void]$row.ColumnDefinitions.Add($col1)
        [void]$row.ColumnDefinitions.Add($col2)

        $lbl = New-Object System.Windows.Controls.TextBlock
        $lbl.Text              = $label
        $lbl.Foreground        = ConvertTo-Brush '#D1D5DB'
        $lbl.FontSize          = 16
        $lbl.FontWeight        = 'SemiBold'
        $lbl.TextWrapping      = 'Wrap'
        $lbl.VerticalAlignment = 'Center'
        $lbl.Margin            = '0,0,24,0'
        [System.Windows.Controls.Grid]::SetColumn($lbl, 0)
        [void]$row.Children.Add($lbl)

        if ($value -is [bool]) {
            $ctrl = New-Object System.Windows.Controls.CheckBox
            $ctrl.Style     = $Script:window.FindResource("ToggleSwitchStyle")
            $ctrl.IsChecked = $value
        } else {
            $ctrl = New-Object System.Windows.Controls.TextBox
            $ctrl.Style = $Script:window.FindResource("SettingsTextBox")
            $ctrl.Text  = $value
            $ctrl.Width = 380
        }
        $ctrl.VerticalAlignment = 'Center'
        [System.Windows.Controls.Grid]::SetColumn($ctrl, 1)
        [void]$row.Children.Add($ctrl)

        [void]$Script:settingsAdvancedPanel.Children.Add($row)
        $Script:AdvancedControls[$key] = $ctrl
    }
}

function Show-SettingsTab {
    param([string]$Tab)
    $Script:settingsSimplePanel.Visibility   = if ($Tab -eq "Simple")   { 'Visible' } else { 'Collapsed' }
    $Script:settingsAdvancedPanel.Visibility = if ($Tab -eq "Advanced") { 'Visible' } else { 'Collapsed' }
    $Script:settingsLayoutPanel.Visibility   = if ($Tab -eq "Layout")   { 'Visible' } else { 'Collapsed' }

    foreach ($pair in @(
        @{ Btn = $Script:btnSettingsTabSimple;   Match = "Simple" }
        @{ Btn = $Script:btnSettingsTabAdvanced; Match = "Advanced" }
        @{ Btn = $Script:btnSettingsTabLayout;   Match = "Layout" }
    )) {
        if ($pair.Match -eq $Tab) {
            $pair.Btn.Background = ConvertTo-Brush '#132040'
            $pair.Btn.Foreground = ConvertTo-Brush '#60A5FA'
        } else {
            $pair.Btn.Background = ConvertTo-Brush '#1A1D2E'
            $pair.Btn.Foreground = ConvertTo-Brush '#9CA3AF'
        }
    }

    if ($Tab -eq "Layout" -and -not $Script:LayoutEditorCurrentMode) {
        Show-LayoutMode -ModeName (Get-PreflightModeName)
    }
}

$Script:LayoutEditorRowsByMode  = @{}
$Script:LayoutEditorCurrentMode = $null
$Script:LayoutAppLabels = @{ Obs = "OBS"; Zoom = "Zoom"; M3 = "M3"; OnlyT = "OnlyT"; Emeet = "EMEET" }
$Script:LayoutModeLabels = @{ Standard = "Standard"; OnlyT = "OnlyT"; Emeet = "EMEET"; EmeetOnlyT = "EMEET+OnlyT" }

function Show-LayoutMode {
    param([string]$ModeName)
    $Script:LayoutEditorCurrentMode = $ModeName
    if (-not $Script:LayoutEditorRowsByMode.ContainsKey($ModeName)) {
        # Deep-copy so editing doesn't mutate the resolved defaults/overrides directly.
        $Script:LayoutEditorRowsByMode[$ModeName] = @(Resolve-LaunchSequence -ModeName $ModeName | ForEach-Object {
            @{ App = $_.App; Order = $_.Order; X = $_.X; Y = $_.Y; W = $_.W; H = $_.H; DelayMs = $_.DelayMs }
        })
    }

    foreach ($pair in @(
        @{ Btn = $Script:btnLayoutModeStandard;   Match = "Standard" }
        @{ Btn = $Script:btnLayoutModeOnlyT;      Match = "OnlyT" }
        @{ Btn = $Script:btnLayoutModeEmeet;      Match = "Emeet" }
        @{ Btn = $Script:btnLayoutModeEmeetOnlyT; Match = "EmeetOnlyT" }
    )) {
        if ($pair.Match -eq $ModeName) {
            $pair.Btn.Background = ConvertTo-Brush '#132040'
            $pair.Btn.Foreground = ConvertTo-Brush '#60A5FA'
        } else {
            $pair.Btn.Background = ConvertTo-Brush '#1A1D2E'
            $pair.Btn.Foreground = ConvertTo-Brush '#9CA3AF'
        }
    }

    Build-LayoutRows
}

function New-LayoutFieldBox {
    param([string]$Text, [int]$Width, [scriptblock]$OnCommit)
    $tb = New-Object System.Windows.Controls.TextBox
    $tb.Style = $Script:window.FindResource("LayoutPillTextBox")
    $tb.Text  = $Text
    $tb.Width = $Width
    $tb.MinWidth = $Width  # Ensure minimum width
    $tb.Add_LostFocus({
        param($s, $e)
        & $OnCommit $s.Text
    }.GetNewClosure())
    return $tb
}

function Build-LayoutRows {
    $Script:layoutRowsContainer.Children.Clear()
    $rows = @($Script:LayoutEditorRowsByMode[$Script:LayoutEditorCurrentMode] | Sort-Object Order)

    for ($i = 0; $i -lt $rows.Count; $i++) {
        $row = $rows[$i]

        $card = New-Object System.Windows.Controls.Border
        $card.Background   = ConvertTo-Brush '#161923'
        $card.CornerRadius = [System.Windows.CornerRadius]::new(14)
        $card.Padding      = [System.Windows.Thickness]::new(16,12,16,12)
        $card.Margin       = [System.Windows.Thickness]::new(0,0,0,8)

        $grid = New-Object System.Windows.Controls.Grid
        foreach ($w in @('200','*','Auto','Auto')) {
            $cd = New-Object System.Windows.Controls.ColumnDefinition
            $cd.Width = if ($w -eq '*') { 
                [System.Windows.GridLength]::new(1,[System.Windows.GridUnitType]::Star) 
            } elseif ($w -match '^\d+$') { 
                [System.Windows.GridLength]::new([double]$w) 
            } else { 
                [System.Windows.GridLength]::Auto 
            }
            [void]$grid.ColumnDefinitions.Add($cd)
        }

        # --- Column 0: order badge + app name ---
        $left = New-Object System.Windows.Controls.StackPanel
        $left.Orientation = 'Horizontal'
        $left.VerticalAlignment = 'Center'
        $left.Margin = [System.Windows.Thickness]::new(0,0,16,0)

        $badge = New-Object System.Windows.Controls.Border
        $badge.Background = ConvertTo-Brush '#0F2040'
        $badge.CornerRadius = [System.Windows.CornerRadius]::new(18)
        $badge.Width = 36; $badge.Height = 36
        $badge.Margin = [System.Windows.Thickness]::new(0,0,12,0)
        $badgeText = New-Object System.Windows.Controls.TextBlock
        $badgeText.Text = "$($row.Order)"
        $badgeText.Foreground = ConvertTo-Brush '#60A5FA'
        $badgeText.FontWeight = 'Bold'; $badgeText.FontSize = 16
        $badgeText.HorizontalAlignment = 'Center'; $badgeText.VerticalAlignment = 'Center'
        [void]$badge.Child <#dummy#>
        $badge.Child = $badgeText
        [void]$left.Children.Add($badge)

        $nameText = New-Object System.Windows.Controls.TextBlock
        $nameText.Text = $Script:LayoutAppLabels[$row.App]
        $nameText.Foreground = ConvertTo-Brush '#F1F5F9'
        $nameText.FontWeight = 'Bold'; $nameText.FontSize = 20
        $nameText.VerticalAlignment = 'Center'
        [void]$left.Children.Add($nameText)

        [System.Windows.Controls.Grid]::SetColumn($left, 0)
        [void]$grid.Children.Add($left)

        # --- Column 1: pills (size / X / Y / delay) ---
        $pills = New-Object System.Windows.Controls.StackPanel
        $pills.Orientation = 'Horizontal'
        $pills.VerticalAlignment = 'Center'

        $wBox = New-LayoutFieldBox -Text "$($row.W)" -Width 80 -OnCommit { param($t) $row.W = [int]($t -as [int]) }.GetNewClosure()
        $hBox = New-LayoutFieldBox -Text "$($row.H)" -Width 80 -OnCommit { param($t) $row.H = [int]($t -as [int]) }.GetNewClosure()
        $sizePill = New-Object System.Windows.Controls.Border
        $sizePill.Background = ConvertTo-Brush '#0D0F17'
        $sizePill.CornerRadius = [System.Windows.CornerRadius]::new(18)
        $sizePill.Padding = [System.Windows.Thickness]::new(8,3,8,3)
        $sizePill.Margin = [System.Windows.Thickness]::new(0,0,8,0)
        $sizeInner = New-Object System.Windows.Controls.StackPanel
        $sizeInner.Orientation = 'Horizontal'
        [void]$sizeInner.Children.Add($wBox)
        $xLbl = New-Object System.Windows.Controls.TextBlock
        $xLbl.Text = " x "; $xLbl.Foreground = ConvertTo-Brush '#4B5563'
        $xLbl.VerticalAlignment = 'Center'; $xLbl.FontWeight = 'Bold'
        [void]$sizeInner.Children.Add($xLbl)
        [void]$sizeInner.Children.Add($hBox)
        $sizePill.Child = $sizeInner
        [void]$pills.Children.Add($sizePill)

        function New-LabeledPill {
            param([string]$Label, $Box)
            $pill = New-Object System.Windows.Controls.Border
            $pill.Background = ConvertTo-Brush '#0D0F17'
            $pill.CornerRadius = [System.Windows.CornerRadius]::new(18)
            $pill.Padding = [System.Windows.Thickness]::new(8,3,8,3)
            $pill.Margin = [System.Windows.Thickness]::new(0,0,8,0)
            $inner = New-Object System.Windows.Controls.StackPanel
            $inner.Orientation = 'Horizontal'
            $lbl = New-Object System.Windows.Controls.TextBlock
            $lbl.Text = "$Label`: "; $lbl.Foreground = ConvertTo-Brush '#4B5563'
            $lbl.VerticalAlignment = 'Center'; $lbl.FontWeight = 'Bold'; $lbl.FontSize = 14
            [void]$inner.Children.Add($lbl)
            [void]$inner.Children.Add($Box)
            $pill.Child = $inner
            return $pill
        }

        $xBox = New-LayoutFieldBox -Text "$($row.X)" -Width 75 -OnCommit { param($t) $row.X = [int]($t -as [int]) }.GetNewClosure()
        $yBox = New-LayoutFieldBox -Text "$($row.Y)" -Width 75 -OnCommit { param($t) $row.Y = [int]($t -as [int]) }.GetNewClosure()
        $delayBox = New-LayoutFieldBox -Text "$($row.DelayMs)" -Width 75 -OnCommit { param($t) $row.DelayMs = [int]($t -as [int]) }.GetNewClosure()

        [void]$pills.Children.Add((New-LabeledPill "X" $xBox))
        [void]$pills.Children.Add((New-LabeledPill "Y" $yBox))
        [void]$pills.Children.Add((New-LabeledPill "MS" $delayBox))

        [System.Windows.Controls.Grid]::SetColumn($pills, 1)
        [void]$grid.Children.Add($pills)

        # --- Column 2: reorder arrows ---
        $arrows = New-Object System.Windows.Controls.StackPanel
        $arrows.VerticalAlignment = 'Center'
        $arrows.Margin = [System.Windows.Thickness]::new(12,0,0,0)
        $upBtn = New-Object System.Windows.Controls.Button
        $upBtn.Style = $Script:window.FindResource("LayoutOrderBtn")
        $upBtn.Content = [char]0x25B2
        $upBtn.Margin = [System.Windows.Thickness]::new(0,0,0,3)
        $upBtn.IsEnabled = ($i -gt 0)
        $upBtn.Tag = $row.App
        $upBtn.Add_Click({ param($s,$e) Move-LayoutRow -App $s.Tag -Direction -1 }.GetNewClosure())
        [void]$arrows.Children.Add($upBtn)

        $downBtn = New-Object System.Windows.Controls.Button
        $downBtn.Style = $Script:window.FindResource("LayoutOrderBtn")
        $downBtn.Content = [char]0x25BC
        $downBtn.IsEnabled = ($i -lt $rows.Count - 1)
        $downBtn.Tag = $row.App
        $downBtn.Add_Click({ param($s,$e) Move-LayoutRow -App $s.Tag -Direction 1 }.GetNewClosure())
        [void]$arrows.Children.Add($downBtn)

        [System.Windows.Controls.Grid]::SetColumn($arrows, 3)
        [void]$grid.Children.Add($arrows)

        $card.Child = $grid
        [void]$Script:layoutRowsContainer.Children.Add($card)
    }
}

function Move-LayoutRow {
    param([string]$App, [int]$Direction)
    $rows = @($Script:LayoutEditorRowsByMode[$Script:LayoutEditorCurrentMode] | Sort-Object Order)
    $idx  = 0..($rows.Count-1) | Where-Object { $rows[$_].App -eq $App }
    $swapIdx = $idx + $Direction
    if ($swapIdx -lt 0 -or $swapIdx -ge $rows.Count) { return }
    $tmp = $rows[$idx].Order
    $rows[$idx].Order     = $rows[$swapIdx].Order
    $rows[$swapIdx].Order = $tmp
    Build-LayoutRows
}

# =============================================================================
#  ENHANCED LAYOUT FUNCTIONS (PowerShell Integration & Visual Tools)
# =============================================================================
function Update-LayoutToolsStatus {
    param([string]$Message, [string]$Color = "#9CA3AF")
    $Script:layoutToolsStatus.Text = $Message
    $Script:layoutToolsStatus.Foreground = ConvertTo-Brush $Color
    $Script:window.Dispatcher.Invoke([action]{}, [System.Windows.Threading.DispatcherPriority]::Render)
}

function Invoke-CaptureCurrentPositions {
    if (-not $Script:LayoutEditorCurrentMode) { 
        Update-LayoutToolsStatus "Please select a layout mode first" "#EF4444"
        return 
    }
    
    Update-LayoutToolsStatus "Capturing window positions..." "#60A5FA"
    
    try {
        $positions = Get-AllAppPositions
        $rows = $Script:LayoutEditorRowsByMode[$Script:LayoutEditorCurrentMode]
        $updated = 0
        
        foreach ($row in $rows) {
            if ($positions.ContainsKey($row.App)) {
                $pos = $positions[$row.App]
                $row.X = $pos.X
                $row.Y = $pos.Y  
                $row.W = $pos.W
                $row.H = $pos.H
                $updated++
            }
        }
        
        if ($updated -gt 0) {
            Build-LayoutRows
            Update-LayoutToolsStatus "Captured $updated app positions successfully" "#10B981"
        } else {
            Update-LayoutToolsStatus "No running applications found to capture" "#F59E0B"
        }
    } catch {
        Update-LayoutToolsStatus "Error capturing positions: $($_.Exception.Message)" "#EF4444"
        Write-Log "Position capture error: $($_.Exception.Message)" "ERROR"
    }
}

function Invoke-DetectScreenResolution {
    Update-LayoutToolsStatus "Detecting screen resolution..." "#60A5FA"
    
    try {
        $screen = Get-ScreenResolution
        $message = "Screen: $($screen.Width)x$($screen.Height), Working: $($screen.WorkingWidth)x$($screen.WorkingHeight)"
        Update-LayoutToolsStatus $message "#10B981"
        
        Write-Log "Screen Resolution - $message"
    } catch {
        Update-LayoutToolsStatus "Error detecting resolution: $($_.Exception.Message)" "#EF4444"
    }
}

function Invoke-LayoutPreset {
    param([string]$PresetType)
    
    if (-not $Script:LayoutEditorCurrentMode) { 
        Update-LayoutToolsStatus "Please select a layout mode first" "#EF4444"
        return 
    }
    
    $rows = @($Script:LayoutEditorRowsByMode[$Script:LayoutEditorCurrentMode] | Sort-Object Order)
    if ($rows.Count -eq 0) { return }
    
    try {
        $screen = Get-ScreenResolution
        $row = $rows[0]  # Apply to first app for demonstration
        
        switch ($PresetType) {
            "TileLeft" {
                $row.X = 0; $row.Y = 0
                $row.W = [int]($screen.WorkingWidth / 2); $row.H = $screen.WorkingHeight
            }
            "TileRight" {
                $row.X = [int]($screen.WorkingWidth / 2); $row.Y = 0
                $row.W = [int]($screen.WorkingWidth / 2); $row.H = $screen.WorkingHeight
            }
            "Center" {
                $row.W = [int]($screen.WorkingWidth * 0.7); $row.H = [int]($screen.WorkingHeight * 0.7)
                $row.X = [int](($screen.WorkingWidth - $row.W) / 2); $row.Y = [int](($screen.WorkingHeight - $row.H) / 2)
            }
            "Fullscreen" {
                $row.X = 0; $row.Y = 0; $row.W = $screen.WorkingWidth; $row.H = $screen.WorkingHeight
            }
        }
        
        Build-LayoutRows
        Update-LayoutToolsStatus "Applied $PresetType preset to $($Script:LayoutAppLabels[$row.App])" "#10B981"
    } catch {
        Update-LayoutToolsStatus "Error applying preset: $($_.Exception.Message)" "#EF4444"
    }
}

function Invoke-ValidateLayout {
    if (-not $Script:LayoutEditorCurrentMode) { 
        Update-LayoutToolsStatus "Please select a layout mode first" "#EF4444"
        return 
    }
    
    try {
        $screen = Get-ScreenResolution
        $rows = $Script:LayoutEditorRowsByMode[$Script:LayoutEditorCurrentMode]
        $issues = @()
        
        foreach ($row in $rows) {
            if ($row.X + $row.W -gt $screen.WorkingWidth) {
                $issues += "$($Script:LayoutAppLabels[$row.App]) extends beyond right edge"
            }
            if ($row.Y + $row.H -gt $screen.WorkingHeight) {
                $issues += "$($Script:LayoutAppLabels[$row.App]) extends beyond bottom edge"  
            }
            if ($row.X -lt 0 -or $row.Y -lt 0) {
                $issues += "$($Script:LayoutAppLabels[$row.App]) has negative coordinates"
            }
            if ($row.W -le 0 -or $row.H -le 0) {
                $issues += "$($Script:LayoutAppLabels[$row.App]) has invalid size"
            }
        }
        
        if ($issues.Count -eq 0) {
            Update-LayoutToolsStatus "✓ Layout validation passed - all windows fit within screen bounds" "#10B981"
        } else {
            $message = "⚠ Found $($issues.Count) issue(s): " + ($issues -join ", ")
            Update-LayoutToolsStatus $message "#F59E0B"
        }
    } catch {
        Update-LayoutToolsStatus "Error validating layout: $($_.Exception.Message)" "#EF4444"
    }
}

function Invoke-SaveLayoutMode {
    if (-not $Script:LayoutEditorCurrentMode) { 
        Update-LayoutToolsStatus "Please select a layout mode first" "#EF4444"
        return 
    }
    
    try {
        $rows = $Script:LayoutEditorRowsByMode[$Script:LayoutEditorCurrentMode]
        Save-PreflightLayoutMode -ModeName $Script:LayoutEditorCurrentMode -Rows $rows
        Update-LayoutToolsStatus "Layout saved successfully" "#10B981"
    } catch {
        Update-LayoutToolsStatus "Error saving layout: $($_.Exception.Message)" "#EF4444"
        Write-Log "Layout save error: $($_.Exception.Message)" "ERROR"
    }
}

function Show-LayoutPreview {
    # Creates a visual preview window showing app positions scaled to screen
    if (-not $Script:LayoutEditorCurrentMode) { 
        Update-LayoutToolsStatus "Please select a layout mode first" "#EF4444"
        return 
    }
    
    try {
        $screen = Get-ScreenResolution
        $rows = @($Script:LayoutEditorRowsByMode[$Script:LayoutEditorCurrentMode] | Sort-Object Order)
        
        # Create preview XAML with scaled representation
        $scale = 0.3  # 30% scale for preview
        $previewW = [int]($screen.WorkingWidth * $scale)
        $previewH = [int]($screen.WorkingHeight * $scale)
        
        $previewXaml = @"
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation" 
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="Layout Preview - $($Script:LayoutModeLabels[$Script:LayoutEditorCurrentMode])"
        Width="$(20 + $previewW)" Height="$(60 + $previewH)" 
        ResizeMode="NoResize" WindowStartupLocation="CenterScreen"
        Background="#0D0F17">
    <Grid Margin="10">
        <Border Background="#1A1D2E" CornerRadius="8">
            <Canvas Width="$previewW" Height="$previewH" Background="#0F1118" Margin="5">
"@
        
        # Add rectangles for each app
        $colors = @("#EF4444", "#10B981", "#F59E0B", "#8B5CF6", "#06B6D4")
        for ($i = 0; $i -lt $rows.Count; $i++) {
            $row = $rows[$i]
            $color = $colors[$i % $colors.Count]
            $x = [int]($row.X * $scale)
            $y = [int]($row.Y * $scale)  
            $w = [int]($row.W * $scale)
            $h = [int]($row.H * $scale)
            
            $previewXaml += @"
                <Rectangle Canvas.Left="$x" Canvas.Top="$y" Width="$w" Height="$h"
                          Fill="$color" Opacity="0.7" Stroke="$color" StrokeThickness="2"/>
                <TextBlock Canvas.Left="$([int]($x + 5))" Canvas.Top="$([int]($y + 5))"
                          Text="$($row.Order). $($Script:LayoutAppLabels[$row.App])"
                          Foreground="White" FontSize="10" FontWeight="Bold"/>
"@
        }
        
        $previewXaml += @"
            </Canvas>
        </Border>
    </Grid>
</Window>
"@
        
        # Show preview window
        $previewWindow = [Windows.Markup.XamlReader]::Parse($previewXaml)
        [void]$previewWindow.ShowDialog()
        
        Update-LayoutToolsStatus "Preview window closed" "#10B981"
        
    } catch {
        Update-LayoutToolsStatus "Error showing preview: $($_.Exception.Message)" "#EF4444"
        Write-Log "Preview error: $($_.Exception.Message)" "ERROR"
    }
}

function Show-SettingsMenu {
    $Script:setCongregationName.Text         = $Script:Config.CongregationName
    $Script:setZoomHosting.IsChecked         = $Script:Config.ZoomSelfHostingMode
    $Script:setObsScenes.IsChecked           = $Script:Config.ObsDynamicSceneMode
    $Script:setObsSceneNamesPanel.Visibility = if ($Script:Config.ObsDynamicSceneMode) { 'Visible' } else { 'Collapsed' }
    $Script:setObsSceneWeekend.Text          = $Script:Config.ObsSceneWeekend
    $Script:setObsSceneMidweek.Text          = $Script:Config.ObsSceneMidweek
    $Script:setObsAlwaysOnTop.IsChecked      = $Script:Config.ObsAlwaysOnTopMode
    $Script:setStageCountdown.IsChecked      = $Script:Config.StageCountdownMode

    Build-AdvancedSettingsPanel
    Show-SettingsTab "Simple"
    $Script:settingsOverlay.Visibility = 'Visible'
}

# =============================================================================
#  LAUNCH SEQUENCE
# =============================================================================

function Set-SetupStatus {
    param([string]$Message, [string]$Step = "")
    $Script:setupStatusText.Text = $Message
    $Script:setupStepText.Text   = $Step
    $Script:window.Dispatcher.Invoke([action]{}, [System.Windows.Threading.DispatcherPriority]::Render)
    Write-Log "Setup: $Message"
}

function Find-AppMainWindow {
    param([string[]]$ProcessNames, [int]$TimeoutSeconds = 30, [string]$TitleContains = "")
    $deadline = (Get-Date).AddSeconds($TimeoutSeconds)
    while ((Get-Date) -lt $deadline) {
        foreach ($name in $ProcessNames) {
            $proc = Get-Process -Name $name -ErrorAction SilentlyContinue |
                    Where-Object {
                        $_.MainWindowHandle -ne 0 -and
                        $_.MainWindowTitle.Length -gt 0 -and
                        ($TitleContains -eq "" -or $_.MainWindowTitle -match $TitleContains)
                    } | Select-Object -First 1
            if ($proc) { return $proc }
        }
        Start-Sleep -Milliseconds 500
    }
    return $null
}

function Move-AppWindow {
    param([string[]]$ProcessNames, [string]$DisplayName,
          [int]$X, [int]$Y, [int]$W, [int]$H, [string]$TitleContains = "")
    $proc = Find-AppMainWindow -ProcessNames $ProcessNames `
                               -TimeoutSeconds $Script:Config.WindowWaitSeconds `
                               -TitleContains $TitleContains
    if (-not $proc) { Write-Log "Timed out waiting for $DisplayName" "WARN"; return }

    for ($attempt = 1; $attempt -le 2; $attempt++) {
        try {
            [Win32Native]::ShowWindow($proc.MainWindowHandle, [Win32Native]::SW_RESTORE) | Out-Null
            Start-Sleep -Milliseconds 400
            [Win32Native]::MoveWindow($proc.MainWindowHandle, $X, $Y, $W, $H, $true) | Out-Null
            Start-Sleep -Milliseconds 250

            $rect = New-Object Win32Native+RECT
            [Win32Native]::GetWindowRect($proc.MainWindowHandle, [ref]$rect) | Out-Null
            $gotX = $rect.Left; $gotY = $rect.Top
            $gotW = $rect.Right - $rect.Left; $gotH = $rect.Bottom - $rect.Top
            # Windows often reports a few px of invisible drop-shadow border in
            # GetWindowRect, so allow a small tolerance rather than demanding
            # an exact pixel match.
            $close = ([Math]::Abs($gotX - $X) -le 10) -and ([Math]::Abs($gotY - $Y) -le 10) -and
                     ([Math]::Abs($gotW - $W) -le 20) -and ([Math]::Abs($gotH - $H) -le 20)

            if ($close) {
                Write-Log "Positioned ${DisplayName}: ($X,$Y) ${W}x${H}"
                return
            } else {
                Write-Log "${DisplayName} didn't land where expected (attempt $attempt): wanted ($X,$Y) ${W}x${H}, got ($gotX,$gotY) ${gotW}x${gotH}" "WARN"
                if ($attempt -eq 1) { Start-Sleep -Milliseconds 500 }
            }
        } catch { Write-Log "MoveWindow failed for ${DisplayName}: $($_.Exception.Message)" "ERROR" }
    }
}

function Show-BluetoothSetupScreen {
    # First step of Equipment Check when BluetoothMode is on. Topmost goes off
    # here since the operator needs to interact with the real Windows
    # Bluetooth Settings window, not just this app.
    $Script:window.Topmost = $false
    $Script:btSubQ1Panel.Visibility = 'Visible'
    $Script:btSubQ2Panel.Visibility = 'Collapsed'
    $Script:btInstructionsPanel.Visibility = 'Collapsed'
    $Script:btRestartingPanel.Visibility = 'Collapsed'
    $Script:btCheckStatusText.Visibility = 'Collapsed'

    $photoPath = Join-Path $Script:MediaFolder "check-bluetooth-mixer-enable.jpg"
    if (Test-Path $photoPath) {
        try {
            $bmp = [System.Windows.Media.Imaging.BitmapImage]::new()
            $bmp.BeginInit()
            $bmp.UriSource   = [Uri]::new($photoPath)
            $bmp.CacheOption = [System.Windows.Media.Imaging.BitmapCacheOption]::OnLoad
            $bmp.EndInit()
            $Script:btMixerPhotoImage.Source = $bmp
        } catch { Write-Log "Bluetooth mixer photo load failed: $($_.Exception.Message)" "WARN" }
    } else {
        Write-Log "Bluetooth mixer photo not found: $photoPath" "WARN"
    }

    Show-Screen "ScreenBluetoothSetup"
    Update-MainSubway
    Write-Log "Bluetooth setup: showing mixer sub-question."
}

function Open-BluetoothSettingsPositioned {
    # Launches the Windows Bluetooth Settings page and tries to move it over
    # the reference-photo panel so it visually replaces the picture.
    # NOTE: the Settings app is hosted under different process names across
    # Windows versions (SystemSettings.exe vs ApplicationFrameHost.exe) --
    # this tries both, but hasn't been verified on every build. If it doesn't
    # land in the right spot, preflight.log will show what happened; the
    # operator can still just move/resize the Settings window manually.
    # Drop our own Topmost flag first -- otherwise the preflight window stays
    # pinned above Settings no matter what we do to the Settings window below.
    $Script:window.Topmost = $false

    try {
        Start-Process "ms-settings:bluetooth"
        Write-Log "Launched ms-settings:bluetooth."
        $Script:State.BluetoothSettingsOpened = $true
    } catch {
        Write-Log "Failed to launch Bluetooth settings: $($_.Exception.Message)" "ERROR"
        return
    }

    Start-Sleep -Milliseconds 1200
    $proc = Find-AppMainWindow -ProcessNames @("SystemSettings","ApplicationFrameHost") `
                                -TimeoutSeconds 8 -TitleContains "Settings"
    if (-not $proc) {
        Write-Log "Bluetooth Settings window not found -- could not auto-position it." "WARN"
        return
    }

    try {
        $topLeft = $Script:btSettingsAnchor.PointToScreen([System.Windows.Point]::new(0,0))
        $w = [int]$Script:btSettingsAnchor.ActualWidth
        $h = [int]$Script:btSettingsAnchor.ActualHeight
        [Win32Native]::ShowWindow($proc.MainWindowHandle, [Win32Native]::SW_RESTORE) | Out-Null
        Start-Sleep -Milliseconds 300
        [Win32Native]::MoveWindow($proc.MainWindowHandle, [int]$topLeft.X, [int]$topLeft.Y, $w, $h, $true) | Out-Null
        [Win32Native]::AllowSetForegroundWindow([Win32Native]::ASFW_ANY) | Out-Null
        [Win32Native]::SetForegroundWindow($proc.MainWindowHandle) | Out-Null
        Write-Log "Positioned Bluetooth Settings window over the reference panel and brought it to front."
    } catch {
        Write-Log "Could not position Bluetooth Settings window: $($_.Exception.Message)" "WARN"
    }
}

function Close-BluetoothSettingsWindow {
    # The Bluetooth Settings window is only useful during the Equipment Check
    # Bluetooth step. By the time Detection shows, its job is done -- close it
    # so it doesn't sit open (and potentially overlap) through the rest of the
    # flow. Skipped entirely if we never actually opened it.
    if (-not $Script:State.BluetoothSettingsOpened) { return }
    try {
        $proc = Get-Process -Name @("SystemSettings", "ApplicationFrameHost") -ErrorAction SilentlyContinue |
                Where-Object { $_.MainWindowHandle -ne 0 -and $_.MainWindowTitle -match "Settings" } |
                Select-Object -First 1
        if ($proc) {
            $proc.CloseMainWindow() | Out-Null
            Write-Log "Closed Bluetooth Settings window ahead of Detection screen."
        }
    } catch {
        Write-Log "Could not close Bluetooth Settings window: $($_.Exception.Message)" "WARN"
    }
    $Script:State.BluetoothSettingsOpened = $false
}

function Restart-BluetoothAdapter {
    # Turns the Bluetooth adapter off then on. Requires admin rights and the
    # PnpDevice cmdlets; best-effort like the other hardware calls in this
    # script -- failures are logged, not shown to the operator.
    if ($Script:Config.TestMode) {
        Write-Log "TEST MODE -- Bluetooth adapter restart simulated."
        return
    }
    try {
        $adapters = Get-PnpDevice -Class Bluetooth -PresentOnly -ErrorAction Stop
        foreach ($a in $adapters) { Disable-PnpDevice -InstanceId $a.InstanceId -Confirm:$false -ErrorAction SilentlyContinue }
        Start-Sleep -Milliseconds 500
        foreach ($a in $adapters) { Enable-PnpDevice -InstanceId $a.InstanceId -Confirm:$false -ErrorAction SilentlyContinue }
        Write-Log "Bluetooth adapter restarted (off then on)."
    } catch {
        Write-Log "Bluetooth adapter restart failed: $($_.Exception.Message)" "WARN"
    }
}

$Script:btnBtSubQ1Yes.Add_Click({
    $Script:btSubQ1Panel.Visibility = 'Collapsed'
    $Script:btSubQ2Panel.Visibility = 'Visible'
    $Script:btDeviceNameRun.Text = $Script:Config.BluetoothDeviceName
    Write-Log "Bluetooth setup: mixer confirmed on -- showing connect sub-question."
    Open-BluetoothSettingsPositioned
})

$Script:btnEmeetEnable.Add_Click({ Enable-EmeetVcam })

$Script:btnBluetoothCheck.Add_Click({
    $connected = if ($Script:Config.TestMode) {
        $true
    } else {
        [bool](Get-PnpDevice -PresentOnly -ErrorAction SilentlyContinue |
               Where-Object { $_.InstanceId -eq $Script:Config.BluetoothInstanceId -and $_.Status -eq 'OK' })
    }
    if ($connected) {
        Write-Log "Bluetooth connection confirmed -- continuing Equipment Check."
        $Script:State.BluetoothConfirmed = $true
        $Script:btCheckStatusText.Visibility = 'Collapsed'
        $Script:window.Topmost = $true
        Show-Screen "ScreenQuestion"
        Show-CurrentQuestion
    } else {
        Write-Log "Bluetooth check failed -- device not connected yet." "WARN"
        $Script:btCheckStatusText.Text = "Bluetooth isn't connected yet. Check the settings and try again."
        $Script:btCheckStatusText.Visibility = 'Visible'
    }
})

$Script:btnBtNotConnected.Add_Click({
    $Script:btSubQ2Panel.Visibility        = 'Collapsed'
    $Script:btInstructionsPanel.Visibility = 'Visible'
    Write-Log "Bluetooth setup: operator indicated not connected -- showing reconnect instructions."
})

$Script:btnBtSkip.Add_Click({
    Show-ConfirmAction -Header "Are you sure you don't want to connect to Bluetooth?" -Bullets @(
        "You may not be able to play audio through the sound system."
    ) -OnConfirm {
        Write-Log "Bluetooth setup: operator skipped Bluetooth connection."
        $Script:State.BluetoothConfirmed       = $true
        $Script:btInstructionsPanel.Visibility = 'Collapsed'
        $Script:window.Topmost = $true
        Show-Screen "ScreenQuestion"
        Show-CurrentQuestion
    } -OnCancel {}
})

$Script:btnBtTryAgain.Add_Click({
    $Script:btInstructionsPanel.Visibility = 'Collapsed'
    $Script:btRestartingPanel.Visibility   = 'Visible'
    Write-Log "Bluetooth setup: operator chose to try again -- restarting Bluetooth adapter."
    Restart-BluetoothAdapter
    Open-BluetoothSettingsPositioned
    $Script:btRestartTimer.Start()
})



function Start-Launch {
    Write-Log "=== Launch sequence starting (Flow: $($Script:State.Flow), OnlyT: $($Script:Config.OnlyTMode)) ==="

    if ($Script:State.Flow -eq "NonZoom") {
        if ($Script:State.NonZoomProgram -eq "JWLibrary") {
            Set-SetupStatus "Starting JW Library..." "1 of 1  —  JW Library"
            $jwPath = Join-Path $Script:ScriptRoot $Script:Config.JwLibraryShortcut
            if (Test-Path $jwPath) {
                try { Start-Process -FilePath $jwPath; Write-Log "Launched JW Library." }
                catch { Write-Log "JW Library launch failed: $($_.Exception.Message)" "ERROR" }
            } else { Write-Log "JW Library shortcut not found: $jwPath" "ERROR" }
        } else {
            $m3Step = Get-LaunchStep -ModeName "Standard" -AppName "M3"
            Invoke-M3Step -Step $m3Step -StepNum 1 -AppCount 1
        }
        Set-SetupStatus "All done — your meeting is ready." "Complete"
        Start-Sleep -Milliseconds $Script:Config.FinalMessageHold
        Write-Log "=== Launch sequence complete (Non-Zoom) ==="
        return
    }

    $modeName = Get-PreflightModeName
    $sequence = Resolve-LaunchSequence -ModeName $modeName
    Write-Log "Launch sequence ($modeName): $(($sequence | ForEach-Object { $_.App }) -join ' -> ')"

    $appCount = $sequence.Count
    if ($Script:State.UseStageCountdown) { $appCount++ }

    $dispatch = @{
        Emeet = ${function:Invoke-EmeetStep}
        Zoom  = ${function:Invoke-ZoomStep}
        Obs   = ${function:Invoke-ObsStep}
        M3    = ${function:Invoke-M3Step}
        OnlyT = ${function:Invoke-OnlyTStep}
    }

    $stepNum = 0
    foreach ($entry in $sequence) {
        $stepNum++
        if ($dispatch.ContainsKey($entry.App)) {
            & $dispatch[$entry.App] $entry $stepNum $appCount
        } else {
            Write-Log "No launch handler for '$($entry.App)' -- skipping." "WARN"
        }
        Start-Sleep -Milliseconds $entry.DelayMs
    }

    # StageCountdown -- launched last, after everything else is up. It has no
    # tile of its own, so it isn't part of the position/order sequence above.
    if ($Script:State.UseStageCountdown) {
        $stepNum++
        Set-SetupStatus "Starting StageCountdown..." "$stepNum of $appCount  —  StageCountdown"
        Launch-StageCountdownNow
    }

    Set-SetupStatus "All done — your meeting is ready." "Complete"
    Start-Sleep -Milliseconds $Script:Config.FinalMessageHold
    Write-Log "=== Launch sequence complete ==="
}

# =============================================================================
#  EVENT WIRING
# =============================================================================

$Script:btnOpenInternet.Add_Click({ Open-NetworkSettings })
$Script:btnOpenWebcam.Add_Click({   Open-DeviceManager   })

function Enter-RegularMeetingFlow {
    $Script:State.Flow = "Regular"
    $Script:Sections = @(
        @{ Id = "zoom";      Name = "Zoom Setup";      Type = "video"; Questions = $Script:ZoomQuestionsHost }
        @{ Id = "equipment"; Name = "Equipment Check"; Type = "photo"; Questions = $Script:EquipmentQuestionsRegular }
    )
    $Script:State.SectionIdx  = 0
    $Script:State.QuestionIdx = 0
    Build-DetCards
    if ($Script:Config.ZoomSelfHostingMode) {
        $Script:State.ZoomMode = "Host"
        Show-Screen "ScreenQuestion"
        Show-CurrentQuestion
    } else {
        Show-Screen "ScreenZoomChoice"
    }
}

function Enter-NonZoomMeetingFlow {
    $Script:State.Flow = "NonZoom"
    $Script:Sections = @(
        @{ Id = "equipment"; Name = "Equipment Check"; Type = "photo"; Questions = $Script:EquipmentQuestionsNonZoom }
    )
    $Script:State.SectionIdx  = 0
    $Script:State.QuestionIdx = 0
    Build-DetCards
    Start-EquipmentSection
}

function Reset-PreflightState {
    Write-Log "=== Start Over -- resetting ==="
    if ($Script:detectionTimer) { $Script:detectionTimer.Stop() }
    if ($Script:videoPlayer)    { $Script:videoPlayer.Stop(); $Script:videoPlayer.Source = $null }

    $Script:State.SectionIdx       = 0
    $Script:State.QuestionIdx      = 0
    $Script:State.CurrentVideo     = ""
    $Script:State.AllHwReady       = $false
    $Script:State.AutoLaunched     = $false
    $Script:State.ZoomMode         = ""
    $Script:State.Flow             = "Regular"
    $Script:State.NonZoomProgram   = ""
    $Script:State.OnlyTLaunched    = $false
    $Script:State.OnlyTConfirmed   = $false
    $Script:State.OnlyTCodeStage   = "Wired"
    $Script:State.BluetoothConfirmed = $false
    $Script:State.StageCountdownAsked = $false
    $Script:State.UseStageCountdown   = $false
    $Script:State.EmeetVcamEnabled    = $false

    if ($Script:Config.OnlyTMode) {
        $Script:State.OnlyTAccessCodes = Get-OnlyTAccessCodes
        Write-Log "OnlyT codes refreshed on Start Over -- Wired: $(Format-AccessCodes $Script:State.OnlyTAccessCodes.Wired)  |  Wireless: $(Format-AccessCodes $Script:State.OnlyTAccessCodes.Wireless)"
    } else {
        $Script:State.OnlyTAccessCodes = @{ Wired = @(); Wireless = @() }
    }

    $Script:Sections = @(
        @{ Id = "zoom";      Name = "Zoom Setup";      Type = "video"; Questions = $Script:ZoomQuestionsHost }
        @{ Id = "equipment"; Name = "Equipment Check"; Type = "photo"; Questions = $Script:EquipmentQuestionsRegular }
    )
    Build-DetCards

    $Script:detReadyPanel.Visibility        = 'Collapsed'
    $Script:detOnlyTConfirmPanel.Visibility = 'Collapsed'
    $Script:detOnlyTHelpPanel.Visibility    = 'Collapsed'
    $Script:launchButton.Visibility         = 'Collapsed'
    $Script:launchButton.IsEnabled          = $true
    $Script:settingUpOverlay.Visibility     = 'Collapsed'
    $Script:confirmActionOverlay.Visibility = 'Collapsed'
    $Script:stageCountdownOverlay.Visibility = 'Collapsed'
    $Script:btnStartOver.Visibility         = 'Collapsed'
    $Script:window.Topmost = $true

    Show-Screen ""
    $Script:welcomeOverlay.Visibility = 'Visible'
}

$Script:btnStartOver.Add_Click({ Reset-PreflightState })

$Script:btnWelcomeStart.Add_Click({
    $Script:welcomeOverlay.Visibility = 'Collapsed'
    $Script:btnStartOver.Visibility   = 'Visible'
    if ($Script:Config.AdminMode) { Show-Screen "ScreenUseCase" }
    else                          { Enter-RegularMeetingFlow    }
})

$Script:btnUseCaseRegular.Add_Click({
    $bullets = @("Hosts Midweek and Weekend Meetings.", "Applies default audio and visual setup.")
    $bullets += if ($Script:Config.OnlyTMode) { "Configures Zoom, OBS, OnlyT, and Meeting Media Manager." }
                else                          { "Configures Zoom, OBS, and Meeting Media Manager."        }
    Show-ConfirmAction -Header "Set this laptop up for a Regular Meeting?" -Bullets $bullets `
        -OnConfirm { Enter-RegularMeetingFlow } -OnCancel { Show-Screen "ScreenUseCase" }
})

$Script:btnUseCaseNonZoom.Add_Click({
    Show-ConfirmAction -Header "Set this laptop up for a Non-Zoom Meeting?" -Bullets @(
        "Displays media for PSS, SCE, Pioneer's, and Elders and MS meetings."
        "Ideal for any gathering that does not require Zoom."
        "Configures the laptop specifically for local/offline use."
    ) -OnConfirm { Enter-NonZoomMeetingFlow } -OnCancel { Show-Screen "ScreenUseCase" }
})

$Script:btnConfirmActionYes.Add_Click({
    $Script:confirmActionOverlay.Visibility = 'Collapsed'
    if ($Script:PendingConfirmYes) { & $Script:PendingConfirmYes }
})
$Script:btnConfirmActionBack.Add_Click({
    $Script:confirmActionOverlay.Visibility = 'Collapsed'
    if ($Script:PendingConfirmCancel) { & $Script:PendingConfirmCancel }
})

$Script:btnProgramM3.Add_Click({
    Show-ConfirmAction -Header "Use Meeting Media Manager for today?" -Bullets @(
        "Meeting Media Manager will be the only program preflight launches."
    ) -OnConfirm { $Script:State.NonZoomProgram = "M3"; Show-DetectionScreen } `
      -OnCancel  { Show-Screen "ScreenProgramChoice" }
})

$Script:btnProgramJwLibrary.Add_Click({
    Show-ConfirmAction -Header "Use JW Library for today?" -Bullets @(
        "JW Library will be the only program preflight launches."
    ) -OnConfirm { $Script:State.NonZoomProgram = "JWLibrary"; Show-DetectionScreen } `
      -OnCancel  { Show-Screen "ScreenProgramChoice" }
})

$Script:btnZoomModeHost.Add_Click({
    $Script:State.ZoomMode = "Host"
    $Script:Sections[0].Questions = $Script:ZoomQuestionsHost
    $Script:zoomIntroHeading.Text = "First, let's start Zoom"
    $Script:zoomIntroSubtext.Text = "• Click Open Zoom below`n• Start today's meeting`n• Come back here once it has started"
    Show-Screen "ScreenZoomIntro"
})

$Script:btnZoomModeJoin.Add_Click({
    $Script:State.ZoomMode = "Join"
    $Script:Sections[0].Questions = $Script:ZoomQuestionsJoin
    $Script:zoomIntroHeading.Text = "First, let's join Zoom"
    $Script:zoomIntroSubtext.Text = "• Click Open Zoom below`n• Join today's meeting`n• Come back here once you've joined"
    Show-Screen "ScreenZoomIntro"
})

$Script:btnOpenZoomIntro.Add_Click({
    $Script:btnOpenZoomIntro.IsEnabled = $false
    $Script:zoomIntroSubtext.Text = "Opening Zoom..."
    $Script:window.Topmost = $false
    try {
        $already = Get-Process -Name "Zoom" -ErrorAction SilentlyContinue | Where-Object { $_.MainWindowHandle -ne 0 }
        if (-not $already -and (Test-Path $Script:Config.ZoomPath)) {
            Start-Process -FilePath $Script:Config.ZoomPath -ErrorAction SilentlyContinue
            Write-Log "Zoom launched from intro screen."
            Start-Sleep -Milliseconds $Script:Config.ZoomActivationWait
        }
        $zp = Find-AppMainWindow -ProcessNames $Script:Config.ZoomProcessNames -TimeoutSeconds 20
        if ($zp) {
            [Win32Native]::AllowSetForegroundWindow([Win32Native]::ASFW_ANY) | Out-Null
            [Win32Native]::SetForegroundWindow($zp.MainWindowHandle) | Out-Null
            Start-Sleep -Milliseconds $Script:Config.ZoomFocusSettle
            $zh = $Script:Config.ZoomHome
            Move-AppWindow -ProcessNames $Script:Config.ZoomProcessNames -DisplayName "Zoom (home)" `
                           -X $zh.X -Y $zh.Y -W $zh.W -H $zh.H
            $Script:zoomIntroSubtext.Text = if ($Script:State.ZoomMode -eq "Join") {
                "• Join today's meeting from the Zoom window`n• Come back here once you've joined"
            } else {
                "• Start today's meeting from the Zoom window`n• Come back here once it has started"
            }
            $Script:btnZoomIntroContinue.Visibility = 'Visible'
        } else {
            Write-Log "Zoom window not found from intro screen." "WARN"
            $Script:zoomIntroSubtext.Text = "Couldn't find Zoom. Open it manually, then continue."
            $Script:btnZoomIntroContinue.Visibility = 'Visible'
        }
    } finally { $Script:btnOpenZoomIntro.IsEnabled = $true }
})

$Script:btnZoomIntroContinue.Add_Click({
    Show-Screen "ScreenQuestion"
    Show-CurrentQuestion
})

$Script:btnYes.Add_Click({    Advance-Question })
$Script:btnYesEq.Add_Click({  Advance-Question })
$Script:btnShowHow.Add_Click({ Open-MediaVideo })

$Script:btnCloseVideo.Add_Click({
    $Script:videoPlayer.Stop()
    $Script:videoPlayer.Source = $null
    Show-Screen "ScreenQuestion"
    Write-Log "Video closed."
})

$Script:videoPlayer.Add_MediaEnded({
    $Script:videoPlayer.Stop()
    $Script:confirmText.Text = $Script:Sections[$Script:State.SectionIdx].Questions[$Script:State.QuestionIdx].Text
    Show-Screen "ScreenConfirm"
    Write-Log "Video ended -- confirm screen."
})

$Script:videoPlayer.Add_MediaFailed({
    param($s, $e)
    $Script:videoPlayer.Source = $null
    Write-Log "MediaFailed: $($e.ErrorException.Message)" "ERROR"
    Show-Screen "ScreenQuestion"
    $Script:videoErrorText.Text       = "Video could not be played — check the file in the media folder."
    $Script:videoErrorText.Visibility = 'Visible'
    $errTimer = New-Object System.Windows.Threading.DispatcherTimer
    $errTimer.Interval = [TimeSpan]::FromMilliseconds($Script:Config.VideoErrorHold)
    $errTimer.Add_Tick({ $errTimer.Stop(); $Script:videoErrorText.Visibility = 'Collapsed' })
    $errTimer.Start()
})

$Script:btnConfirmYes.Add_Click({ Advance-Question })
$Script:btnWatchAgain.Add_Click({
    if ($Script:State.CurrentVideo -and (Test-Path $Script:State.CurrentVideo)) {
        $Script:videoPlayer.Source = [Uri]::new($Script:State.CurrentVideo)
        $Script:videoPlayer.Play()
        Show-Screen "ScreenVideo"
        Write-Log "Replaying video."
    }
})

$Script:radioMidweek.Add_Checked({ Set-MeetingTypeBadge "Midweek"; Update-LaunchVisibility })
$Script:radioWeekend.Add_Checked({ Set-MeetingTypeBadge "Weekend"; Update-LaunchVisibility })

$Script:btnBackToEquipment.Add_Click({
    $Script:detectionTimer.Stop()
    $Script:State.SectionIdx  = $Script:Sections.Count - 1
    $Script:State.QuestionIdx = 0
    $Script:State.AllHwReady  = $false
    Show-CurrentQuestion
    Write-Log "Operator returned to Equipment Check."
})

# OnlyT confirm/help buttons
$Script:btnOnlyTConfirmYes.Add_Click({
    $Script:State.OnlyTConfirmed            = $true
    $Script:detOnlyTConfirmPanel.Visibility = 'Collapsed'
    $Script:detOnlyTHelpPanel.Visibility    = 'Collapsed'
    Write-Log "Operator confirmed OnlyT timer is showing ($($Script:State.OnlyTCodeStage) code)."
    Complete-OnlyTStep
})

$Script:btnOnlyTConfirmNo.Add_Click({
    $otherCodesExist = if ($Script:State.OnlyTCodeStage -eq "Wired") {
        [bool]$Script:State.OnlyTAccessCodes.Wireless
    } else {
        [bool]$Script:State.OnlyTAccessCodes.Wired
    }

    if ($otherCodesExist) {
        $Script:State.OnlyTCodeStage = if ($Script:State.OnlyTCodeStage -eq "Wired") { "Wireless" } else { "Wired" }
        Show-OnlyTCode
        $Script:detOnlyTConfirmQuestion.Text = "Try the other access code shown on the left — is the timer display showing now?"
        Write-Log "Operator reported OnlyT timer not showing -- switched to $($Script:State.OnlyTCodeStage) access code."
    } else {
        Write-Log "Operator reported OnlyT timer not showing after both access codes -- skipping OnlyT."
        Close-OnlyT
        $Script:detOnlyTConfirmPanel.Visibility = 'Collapsed'
        $Script:detOnlyTHelpPanel.Visibility    = 'Visible'
    }
})

$Script:btnOnlyTRetry.Add_Click({
    $Script:State.OnlyTConfirmed         = $true
    $Script:detOnlyTHelpPanel.Visibility = 'Collapsed'
    Write-Log "Continuing without OnlyT."
    Complete-OnlyTStep
})

# StageCountdown prompt buttons
$Script:btnStageCountdownYes.Add_Click({
    $Script:stageCountdownOverlay.Visibility = 'Collapsed'
    $Script:State.UseStageCountdown = $true
    Write-Log "Operator chose to use StageCountdown (queued to launch last, after M3)."
    Show-ReadyPanel
})

$Script:btnStageCountdownNo.Add_Click({
    $Script:stageCountdownOverlay.Visibility = 'Collapsed'
    $Script:State.UseStageCountdown = $false
    Write-Log "Operator declined StageCountdown for this meeting."
    Show-ReadyPanel
})

# ----- Setup Wizard buttons ---------------------------------------------------
$Script:setupObsScenes.Add_Click({
    $Script:setupObsSceneNamesPanel.Visibility = if ($Script:setupObsScenes.IsChecked -eq $true) { 'Visible' } else { 'Collapsed' }
})

$Script:btnSetupFinish.Add_Click({
    $Script:Config.CongregationName    = $Script:setupCongregationName.Text.Trim()
    $Script:Config.ZoomSelfHostingMode = [bool]$Script:setupZoomHosting.IsChecked
    $Script:Config.ObsDynamicSceneMode = [bool]$Script:setupObsScenes.IsChecked
    if ($Script:Config.ObsDynamicSceneMode) {
        $Script:Config.ObsSceneWeekend = $Script:setupObsSceneWeekend.Text.Trim()
        $Script:Config.ObsSceneMidweek = $Script:setupObsSceneMidweek.Text.Trim()
    }
    $Script:Config.ObsAlwaysOnTopMode = [bool]$Script:setupObsAlwaysOnTop.IsChecked
    $Script:Config.StageCountdownMode = [bool]$Script:setupStageCountdown.IsChecked

    Export-PreflightConfig -Path $Script:ConfigFile
    $Script:NeedsInitialSetup = $false
    Write-Log "Initial setup complete."

    $Script:setupOverlay.Visibility   = 'Collapsed'
    $Script:welcomeOverlay.Visibility = 'Visible'
    Start-PreflightFlow
})

# ----- Settings Menu buttons --------------------------------------------------
$Script:btnSettings.Add_Click({ Show-SettingsMenu })
$Script:btnSettingsClose.Add_Click({ $Script:settingsOverlay.Visibility = 'Collapsed' })
$Script:btnSettingsCancel.Add_Click({ $Script:settingsOverlay.Visibility = 'Collapsed' })
$Script:btnSettingsTabSimple.Add_Click({ Show-SettingsTab "Simple" })
$Script:btnSettingsTabAdvanced.Add_Click({ Show-SettingsTab "Advanced" })
$Script:btnSettingsTabLayout.Add_Click({ Show-SettingsTab "Layout" })

# Layout mode selection buttons
$Script:btnLayoutModeStandard.Add_Click({ Show-LayoutMode "Standard" })
$Script:btnLayoutModeOnlyT.Add_Click({ Show-LayoutMode "OnlyT" })
$Script:btnLayoutModeEmeet.Add_Click({ Show-LayoutMode "Emeet" })
$Script:btnLayoutModeEmeetOnlyT.Add_Click({ Show-LayoutMode "EmeetOnlyT" })

# Layout reset button
$Script:btnLayoutResetMode.Add_Click({
    if ($Script:LayoutEditorCurrentMode) {
        $result = [System.Windows.Forms.MessageBox]::Show(
            "Reset '$($Script:LayoutModeLabels[$Script:LayoutEditorCurrentMode])' layout to default settings?`n`nThis will remove all your custom positions and sizes for this mode.",
            "Reset Layout", 
            [System.Windows.Forms.MessageBoxButtons]::YesNo,
            [System.Windows.Forms.MessageBoxIcon]::Question
        )
        if ($result -eq [System.Windows.Forms.DialogResult]::Yes) {
            Remove-PreflightLayoutMode -ModeName $Script:LayoutEditorCurrentMode
            $Script:LayoutEditorRowsByMode.Remove($Script:LayoutEditorCurrentMode)
            Show-LayoutMode $Script:LayoutEditorCurrentMode
        }
    }
})

# PowerShell Integration Tool Event Handlers
$Script:btnCapturePositions.Add_Click({ Invoke-CaptureCurrentPositions })
$Script:btnDetectResolution.Add_Click({ Invoke-DetectScreenResolution })
$Script:btnShowPreview.Add_Click({ Show-LayoutPreview })

# Layout Quick Action Event Handlers
$Script:btnLayoutPresetTileLeft.Add_Click({ Invoke-LayoutPreset "TileLeft" })
$Script:btnLayoutPresetTileRight.Add_Click({ Invoke-LayoutPreset "TileRight" })
$Script:btnLayoutPresetCenter.Add_Click({ Invoke-LayoutPreset "Center" })
$Script:btnLayoutPresetFullscreen.Add_Click({ Invoke-LayoutPreset "Fullscreen" })
$Script:btnLayoutValidate.Add_Click({ Invoke-ValidateLayout })
$Script:btnLayoutAutoAlign.Add_Click({
    Update-LayoutToolsStatus "Auto-align feature coming soon!" "#60A5FA"
})
$Script:btnLayoutCopy.Add_Click({
    Update-LayoutToolsStatus "Copy settings feature coming soon!" "#60A5FA"
})
$Script:btnLayoutSaveMode.Add_Click({ Invoke-SaveLayoutMode })

$Script:setObsScenes.Add_Click({
    $Script:setObsSceneNamesPanel.Visibility = if ($Script:setObsScenes.IsChecked -eq $true) { 'Visible' } else { 'Collapsed' }
})

$Script:btnSettingsSave.Add_Click({
    $updates = @{
        CongregationName    = $Script:setCongregationName.Text.Trim()
        ZoomSelfHostingMode = [bool]$Script:setZoomHosting.IsChecked
        ObsDynamicSceneMode = [bool]$Script:setObsScenes.IsChecked
        ObsSceneWeekend     = $Script:setObsSceneWeekend.Text.Trim()
        ObsSceneMidweek     = $Script:setObsSceneMidweek.Text.Trim()
        ObsAlwaysOnTopMode  = [bool]$Script:setObsAlwaysOnTop.IsChecked
        StageCountdownMode  = [bool]$Script:setStageCountdown.IsChecked
    }
    foreach ($key in $Script:AdvancedControls.Keys) {
        $ctrl = $Script:AdvancedControls[$key]
        $updates[$key] = if ($ctrl -is [System.Windows.Controls.CheckBox]) { [bool]$ctrl.IsChecked } else { $ctrl.Text.Trim() }
    }

    foreach ($key in $updates.Keys) { $Script:Config[$key] = $updates[$key] }
    $Script:Config.Layout = Resolve-PreflightLayout

    # Save any pending layout changes
    foreach ($modeName in $Script:LayoutEditorRowsByMode.Keys) {
        try {
            $rows = $Script:LayoutEditorRowsByMode[$modeName]
            Save-PreflightLayoutMode -ModeName $modeName -Rows $rows
            Write-Log "Auto-saved layout changes for mode: $modeName"
        } catch {
            Write-Log "Error auto-saving layout for $modeName`: $($_.Exception.Message)" "WARN"
        }
    }

    $Script:settingsOverlay.Visibility   = 'Collapsed'
    Set-SetupStatus "Saving your settings..." ""
    $Script:settingUpOverlay.Visibility  = 'Visible'
    Start-Sleep -Milliseconds 700

    if ($Script:NeedsInitialSetup) {
        Export-PreflightConfig -Path $Script:ConfigFile
        $Script:NeedsInitialSetup = $false
    } else {
        Update-PreflightConfigFile -Updates $updates -Path $Script:ConfigFile
    }

    $Script:settingUpOverlay.Visibility = 'Collapsed'
    $Script:restartOverlay.Visibility   = 'Visible'
})

$Script:btnRestartNow.Add_Click({
    Write-Log "Restarting Preflight to apply new settings."
    try {
        Start-Process -FilePath "powershell.exe" -ArgumentList @("-NoProfile", "-ExecutionPolicy", "Bypass", "-File", "`"$Script:SelfPath`"")
    } catch {
        Write-Log "Restart failed: $($_.Exception.Message)" "ERROR"
    }
    $Script:window.Close()
})

$Script:btnRestartLater.Add_Click({
    $Script:restartOverlay.Visibility = 'Collapsed'
})

function Invoke-Launch {
    $Script:launchButton.IsEnabled = $false
    $Script:detectionTimer.Stop()
    $Script:settingUpOverlay.Visibility = 'Visible'
    $Script:window.Dispatcher.Invoke([action]{}, [System.Windows.Threading.DispatcherPriority]::Render)
    try { Start-Launch } catch { Write-Log "Launch error: $($_.Exception.Message)" "ERROR" }
    $Script:window.Close()
}

$Script:launchButton.Add_Click({ Invoke-Launch })

$Script:window.Add_KeyDown({
    param($s, $e)
    if ($e.Key -eq [System.Windows.Input.Key]::S) {
        $mods = [System.Windows.Input.Keyboard]::Modifiers
        $cs   = [System.Windows.Input.ModifierKeys]::Control -bor [System.Windows.Input.ModifierKeys]::Shift
        if (($mods -band $cs) -eq $cs) {
            Write-Log "Admin escape (Ctrl+Shift+S)."
            $Script:window.Close()
        }
    }
})

# ----- TIMERS ----------------------------------------------------------------
$Script:detectionTimer          = New-Object System.Windows.Threading.DispatcherTimer
$Script:detectionTimer.Interval = [TimeSpan]::FromMilliseconds($Script:Config.UiRefreshMs)
$Script:detectionTimer.Add_Tick({ Update-Detection })

$Script:clockTimer          = New-Object System.Windows.Threading.DispatcherTimer
$Script:clockTimer.Interval = [TimeSpan]::FromSeconds(1)
$Script:clockTimer.Add_Tick({ $Script:clockText.Text = (Get-Date -Format "h:mm tt") })

$Script:btRestartTimer          = New-Object System.Windows.Threading.DispatcherTimer
$Script:btRestartTimer.Interval = [TimeSpan]::FromSeconds(5)
$Script:btRestartTimer.Add_Tick({
    $Script:btRestartTimer.Stop()
    $Script:btRestartingPanel.Visibility = 'Collapsed'
    $Script:btSubQ2Panel.Visibility      = 'Visible'
    $Script:btCheckStatusText.Visibility = 'Collapsed'
    Write-Log "Bluetooth setup: restart complete -- back to connect sub-question."
})

$Script:window.Add_Closed({
    Stop-HardwarePolling
    if ($Script:detectionTimer) { $Script:detectionTimer.Stop() }
    if ($Script:clockTimer)     { $Script:clockTimer.Stop() }
    if ($Script:btRestartTimer) { $Script:btRestartTimer.Stop() }
    Write-Log "=== Audio-Video Preflight closed ==="
})

$Script:window.Add_ContentRendered({
    if ($Script:Config.TestMode) { $Script:testModeBanner.Visibility = 'Visible' }
    $Script:clockText.Text = (Get-Date -Format "h:mm tt")
    $Script:clockTimer.Start()

    if ($Script:NeedsInitialSetup) {
        Show-InitialSetup
    } else {
        Start-PreflightFlow
    }
})

# =============================================================================
#  START
# =============================================================================
[void]$Script:window.ShowDialog()